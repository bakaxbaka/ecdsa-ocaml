#!/usr/bin/env python3
"""
Fetch all spending transactions for one or more Bitcoin addresses
(transactions where the address appears as INPUT).
Saves per-address JSON incrementally + a combined JSON at the end.

Resumable: skips addresses whose per-address file already exists in data/.
Use --force to re-fetch anyway.

Usage:
  python fetch_address_inputs.py                          # uses address.txt
  python fetch_address_inputs.py address.txt [out.json]
  python fetch_address_inputs.py <single-address> [out.json]
  python fetch_address_inputs.py --force [address.txt]
"""

import sys
import json
import time
import requests
from pathlib import Path

BLOCKCHAIN_APIS = [
    {'name': 'mempool.space',
     'address_url': 'https://mempool.space/api/address/{address}/txs',
     'raw_tx_url': 'https://mempool.space/api/tx/{txid}/hex'},
    {'name': 'blockstream.info',
     'address_url': 'https://blockstream.info/api/address/{address}/txs',
     'raw_tx_url': 'https://blockstream.info/api/tx/{txid}/hex'},
    {'name': 'blockchain.info',
     'address_url': 'https://blockchain.info/rawaddr/{address}',
     'raw_tx_url': 'https://blockchain.info/tx/{txid}?format=hex'},
]

DATA_DIR                 = Path("data")
DELAY_BETWEEN_ADDRESSES  = 1.0
PAGE_DELAY               = 0.3
MAX_CHAIN_PAGES          = 400
MAX_BLOCKCHAININFO_PAGES = 200


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def safe_addr(addr):
    return addr.replace(':', '_').replace('/', '_').replace('\\', '_')


def per_address_path(addr):
    return DATA_DIR / f"input_txs_{safe_addr(addr)}.json"


def save_json(data, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, 'w') as f:
        json.dump(data, f, indent=2)
    tmp.replace(path)


def load_addresses_from_file(filepath):
    path = Path(filepath)
    if not path.exists():
        print(f"Error: file not found: {filepath}")
        return []
    out, seen = [], set()
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            for tok in line.replace(',', ' ').split():
                if tok and tok not in seen:
                    seen.add(tok)
                    out.append(tok)
    return out


def looks_like_address(s):
    return bool(s) and s.startswith(('1', '3', 'bc1', 'tb1', 'bcrt1'))


def is_file_path(s):
    try:
        return Path(s).exists()
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Paginated fetch
# ---------------------------------------------------------------------------
def get_address_txs(address):
    for api in BLOCKCHAIN_APIS:
        print(f"Trying {api['name']}...")
        try:
            if api['name'] in ('mempool.space', 'blockstream.info'):
                txs = _paginate_esplora(api, address)
            elif api['name'] == 'blockchain.info':
                txs = _paginate_blockchain_info(api, address)
            else:
                continue
            if txs is not None:
                return txs, api['name']
        except requests.RequestException as e:
            print(f"  Failed with {api['name']}: {e}")
    print("All APIs failed")
    return None, None


def _paginate_esplora(api, address):
    """Esplora-style pagination (mempool.space / blockstream.info).

    /api/address/{addr}/txs             -> up to 50 mempool + 25 confirmed
    /api/address/{addr}/txs/chain/{id}  -> 25 more confirmed, newest->oldest
    """
    # --- FIX: format the URL FIRST, then strip the '/txs' suffix ---
    initial_url = api['address_url'].format(address=address)
    base = initial_url.rsplit('/txs', 1)[0]

    r = requests.get(initial_url, timeout=30)
    r.raise_for_status()
    all_txs = r.json()
    print(f"  Initial page: {len(all_txs)} txs")

    last_confirmed = None
    for tx in all_txs:
        if tx.get('status', {}).get('confirmed'):
            last_confirmed = tx['txid']

    if last_confirmed is None:
        # Only mempool txs; can't paginate chain.
        print("  (no confirmed txs — chain pagination skipped)")
    else:
        pages = 0
        while last_confirmed and pages < MAX_CHAIN_PAGES:
            pages += 1
            chain_url = f"{base}/txs/chain/{last_confirmed}"
            r = requests.get(chain_url, timeout=30)
            r.raise_for_status()
            page = r.json()
            if not page:
                print(f"  Chain page {pages}: 0 txs (end)")
                break
            print(f"  Chain page {pages}: {len(page)} txs")
            all_txs.extend(page)
            if len(page) < 25:
                break
            last_confirmed = page[-1]['txid']
            time.sleep(PAGE_DELAY)

        if pages >= MAX_CHAIN_PAGES:
            print(f"  ⚠ Hit pagination cap ({MAX_CHAIN_PAGES} pages).")

    # Dedupe by txid
    seen, deduped = set(), []
    for tx in all_txs:
        if tx['txid'] not in seen:
            seen.add(tx['txid'])
            deduped.append(tx)
    print(f"  Total: {len(deduped)} txs (from {len(all_txs)} fetched)")
    return deduped


def _paginate_blockchain_info(api, address):
    """blockchain.info rawaddr offset/limit pagination.

    NOTE: blockchain.info does not expose prev-txid per input, so
    prevout_data will be empty → sighash z will be zero for these records.
    """
    offset, limit, out = 0, 50, []
    for _ in range(MAX_BLOCKCHAININFO_PAGES):
        r = requests.get(
            f"https://blockchain.info/rawaddr/{address}?offset={offset}&limit={limit}",
            timeout=30)
        r.raise_for_status()
        data = r.json()
        txs = data.get('txs', [])
        if not txs:
            break
        print(f"  Offset {offset}: {len(txs)} txs (n_tx={data.get('n_tx')})")
        for tx in txs:
            vin = []
            for inp in tx.get('inputs', []):
                po = inp.get('prev_out', {}) or {}
                vin.append({
                    'prevout': {
                        'txid': '',
                        'index': po.get('n', 0),
                        'scriptpubkey': po.get('script', ''),
                        'scriptpubkey_address': po.get('addr', ''),
                        'value': po.get('value', 0),
                    },
                    'sequence': inp.get('sequence'),
                })
            vout = [{
                'value': o.get('value', 0),
                'scriptpubkey': o.get('script', ''),
                'scriptpubkey_address': o.get('addr', ''),
            } for o in tx.get('out', [])]
            out.append({
                'txid': tx['hash'],
                'status': {
                    'block_height': tx.get('block_height'),
                    'block_time': tx.get('time'),
                    'confirmed': tx.get('block_height') is not None,
                },
                'size': tx.get('size'),
                'fee': tx.get('fee'),
                'vin': vin, 'vout': vout,
            })
        offset += len(txs)
        if offset >= data.get('n_tx', 0) or len(txs) < limit:
            break
        time.sleep(PAGE_DELAY)
    return out


def get_raw_tx(txid):
    for api in BLOCKCHAIN_APIS:
        try:
            r = requests.get(api['raw_tx_url'].format(txid=txid), timeout=30)
            r.raise_for_status()
            return r.text.strip()
        except requests.RequestException:
            continue
    return None


def get_tx_json(txid):
    for api in BLOCKCHAIN_APIS:
        if api['name'] == 'mempool.space':
            url = f"https://mempool.space/api/tx/{txid}"
        elif api['name'] == 'blockstream.info':
            url = f"https://blockstream.info/api/tx/{txid}"
        elif api['name'] == 'blockchain.info':
            url = f"https://blockchain.info/tx/{txid}?format=json"
        else:
            continue
        try:
            r = requests.get(url, timeout=30)
            r.raise_for_status()
            return r.json()
        except requests.RequestException:
            continue
    return None


def is_spending_transaction(tx, address):
    for vin in tx.get('vin', []):
        po = vin.get('prevout') or {}
        if po.get('scriptpubkey_address') == address:
            return True
    return False


def fetch_input_transactions(address):
    all_txs, api_name = get_address_txs(address)
    if not all_txs:
        return []

    spending = [t for t in all_txs if is_spending_transaction(t, address)]
    print(f"Found {len(all_txs)} total, {len(spending)} spending txs ({api_name})")

    results = []
    for i, tx in enumerate(spending, 1):
        txid = tx['txid']
        print(f"[{i}/{len(spending)}] {txid}")
        raw_hex = get_raw_tx(txid)
        if not raw_hex:
            print("  Failed to fetch raw hex")
            continue

        prevout_data = []
        for j, vin in enumerate(tx.get('vin', [])):
            po = vin.get('prevout') or {}
            if 'scriptpubkey_address' not in po:
                continue
            prev_txid = po.get('txid', '')
            if not prev_txid:
                continue
            idx_out = po.get('index', 0)
            pj = get_tx_json(prev_txid)
            if pj and 'vout' in pj and idx_out < len(pj['vout']):
                v = pj['vout'][idx_out]
                prevout_data.append({
                    'input_index': j,
                    'prev_txid': prev_txid,
                    'prevout_index': idx_out,
                    'scriptpubkey': v.get('scriptpubkey', ''),
                    'scriptpubkey_address': v.get('scriptpubkey_address', ''),
                    'value': v.get('value', 0),
                })

        results.append({
            'txid': txid,
            'address': address,
            'raw_hex': raw_hex,
            'height': tx.get('status', {}).get('block_height'),
            'timestamp': tx.get('status', {}).get('block_time'),
            'size': tx.get('size'),
            'fee': tx.get('fee'),
            'input_count': len(tx.get('vin', [])),
            'output_count': len(tx.get('vout', [])),
            'prevout_data': prevout_data,
        })
    return results


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def print_usage():
    print("Usage:")
    print("  python fetch_address_inputs.py")
    print("  python fetch_address_inputs.py address.txt [out.json]")
    print("  python fetch_address_inputs.py <single-address> [out.json]")
    print("  python fetch_address_inputs.py --force [address.txt]")
    print("\nPer-address results are stored in ./data/ and skipped on rerun.")


def main():
    args = sys.argv[1:]
    if any(a in ('-h', '--help') for a in args):
        print_usage(); sys.exit(0)

    force = '--force' in args
    args = [a for a in args if a != '--force']

    addresses, output_file = [], None
    if not args:
        default_file = 'address.txt'
        if not Path(default_file).exists():
            print(f"Error: '{default_file}' not found."); print_usage(); sys.exit(1)
        addresses = load_addresses_from_file(default_file)
        print(f"Loaded {len(addresses)} addresses from {default_file}")
    else:
        first = args[0]
        if is_file_path(first):
            addresses = load_addresses_from_file(first)
            print(f"Loaded {len(addresses)} addresses from {first}")
            if len(args) > 1: output_file = args[1]
        elif looks_like_address(first):
            addresses = [first]
            if len(args) > 1: output_file = args[1]
        else:
            print(f"Error: '{first}' is neither a file nor an address.")
            print_usage(); sys.exit(1)

    if not addresses:
        print("No addresses to process."); sys.exit(0)

    if not output_file:
        if len(addresses) == 1:
            output_file = f"input_txs_{safe_addr(addresses[0])}.json"
        else:
            output_file = "input_txs_all.json"

    DATA_DIR.mkdir(exist_ok=True)

    print("=" * 60)
    print("Bitcoin Address Input Fetcher — per-address incremental save")
    print("=" * 60)
    if force:
        print("⚠ --force: ignoring existing per-address files")

    all_results, per_address_counts = [], {}

    for idx, address in enumerate(addresses, 1):
        pa = per_address_path(address)
        print("\n" + "=" * 60)
        print(f"[{idx}/{len(addresses)}] {address}")
        print("=" * 60)

        if pa.exists() and not force:
            try:
                with open(pa) as f:
                    results = json.load(f)
                print(f"  ✓ Cached: {len(results)} txs from {pa} (skipping)")
                per_address_counts[address] = len(results)
                all_results.extend(results)
                continue
            except Exception as e:
                print(f"  Cache load failed ({e}); re-fetching")

        try:
            results = fetch_input_transactions(address)
        except Exception as e:
            print(f"Error: {e}")
            results = []

        save_json(results, pa)
        print(f"  ✓ Saved {len(results)} txs to {pa}")
        per_address_counts[address] = len(results)
        all_results.extend(results)

        if idx < len(addresses):
            time.sleep(DELAY_BETWEEN_ADDRESSES)

    if all_results:
        save_json(all_results, output_file)
        print(f"\n✓ Combined: {len(all_results)} txs → {output_file}")
    else:
        print("\nNo spending transactions found.")

    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)
    print(f"Addresses:  {len(addresses)}")
    print(f"Total txs:  {len(all_results)}")
    print(f"Per-address files: {DATA_DIR}/")
    for a in addresses:
        n = per_address_counts.get(a, 0)
        marker = "" if n else "  (no spending txs)"
        print(f"  {a}: {n}{marker}")
    print("\nDone!")


if __name__ == "__main__":
    main()