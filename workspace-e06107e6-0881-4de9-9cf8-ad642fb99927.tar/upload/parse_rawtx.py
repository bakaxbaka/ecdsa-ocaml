#!/usr/bin/env python3
"""
Parse raw Bitcoin transaction hex, extract signature (r, s) values, and calculate sighash (z).
Supports legacy (P2PKH/P2PK) and SegWit v0 (P2WPKH) inputs.

Usage: python parse_rawtx.py <rawtx_hex> [input_index]
"""

import sys
import struct
import hashlib

# secp256k1 curve order / 2 — used for low-S check
SECP256K1_N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
SECP256K1_HALF_N = SECP256K1_N // 2


def double_sha256(data):
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()


def encode_varint(n):
    """Encode a compact size (varint) per Bitcoin serialization."""
    if n < 0xfd:
        return bytes([n])
    elif n <= 0xffff:
        return b'\xfd' + struct.pack('<H', n)
    elif n <= 0xffffffff:
        return b'\xfe' + struct.pack('<I', n)
    else:
        return b'\xff' + struct.pack('<Q', n)


def decode_varint(data, pos):
    if pos >= len(data):
        raise ValueError("Unexpected end of data at varint")
    b = data[pos]
    if b < 0xfd:
        return b, pos + 1
    elif b == 0xfd:
        return struct.unpack('<H', data[pos+1:pos+3])[0], pos + 3
    elif b == 0xfe:
        return struct.unpack('<I', data[pos+1:pos+5])[0], pos + 5
    elif b == 0xff:
        return struct.unpack('<Q', data[pos+1:pos+9])[0], pos + 9


# ---------------------------------------------------------------------------
# ScriptSig / signature parsing
# ---------------------------------------------------------------------------
def parse_script_sig(script_sig):
    """Parse a legacy scriptSig.

    Returns (der_sig, pubkey, sighash_type) where:
      - der_sig is clean DER (sighash byte stripped)
      - pubkey is 33/65 raw bytes, or None for P2PK (pubkey lives in prevout script)
      - sighash_type is the final byte of the signature push (0x01, 0x02, 0x03, ...)

    Format handled:
      P2PKH: <push sig+sighash> <push pubkey>
      P2PK:  <push sig+sighash>
    """
    pos = 0
    sig_len, pos = decode_varint(script_sig, pos)
    sig_with_hashtype = script_sig[pos:pos + sig_len]
    pos += sig_len

    if len(sig_with_hashtype) < 2:
        raise ValueError(f"Signature push too short: {len(sig_with_hashtype)} bytes")

    sighash_type = sig_with_hashtype[-1]
    der_sig = sig_with_hashtype[:-1]

    pubkey = None
    if pos < len(script_sig):
        try:
            pk_len, pk_pos = decode_varint(script_sig, pos)
            if pk_pos + pk_len <= len(script_sig):
                candidate = script_sig[pk_pos:pk_pos + pk_len]
                if (len(candidate) == 33 and candidate[0] in (0x02, 0x03)) or \
                   (len(candidate) == 65 and candidate[0] == 0x04):
                    pubkey = candidate
        except Exception:
            pass

    return der_sig, pubkey, sighash_type


def parse_witness_signature(witness_items):
    """Parse P2WPKH witness: [signature_with_sighash, pubkey]."""
    if len(witness_items) < 2:
        raise ValueError(f"P2WPKH witness needs >=2 items, got {len(witness_items)}")
    sig_with_hashtype = witness_items[0]
    pubkey = witness_items[1]
    if len(sig_with_hashtype) < 2:
        raise ValueError("Witness signature too short")
    sighash_type = sig_with_hashtype[-1]
    der_sig = sig_with_hashtype[:-1]
    return der_sig, pubkey, sighash_type


def parse_der_signature(der_sig):
    """Extract (r, s) integers from a DER-encoded signature (no sighash byte)."""
    if len(der_sig) < 8:
        raise ValueError(f"DER too short: {len(der_sig)} bytes")
    if der_sig[0] != 0x30:
        raise ValueError("Invalid DER: not a SEQUENCE")

    pos = 2

    if der_sig[pos] != 0x02:
        raise ValueError("Invalid DER: r tag")
    r_len = der_sig[pos + 1]
    r_bytes = der_sig[pos + 2:pos + 2 + r_len]
    pos += 2 + r_len

    if pos >= len(der_sig) or der_sig[pos] != 0x02:
        raise ValueError("Invalid DER: s tag")
    s_len = der_sig[pos + 1]
    s_bytes = der_sig[pos + 2:pos + 2 + s_len]

    r = int.from_bytes(r_bytes, 'big')
    s = int.from_bytes(s_bytes, 'big')
    return r, s


# ---------------------------------------------------------------------------
# Transaction parsing
# ---------------------------------------------------------------------------
def parse_raw_transaction(rawtx_hex):
    data = bytes.fromhex(rawtx_hex.strip())
    pos = 0

    if len(data) < 10:
        raise ValueError(f"Transaction too short: {len(data)} bytes")

    version = struct.unpack('<I', data[pos:pos + 4])[0]; pos += 4

    marker = data[pos] if pos < len(data) else 0
    flag = data[pos + 1] if pos + 1 < len(data) else 0
    is_segwit = (marker == 0x00 and flag == 0x01)
    if is_segwit:
        pos += 2

    input_count, pos = decode_varint(data, pos)
    inputs = []
    for i in range(input_count):
        prev_txid = data[pos:pos + 32][::-1].hex(); pos += 32
        prevout = struct.unpack('<I', data[pos:pos + 4])[0]; pos += 4
        script_len, pos = decode_varint(data, pos)
        script_sig = data[pos:pos + script_len]; pos += script_len
        sequence = struct.unpack('<I', data[pos:pos + 4])[0]; pos += 4
        inputs.append({
            'prev_txid': prev_txid,
            'prevout': prevout,
            'script_sig': script_sig,
            'sequence': sequence,
        })

    output_count, pos = decode_varint(data, pos)
    outputs = []
    for i in range(output_count):
        value = struct.unpack('<Q', data[pos:pos + 8])[0]; pos += 8
        script_len, pos = decode_varint(data, pos)
        script_pubkey = data[pos:pos + script_len]; pos += script_len
        outputs.append({'value': value, 'script_pubkey': script_pubkey})

    witnesses = []
    if is_segwit:
        for i in range(input_count):
            wcount, pos = decode_varint(data, pos)
            witness = []
            for _ in range(wcount):
                wlen, pos = decode_varint(data, pos)
                witness.append(data[pos:pos + wlen]); pos += wlen
            witnesses.append(witness)

    locktime = struct.unpack('<I', data[pos:pos + 4])[0]

    return {
        'version': version,
        'inputs': inputs,
        'outputs': outputs,
        'witnesses': witnesses if is_segwit else None,
        'locktime': locktime,
        'is_segwit': is_segwit,
    }


# ---------------------------------------------------------------------------
# Sighash (z) calculation
# ---------------------------------------------------------------------------
def calculate_sighash_legacy(rawtx_hex, input_index, scriptPubKey, sighash_type=0x01):
    """Legacy (pre-segwit) sighash for P2PKH / P2PK."""
    if isinstance(scriptPubKey, str):
        spk_bytes = bytes.fromhex(scriptPubKey)
    else:
        spk_bytes = scriptPubKey

    data = bytes.fromhex(rawtx_hex)
    pos = 0

    version = data[pos:pos + 4]; pos += 4

    is_segwit = (data[pos] == 0x00 and data[pos + 1] == 0x01)
    if is_segwit:
        pos += 2

    input_count, pos = decode_varint(data, pos)

    preimage = bytearray()
    preimage.extend(version)
    preimage.extend(encode_varint(input_count))

    for i in range(input_count):
        prev_txid = data[pos:pos + 32]; pos += 32
        prevout = data[pos:pos + 4]; pos += 4
        script_len, pos = decode_varint(data, pos)
        _script_sig = data[pos:pos + script_len]; pos += script_len
        sequence = data[pos:pos + 4]; pos += 4

        preimage.extend(prev_txid)
        preimage.extend(prevout)
        if i == input_index:
            preimage.extend(encode_varint(len(spk_bytes)))
            preimage.extend(spk_bytes)
        else:
            preimage.extend(b'\x00')
        preimage.extend(sequence)

    output_count, pos = decode_varint(data, pos)
    preimage.extend(encode_varint(output_count))

    for _ in range(output_count):
        value = data[pos:pos + 8]; pos += 8
        script_len, pos = decode_varint(data, pos)
        spk = data[pos:pos + script_len]; pos += script_len
        preimage.extend(value)
        preimage.extend(encode_varint(script_len))
        preimage.extend(spk)

    locktime = data[pos:pos + 4]
    preimage.extend(locktime)
    preimage.extend(struct.pack('<I', sighash_type))

    return double_sha256(bytes(preimage))


def calculate_sighash_segwit_v0(rawtx_hex, input_index, prevout_value,
                                script_pubkey_hex, sighash_type=0x01):
    """BIP143 sighash for P2WPKH inputs."""
    data = bytes.fromhex(rawtx_hex)
    pos = 0

    version = data[pos:pos + 4]; pos += 4
    pos += 2

    input_count, pos = decode_varint(data, pos)
    inputs = []
    for _ in range(input_count):
        prev_txid = data[pos:pos + 32]; pos += 32
        prevout = data[pos:pos + 4]; pos += 4
        script_len, pos = decode_varint(data, pos)
        pos += script_len
        sequence = data[pos:pos + 4]; pos += 4
        inputs.append((prev_txid, prevout, sequence))

    output_count, pos = decode_varint(data, pos)
    outputs = []
    for _ in range(output_count):
        value = data[pos:pos + 8]; pos += 8
        script_len, pos = decode_varint(data, pos)
        spk = data[pos:pos + script_len]; pos += script_len
        outputs.append((value, spk))

    locktime = data[pos:pos + 4]

    spk = bytes.fromhex(script_pubkey_hex) if isinstance(script_pubkey_hex, str) else script_pubkey_hex
    if len(spk) == 22 and spk[0] == 0x00 and spk[1] == 0x14:
        hash160 = spk[2:]
        script_code = bytes([0x76, 0xa9, 0x14]) + hash160 + bytes([0x88, 0xac])
    else:
        raise ValueError(f"Unsupported SegWit scriptPubKey for sighash: {spk.hex()}")

    preimage = bytearray()
    preimage.extend(version)

    prevouts_data = bytearray()
    for prev_txid, prevout, _ in inputs:
        prevouts_data.extend(prev_txid)
        prevouts_data.extend(prevout)
    preimage.extend(double_sha256(bytes(prevouts_data)))

    seq_data = bytearray()
    for _, _, seq in inputs:
        seq_data.extend(seq)
    preimage.extend(double_sha256(bytes(seq_data)))

    prev_txid, prevout, sequence = inputs[input_index]
    preimage.extend(prev_txid)
    preimage.extend(prevout)

    preimage.extend(encode_varint(len(script_code)))
    preimage.extend(script_code)

    preimage.extend(struct.pack('<Q', int(prevout_value)))
    preimage.extend(sequence)

    out_data = bytearray()
    for value, spk in outputs:
        out_data.extend(value)
        out_data.extend(encode_varint(len(spk)))
        out_data.extend(spk)
    preimage.extend(double_sha256(bytes(out_data)))

    preimage.extend(locktime)
    preimage.extend(struct.pack('<I', sighash_type))

    return double_sha256(bytes(preimage))


calculate_sighash_bip34 = calculate_sighash_legacy


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    if len(sys.argv) < 2:
        print("Usage: python parse_rawtx.py <rawtx_hex> [input_index]")
        sys.exit(1)

    rawtx_hex = sys.argv[1]
    input_index = int(sys.argv[2]) if len(sys.argv) > 2 else 0

    tx = parse_raw_transaction(rawtx_hex)

    print(f"Version:  {tx['version']}")
    print(f"Inputs:   {len(tx['inputs'])}")
    print(f"Outputs:  {len(tx['outputs'])}")
    print(f"Locktime: {tx['locktime']}")
    print(f"SegWit:   {tx['is_segwit']}")
    print()

    for i, inp in enumerate(tx['inputs']):
        print(f"--- Input {i} ---")
        print(f"  Prev TXID: {inp['prev_txid']}")
        print(f"  Prevout:   {inp['prevout']}")
        print(f"  Sequence:  {inp['sequence']}")

        is_segwit_input = (
            tx['is_segwit']
            and i < len(tx['witnesses'] or [])
            and len(tx['witnesses'][i]) > 0
        )

        try:
            if is_segwit_input:
                der_sig, pubkey, sighash_type = parse_witness_signature(tx['witnesses'][i])
                print(f"  Type:      P2WPKH (segwit)")
            else:
                if not inp['script_sig']:
                    print("  (no scriptSig)")
                    continue
                der_sig, pubkey, sighash_type = parse_script_sig(inp['script_sig'])
                print(f"  Type:      {'P2PKH' if pubkey else 'P2PK'} (legacy)")

            r, s = parse_der_signature(der_sig)
            print(f"  DER:       {der_sig.hex()}")
            print(f"  r:         {hex(r)}")
            print(f"  s:         {hex(s)}")
            print(f"  low-S:     {'yes' if s <= SECP256K1_HALF_N else 'NO (malleable)'}")
            print(f"  sighash:   0x{sighash_type:02x}")
            if pubkey:
                print(f"  PublicKey: {pubkey.hex()}")
            else:
                print("  PublicKey: (P2PK — in prevout script)")
        except Exception as e:
            print(f"  Error: {e}")

        print()


if __name__ == "__main__":
    main()