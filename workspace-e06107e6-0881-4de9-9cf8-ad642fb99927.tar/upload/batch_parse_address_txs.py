#!/usr/bin/env python3
"""
Parse transactions, extract r/s, compute z, detect nonce reuse.
Writes per-address CSVs incrementally (hex + decimal variants)
plus combined CSVs at the end. Resumable via data/.

Numeric values r, s, z are written twice:
  - signatures*.csv          → hex (e.g. 0x5823…)
  - signatures*_decimal.csv  → same structure, values as decimal integers

Usage:
  python batch_parse_address_txs.py <input_json> [output_csv] [--force]
  python batch_parse_address_txs.py data/ [output_csv] [--force]
"""

import sys
import json
import csv
from pathlib import Path
from collections import defaultdict

try:
    from parse_rawtx import (
        parse_raw_transaction, parse_script_sig, parse_witness_signature,
        parse_der_signature, calculate_sighash_legacy,
        calculate_sighash_segwit_v0, SECP256K1_HALF_N,
    )
except ImportError:
    print("Error: parse_rawtx.py not found")
    sys.exit(1)

DATA_DIR = Path("data")


# ---------------------------------------------------------------------------
# Paths & conversion helpers
# ---------------------------------------------------------------------------
def safe_addr(a):
    return (a or 'unknown').replace(':', '_').replace('/', '_').replace('\\', '_')


def per_addr_csv(addr):
    return DATA_DIR / f"signatures_{safe_addr(addr)}.csv"


def per_addr_csv_dec(addr):
    return DATA_DIR / f"signatures_{safe_addr(addr)}_decimal.csv"


def hex_to_dec(val):
    """Convert a hex string (with or without 0x prefix) to decimal string."""
    if val is None or val == '':
        return val
    s = str(val)
    if s in ('(P2PK)',):
        return s
    try:
        if s.startswith(('0x', '0X')):
            return str(int(s, 16))
        return str(int(s, 16))
    except (ValueError, TypeError):
        return s


def to_decimal_rows(hex_rows):
    """Return a copy of hex_rows with r, s, z converted to decimal strings."""
    dec_rows = []
    for row in hex_rows:
        r = dict(row)
        for fld in ('r', 's', 'z'):
            if fld in r:
                r[fld] = hex_to_dec(r[fld])
        dec_rows.append(r)
    return dec_rows


def derive_output_dec_path(output_csv):
    p = Path(output_csv)
    return p.with_name(p.stem + "_decimal" + p.suffix)


# ---------------------------------------------------------------------------
# Input signature extraction
# ---------------------------------------------------------------------------
def _process_input(tx, raw_hex, idx, inp, prevout_map):
    is_segwit_input = (
        tx['is_segwit'] and tx.get('witnesses')
        and idx < len(tx['witnesses']) and tx['witnesses'][idx]
    )
    if is_segwit_input:
        try:
            der_sig, pubkey, shtype = parse_witness_signature(tx['witnesses'][idx])
            kind = 'P2WPKH'
        except Exception as e:
            print(f"    Input {idx}: witness parse error - {e}")
            return None
    else:
        if not inp['script_sig']:
            return None
        try:
            der_sig, pubkey, shtype = parse_script_sig(inp['script_sig'])
            kind = 'P2PKH' if pubkey else 'P2PK'
        except Exception as e:
            print(f"    Input {idx}: scriptSig parse error - {e}")
            return None

    try:
        r, s = parse_der_signature(der_sig)
    except Exception as e:
        print(f"    Input {idx}: DER error - {e}")
        return None

    prev = prevout_map.get(idx, {})
    spk = prev.get('scriptpubkey', '')
    val = prev.get('value')

    z_hex = "00" * 32
    z_dec = "0"
    if spk:
        try:
            if is_segwit_input and val is not None:
                z_bytes = calculate_sighash_segwit_v0(raw_hex, idx, val, spk, shtype)
            else:
                z_bytes = calculate_sighash_legacy(raw_hex, idx, spk, shtype)
            z_hex = z_bytes.hex()
            z_dec = str(int.from_bytes(z_bytes, 'big'))
        except Exception as e:
            print(f"    Input {idx}: sighash error - {e}")

    return {
        'input_index': idx,
        'prev_txid': inp['prev_txid'],
        'prevout': inp['prevout'],
        'sequence': inp['sequence'],
        'type': kind,
        'der_signature': der_sig.hex(),
        'r': hex(r),
        's': hex(s),
        'low_s': s <= SECP256K1_HALF_N,
        'z': z_hex,
        'sighash_type': shtype,
        'pubkey': pubkey.hex() if pubkey else '(P2PK)',
        'script_sig': inp['script_sig'].hex(),
        # convenience fields, kept even if we later normalise:
        '_r_dec': str(r),
        '_s_dec': str(s),
        '_z_dec': z_dec,
    }


def parse_tx_group(tx_list, address):
    rows = []
    for i, tx_data in enumerate(tx_list, 1):
        txid = tx_data.get('txid', '?')
        raw_hex = tx_data.get('raw_hex', '')
        if not raw_hex:
            print(f"  [{i}/{len(tx_list)}] {txid}: no raw_hex, skip")
            continue
        print(f"  [{i}/{len(tx_list)}] {txid}")
        try:
            tx = parse_raw_transaction(raw_hex)
        except Exception as e:
            print(f"    tx parse error: {e}")
            continue
        prevout_map = {p.get('input_index'): p
                       for p in tx_data.get('prevout_data', [])
                       if 'input_index' in p}
        for idx, inp in enumerate(tx['inputs']):
            row = _process_input(tx, raw_hex, idx, inp, prevout_map)
            if row is None:
                continue
            row['txid'] = txid
            row['address'] = address

            # Strip internal decimal helpers — they're derived on write
            r_dec = row.pop('_r_dec', None)
            s_dec = row.pop('_s_dec', None)
            z_dec = row.pop('_z_dec', None)

            rows.append(row)
            flag = '  ⚠ high-S' if not row['low_s'] else ''
            print(f"    input {idx} ({row['type']}): "
                  f"r={row['r'][:16]}…  r_dec={str(r_dec)[:16]}…{flag}")
    return rows


# ---------------------------------------------------------------------------
# CSV I/O
# ---------------------------------------------------------------------------
def write_csv(rows, path):
    if not rows:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def write_both(rows, hex_path, dec_path):
    """Write identical-structure hex and decimal CSVs."""
    write_csv(rows, hex_path)
    write_csv(to_decimal_rows(rows), dec_path)


def read_csv(path):
    with open(path) as f:
        return list(csv.DictReader(f))


def load_txs(path):
    path = Path(path)
    grouped = defaultdict(list)

    if path.is_dir():
        files = sorted(path.glob("input_txs_*.json"))
        print(f"Found {len(files)} per-address files in {path}/")
        for fp in files:
            try:
                with open(fp) as f:
                    data = json.load(f)
            except Exception as e:
                print(f"  skip {fp.name}: {e}")
                continue
            for tx in data:
                grouped[tx.get('address', '')].append(tx)
    else:
        with open(path) as f:
            data = json.load(f)
        if not isinstance(data, list):
            print("Error: JSON must be an array")
            return grouped
        for tx in data:
            grouped[tx.get('address', '')].append(tx)

    return grouped


# ---------------------------------------------------------------------------
# Nonce reuse check
# ---------------------------------------------------------------------------
def check_nonce_reuse(rows):
    groups = defaultdict(list)
    for r in rows:
        groups[r['r']].append(r)
    dupes = {r: rs for r, rs in groups.items() if len(rs) > 1}

    print("\n" + "=" * 60)
    print("Nonce Reuse Check")
    print("=" * 60)
    if not dupes:
        print(f"✅ No nonce reuse ({len(groups)} unique r values)")
        return
    print(f"⚠️  NONCE REUSE: {len(dupes)} duplicate r value(s)\n")
    for r_hex, sigs in dupes.items():
        r_dec = hex_to_dec(r_hex)
        print(f"  r (hex) = {r_hex}")
        print(f"  r (dec) = {r_dec}")
        for s in sigs:
            print(f"    • {s['address']} | {s['txid'][:20]}… input {s['input_index']}")
        print()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    args = sys.argv[1:]
    if not args or any(a in ('-h', '--help') for a in args):
        print(__doc__)
        sys.exit(0)

    force = '--force' in args
    args = [a for a in args if a != '--force']

    input_path = args[0]
    output_csv = args[1] if len(args) > 1 else "signatures.csv"
    output_csv_dec = derive_output_dec_path(output_csv)

    DATA_DIR.mkdir(exist_ok=True)

    print("=" * 60)
    print("Batch Signature Parser — per-address hex + decimal")
    print("=" * 60)

    grouped = load_txs(input_path)
    if not grouped:
        print("No transactions found.")
        sys.exit(1)

    total_addrs = len(grouped)
    print(f"\nAddresses to process: {total_addrs}")

    all_rows = []
    per_addr_counts = {}

    for i, (address, txs) in enumerate(grouped.items(), 1):
        print("\n" + "=" * 60)
        print(f"[{i}/{total_addrs}] {address or '(unknown)'}  ({len(txs)} txs)")
        print("=" * 60)

        hex_path = per_addr_csv(address)
        dec_path = per_addr_csv_dec(address)

        # ---- Resume from cache ----
        if hex_path.exists() and not force:
            try:
                cached_hex = read_csv(hex_path)
                print(f"  ✓ Cached: {len(cached_hex)} sigs from {hex_path}")

                # Restore typed fields for downstream consumers
                for row in cached_hex:
                    row['low_s'] = row['low_s'] in ('True', 'true', '1')
                    row['input_index'] = int(row['input_index'])
                    row['sighash_type'] = int(row['sighash_type'])

                # Ensure decimal variant exists
                if not dec_path.exists():
                    write_csv(to_decimal_rows(cached_hex), dec_path)
                    print(f"  ✓ Regenerated decimal: {dec_path}")

                all_rows.extend(cached_hex)
                per_addr_counts[address] = len(cached_hex)
                continue
            except Exception as e:
                print(f"  cache read failed ({e}); re-parsing")

        # ---- Fresh parse ----
        rows = parse_tx_group(txs, address)
        write_both(rows, hex_path, dec_path)
        print(f"  ✓ Saved {len(rows)} sigs →")
        print(f"      {hex_path}")
        print(f"      {dec_path}")

        per_addr_counts[address] = len(rows)
        all_rows.extend(rows)

    if not all_rows:
        print("\nNo signatures extracted.")
        sys.exit(1)

    # ---- Combined outputs ----
    write_both(all_rows, output_csv, output_csv_dec)
    print(f"\n✓ Combined hex:     {output_csv}  ({len(all_rows)} rows)")
    print(f"✓ Combined decimal: {output_csv_dec}  ({len(all_rows)} rows)")

    check_nonce_reuse(all_rows)

    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)
    print(f"Addresses:          {total_addrs}")
    print(f"Signatures:         {len(all_rows)}")
    print(f"High-S (malleable): {sum(1 for r in all_rows if not r.get('low_s', True))}")
    print(f"Combined hex:       {output_csv}")
    print(f"Combined decimal:   {output_csv_dec}")
    print(f"Per-address:        {DATA_DIR}/")
    print("\nPer-address:")
    for a, n in per_addr_counts.items():
        print(f"  {a or '(unknown)'}: {n}")
    print("\nDone!")


if __name__ == "__main__":
    main()