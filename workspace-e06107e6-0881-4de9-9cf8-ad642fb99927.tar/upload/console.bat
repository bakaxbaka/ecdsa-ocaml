@echo off
REM Menu for the ECDSA signature analysis pipeline.
setlocal enabledelayedexpansion
cd /d "%~dp0"

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Python not found in PATH.
    pause & exit /b 1
)

:menu
cls
echo ============================================================
echo   Bitcoin ECDSA Signature Analysis Pipeline
echo ============================================================
echo.
echo   1. Fetch input transactions        (address.txt, resumable)
echo   2. Parse signatures                (data/, resumable)
echo   3. Run full pipeline               (1 then 2)
echo   4. Custom single address           (fetch + parse)
echo   5. Force re-fetch all addresses    (--force)
echo   6. Force re-parse all signatures   (--force)
echo   7. Clean data/ checkpoint          (delete fetched/parsed)
echo   8. Exit
echo.
set /p choice="Choice [1-8]: "

if "!choice!"=="1" goto fetch
if "!choice!"=="2" goto parse
if "!choice!"=="3" goto full
if "!choice!"=="4" goto custom
if "!choice!"=="5" goto fetch_force
if "!choice!"=="6" goto parse_force
if "!choice!"=="7" goto clean
if "!choice!"=="8" goto end
echo Invalid choice. & pause & goto menu

:fetch
python fetch_address_inputs.py
pause & goto menu

:parse
if exist "data" (
    python batch_parse_address_txs.py data/ signatures.csv
) else if exist "input_txs_all.json" (
    python batch_parse_address_txs.py input_txs_all.json signatures.csv
) else (
    echo Nothing to parse. Run option 1 first.
)
pause & goto menu

:full
echo === Fetching ===
python fetch_address_inputs.py
if errorlevel 1 ( echo Fetch failed. & pause & goto menu )
echo.
echo === Parsing ===
if exist "data" (
    python batch_parse_address_txs.py data/ signatures.csv
) else (
    python batch_parse_address_txs.py input_txs_all.json signatures.csv
)
pause & goto menu

:fetch_force
python fetch_address_inputs.py --force
pause & goto menu

:parse_force
if exist "data" (
    python batch_parse_address_txs.py data/ signatures.csv --force
) else if exist "input_txs_all.json" (
    python batch_parse_address_txs.py input_txs_all.json signatures.csv --force
)
pause & goto menu

:custom
set /p addr="Address: "
if "!addr!"=="" ( pause & goto menu )
python fetch_address_inputs.py !addr!
if errorlevel 1 ( pause & goto menu )
python batch_parse_address_txs.py data/
pause & goto menu

:clean
echo This deletes data/ (all per-address fetch + parse results).
set /p confirm="Type YES to confirm: "
if /i "!confirm!"=="YES" (
    if exist "data" rmdir /s /q "data"
    echo Cleaned.
) else (
    echo Cancelled.
)
pause & goto menu

:end
endlocal