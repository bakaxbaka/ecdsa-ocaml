// ============================================================================
// Bitcoin ECDSA Signature Analysis Pipeline — shared data contract.
// Mirrors the frozen socket.io contract in /home/z/my-project/worklog.md.
// ============================================================================

/** Script/address type that produced the signature. */
export type SignatureType = "P2PKH" | "P2PK" | "P2WPKH";

/** A single parsed ECDSA signature from a transaction input. */
export interface Signature {
  address: string;
  txid: string;
  input_index: number;
  prev_txid: string;
  prevout: number;
  sequence: number;
  type: SignatureType;
  /** Full DER-encoded signature, hex (includes sighash byte). */
  der_signature: string;
  /** r value, hex (no 0x prefix). */
  r: string;
  /** s value, hex (no 0x prefix). */
  s: string;
  /** Whether s is in low-S form (BIP-62). */
  low_s: boolean;
  /** Sighash z value, hex. */
  z: string;
  /** Sighash type byte (0x01 ALL, 0x02 NONE, 0x03 SINGLE, 0x81 ANYONECANPAY|ALL ...). */
  sighash_type: number;
  /** Public key that signed, hex (compressed or uncompressed). */
  pubkey: string;
}

/** Kind of vulnerability detected. */
export type VulnType = "nonce_reuse" | "high_s" | "weak_nonce";

/** Severity of a vulnerability. */
export type Severity = "critical" | "medium" | "low";

/** A detected vulnerability / security finding. */
export interface Vulnerability {
  id: string;
  type: VulnType;
  severity: Severity;
  title: string;
  description: string;
  address?: string;
  signatures: Signature[];
  /** Recovered private key, hex (present for nonce_reuse). */
  recovered_private_key?: string;
  /** Recovered nonce k, hex (present for nonce_reuse). */
  recovered_nonce?: string;
}

/** Aggregate counts emitted at pipeline completion. */
export interface PipelineSummary {
  addresses: number;
  transactions: number;
  signatures: number;
  vulnerabilities: number;
  nonce_reuse_count: number;
  high_s_count: number;
  weak_nonce_count: number;
  keys_recovered: number;
}

/** Pipeline phase reported by progress events. */
export type PipelinePhase =
  | "idle"
  | "fetching"
  | "parsing"
  | "detecting"
  | "complete"
  | "error";

/** `pipeline:progress` payload. */
export interface ProgressEvent {
  jobId: string;
  phase: PipelinePhase;
  address?: string;
  message: string;
  current: number;
  total: number;
}

/** Options sent with `pipeline:start`. */
export interface PipelineOptions {
  forceRefetch: boolean;
  apiSource: "auto" | "mempool.space" | "blockstream.info";
}

// ---------------------------------------------------------------------------
// Socket event payload types (for type-safe emit/on handlers).
// ---------------------------------------------------------------------------

export interface PipelineStartPayload {
  jobId: string;
  addresses: string[];
  options: PipelineOptions;
}

export interface PipelineCancelPayload {
  jobId: string;
}

export interface PipelineSignatureEvent {
  jobId: string;
  signature: Signature;
}

export interface PipelineVulnerabilityEvent {
  jobId: string;
  vulnerability: Vulnerability;
}

export interface PipelineCompleteEvent {
  jobId: string;
  signatures: Signature[];
  vulnerabilities: Vulnerability[];
  summary: PipelineSummary;
}

export interface PipelineErrorEvent {
  jobId: string;
  error: string;
}

/** A single line in the live activity log. */
export interface ActivityLogEntry {
  id: string;
  timestamp: number;
  phase: PipelinePhase;
  address?: string;
  message: string;
  current: number;
  total: number;
}
