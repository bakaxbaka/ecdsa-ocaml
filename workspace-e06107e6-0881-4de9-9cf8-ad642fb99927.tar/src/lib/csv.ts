// ============================================================================
// CSV / JSON export helpers for pipeline results.
// All values are emitted in FULL — no truncation, no cell-width limits.
// ============================================================================

import { formatValue, type ValueBase } from "@/lib/convert";
import type { Signature, Vulnerability } from "@/lib/pipeline-types";

/** Quote a CSV cell per RFC 4180: wrap in quotes if it contains comma/quote/newline. */
function csvCell(value: string | number | boolean | undefined | null): string {
  if (value === undefined || value === null) return "";
  const s = String(value);
  if (/[",\n\r]/.test(s)) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

/** Build a CSV row from an array of cell values. */
function csvRow(cells: Array<string | number | boolean | undefined | null>): string {
  return cells.map(csvCell).join(",");
}

/**
 * Convert signatures to a CSV string. r/s/z are formatted in the requested
 * base (hex is canonical storage; dec/bin are derived via BigInt).
 */
export function signaturesToCsv(signatures: Signature[], base: ValueBase): string {
  const header = [
    "index",
    "address",
    "txid",
    "input_index",
    "prev_txid",
    "prevout",
    "sequence",
    "type",
    "der_signature",
    "r",
    "s",
    "low_s",
    "z",
    "sighash_type",
    "pubkey",
  ];
  const rows = signatures.map((sig, i) =>
    csvRow([
      i + 1,
      sig.address,
      sig.txid,
      sig.input_index,
      sig.prev_txid,
      sig.prevout,
      sig.sequence,
      sig.type,
      sig.der_signature,
      formatValue(sig.r, base),
      formatValue(sig.s, base),
      sig.low_s,
      formatValue(sig.z, base),
      sig.sighash_type,
      sig.pubkey,
    ]),
  );
  return [csvRow(header), ...rows].join("\n");
}

/** Convert vulnerabilities to a CSV string (one row per vulnerability). */
export function vulnerabilitiesToCsv(vulns: Vulnerability[]): string {
  const header = [
    "id",
    "type",
    "severity",
    "title",
    "address",
    "recovered_private_key",
    "recovered_nonce",
    "signature_count",
    "signature_txids",
    "description",
  ];
  const rows = vulns.map((v) =>
    csvRow([
      v.id,
      v.type,
      v.severity,
      v.title,
      v.address ?? "",
      v.recovered_private_key ?? "",
      v.recovered_nonce ?? "",
      v.signatures.length,
      v.signatures.map((s) => `${s.txid}:${s.input_index}`).join(" | "),
      v.description,
    ]),
  );
  return [csvRow(header), ...rows].join("\n");
}

/** Serialize the full result set (signatures + vulnerabilities) as pretty JSON. */
export function resultsToJson(signatures: Signature[], vulns: Vulnerability[]): string {
  return JSON.stringify({ signatures, vulnerabilities: vulns }, null, 2);
}

/**
 * Trigger a client-side download of `content` as a file. Uses a Blob + an
 * ephemeral <a> element; revokes the object URL afterwards.
 */
export function downloadFile(filename: string, content: string, mime: string): void {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  // Defer revoke slightly so the click has a chance to register in all browsers.
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
