// ============================================================================
// Base-conversion utilities for 256-bit (and larger) integers.
//
// All canonical values are stored as hex (no "0x" prefix, lowercase). These
// helpers convert between hex / decimal / binary using BigInt so they handle
// full secp256k1-sized values (and beyond) without precision loss.
//
// IMPORTANT: Nothing here truncates. Binary strings for a 256-bit value are
// 256 characters long; we group them into bytes with spaces for readability
// but the full value is always returned.
// ============================================================================

export type ValueBase = "hex" | "dec" | "bin";

/** Strip an optional "0x"/"0X" prefix and lowercase. */
export function normalizeHex(hex: string): string {
  if (typeof hex !== "string") return "";
  const trimmed = hex.trim();
  const stripped = trimmed.toLowerCase().startsWith("0x")
    ? trimmed.slice(2)
    : trimmed;
  return stripped.toLowerCase();
}

/** Parse a hex string into a BigInt. Returns BigInt(0) for empty/invalid input. */
export function hexToBigInt(hex: string): bigint {
  const clean = normalizeHex(hex);
  if (clean === "") return BigInt(0);
  // BigInt('0x...') accepts hex; guard against stray non-hex chars.
  if (!/^[0-9a-f]+$/.test(clean)) return BigInt(0);
  return BigInt("0x" + clean);
}

/** Parse a decimal string into a BigInt. Returns BigInt(0) for empty/invalid input. */
export function decToBigInt(dec: string): bigint {
  if (typeof dec !== "string") return BigInt(0);
  const clean = dec.trim();
  if (clean === "") return BigInt(0);
  if (!/^-?\d+$/.test(clean)) return BigInt(0);
  return BigInt(clean);
}

/** hex -> decimal string (full precision). */
export function hexToDec(hex: string): string {
  return hexToBigInt(hex).toString(10);
}

/** decimal string -> hex string (no 0x prefix, lowercase). */
export function decToHex(dec: string): string {
  return decToBigInt(dec).toString(16);
}

/** BigInt -> hex string (no 0x prefix, lowercase). */
export function bigIntToHex(n: bigint): string {
  if (n < BigInt(0)) {
    // Two's-complement is out of scope for ECDSA scalars; show magnitude.
    return "-" + (-n).toString(16);
  }
  return n.toString(16);
}

/** BigInt -> binary string, grouped into bytes with spaces. */
export function bigIntToBin(n: bigint): string {
  const isNegative = n < BigInt(0);
  const mag = isNegative ? -n : n;
  if (mag === BigInt(0)) return "00000000";
  const bits = mag.toString(2);
  // Pad to a whole number of bytes.
  const padLen = Math.ceil(bits.length / 8) * 8;
  const padded = bits.padStart(padLen, "0");
  // Group into bytes (8 chars) separated by a space.
  const bytes: string[] = [];
  for (let i = 0; i < padded.length; i += 8) {
    bytes.push(padded.slice(i, i + 8));
  }
  const out = bytes.join(" ");
  return isNegative ? "- " + out : out;
}

/** hex -> binary string (grouped into bytes with spaces). */
export function hexToBin(hex: string): string {
  return bigIntToBin(hexToBigInt(hex));
}

/** decimal string -> binary string (grouped into bytes with spaces). */
export function decToBin(dec: string): string {
  return bigIntToBin(decToBigInt(dec));
}

/**
 * Main entry point used by the UI: given a canonical hex value, render it in
 * the requested base. Never truncates — binary output for a 256-bit scalar is
 * a ~70-char string, decimal is ~77 chars; both wrap naturally in the DOM.
 */
export function formatValue(hexValue: string, base: ValueBase): string {
  switch (base) {
    case "hex":
      return normalizeHex(hexValue);
    case "dec":
      return hexToDec(hexValue);
    case "bin":
      return hexToBin(hexValue);
    default:
      return normalizeHex(hexValue);
  }
}

/** Human-readable label for a base (used in UI labels/CSV headers). */
export function baseLabel(base: ValueBase): string {
  switch (base) {
    case "hex":
      return "Hex";
    case "dec":
      return "Decimal";
    case "bin":
      return "Binary";
    default:
      return "Hex";
  }
}

/** Short hint text describing how a value is encoded. */
export function baseHint(base: ValueBase): string {
  switch (base) {
    case "hex":
      return "base-16, lowercase, no 0x prefix";
    case "dec":
      return "base-10, full precision (BigInt)";
    case "bin":
      return "base-2, grouped 8 bits per byte";
    default:
      return "";
  }
}
