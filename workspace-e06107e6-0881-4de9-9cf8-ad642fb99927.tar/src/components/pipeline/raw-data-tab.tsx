"use client";

import { useMemo, useState } from "react";
import { Braces, Copy, Check } from "lucide-react";

import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { resultsToJson } from "@/lib/csv";
import type { Signature, Vulnerability } from "@/lib/pipeline-types";

interface RawDataTabProps {
  signatures: Signature[];
  vulnerabilities: Vulnerability[];
}

export function RawDataTab({ signatures, vulnerabilities }: RawDataTabProps) {
  const [copied, setCopied] = useState(false);

  const json = useMemo(
    () => resultsToJson(signatures, vulnerabilities),
    [signatures, vulnerabilities],
  );

  const handleCopy = () => {
    navigator.clipboard
      .writeText(json)
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 1200);
      })
      .catch(() => undefined);
  };

  const isEmpty = signatures.length === 0 && vulnerabilities.length === 0;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-[11px] text-muted-foreground">
          Full JSON dump of {signatures.length} signatures and {vulnerabilities.length} vulnerabilities. Nothing is truncated.
        </p>
        <Button
          variant="outline"
          size="sm"
          onClick={handleCopy}
          disabled={isEmpty}
          className="gap-1.5 text-xs"
        >
          {copied ? <Check className="size-3.5 text-emerald-500" /> : <Copy className="size-3.5" />}
          {copied ? "Copied" : "Copy JSON"}
        </Button>
      </div>

      {isEmpty ? (
        <div className="flex flex-col items-center justify-center gap-2 rounded-md border border-dashed py-16 text-center text-muted-foreground">
          <Braces className="size-6 opacity-40" />
          <p className="text-sm">No data yet</p>
          <p className="text-xs">Run the pipeline to populate this view.</p>
        </div>
      ) : (
        <div className="rounded-md border bg-muted/20">
          <ScrollArea className="pipeline-scroll h-[600px] w-full">
            <pre className="p-3">
              <code
                className={cn(
                  "block font-mono text-[11px] leading-relaxed break-all whitespace-pre-wrap text-foreground/90",
                )}
              >
                {json}
              </code>
            </pre>
          </ScrollArea>
        </div>
      )}
    </div>
  );
}
