"use client";

import { useState } from "react";
import { AlertCircle, ChevronDown, KeyRound, RefreshCw, Wifi, WifiOff } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

interface HeaderProps {
  connected: boolean;
  onRetry: () => void;
}

const PHASES: Array<{ n: number; title: string; desc: string }> = [
  {
    n: 1,
    title: "Fetch",
    desc: "Query mempool.space / blockstream.info for the address's spending transactions and their raw hex.",
  },
  {
    n: 2,
    title: "Parse",
    desc: "Decode each raw transaction, locate ECDSA scriptSigs/witnesses, and extract r, s, z (sighash) and the public key.",
  },
  {
    n: 3,
    title: "Detect",
    desc: "Scan for nonce reuse (same r across signatures → private-key recovery), high-S malleability, and weak nonces.",
  },
  {
    n: 4,
    title: "Report",
    desc: "Stream signatures and vulnerabilities live to this UI; emit a final summary with recovered keys.",
  },
];

export function Header({ connected, onRetry }: HeaderProps) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 py-3">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3 min-w-0">
            <div className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg bg-orange-500/15 text-orange-500 ring-1 ring-orange-500/30">
              <KeyRound className="size-5" />
            </div>
            <div className="min-w-0">
              <h1 className="text-lg font-semibold leading-tight tracking-tight sm:text-xl">
                Bitcoin ECDSA Signature Analyzer
              </h1>
              <p className="text-xs text-muted-foreground sm:text-sm">
                Automated pipeline: fetch spending txs → parse r/s/z → detect nonce-reuse &amp; private-key recovery.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {connected ? (
              <Badge className="border-emerald-500/30 bg-emerald-500/15 text-emerald-500">
                <Wifi className="size-3" />
                Pipeline online
              </Badge>
            ) : (
              <Badge
                variant="destructive"
                className="cursor-default"
                title="The pipeline mini-service is unreachable."
              >
                <WifiOff className="size-3" />
                Offline
              </Badge>
            )}
            {!connected && (
              <Button
                variant="outline"
                size="sm"
                onClick={onRetry}
                className="h-7 gap-1.5 text-xs"
              >
                <RefreshCw className="size-3.5" />
                Retry
              </Button>
            )}
            <Collapsible open={open} onOpenChange={setOpen}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="h-7 gap-1.5 text-xs">
                  How it works
                  <ChevronDown
                    className={`size-3.5 transition-transform ${open ? "rotate-180" : ""}`}
                  />
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="absolute right-4 top-full z-50 mt-2 w-[min(92vw,30rem)] origin-top rounded-lg border bg-popover p-3 text-popover-foreground shadow-lg">
                <p className="mb-2 text-xs font-medium text-muted-foreground">
                  The pipeline runs in 4 phases:
                </p>
                <ol className="space-y-2">
                  {PHASES.map((p) => (
                    <li key={p.n} className="flex gap-2.5">
                      <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-orange-500/15 text-[11px] font-semibold text-orange-500 ring-1 ring-orange-500/30">
                        {p.n}
                      </span>
                      <div>
                        <div className="text-xs font-medium">{p.title}</div>
                        <div className="text-[11px] leading-relaxed text-muted-foreground">
                          {p.desc}
                        </div>
                      </div>
                    </li>
                  ))}
                </ol>
                <div className="mt-3 flex items-start gap-1.5 rounded-md border border-amber-500/30 bg-amber-500/10 p-2 text-[11px] text-amber-600 dark:text-amber-400">
                  <AlertCircle className="mt-px size-3.5 shrink-0" />
                  <span>
                    Educational &amp; security-research use only. Never spend from
                    or import a recovered private key that you do not own.
                  </span>
                </div>
              </CollapsibleContent>
            </Collapsible>
          </div>
        </div>
      </div>
    </header>
  );
}
