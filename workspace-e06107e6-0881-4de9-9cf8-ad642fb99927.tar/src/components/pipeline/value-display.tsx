"use client";

// ============================================================================
// value-display.tsx — reusable components for rendering hex/dec/bin values.
//
// HARD RULE: values are NEVER truncated. Long values render in full and wrap
// via break-all; very long values sit inside a ScrollArea so the user can
// scroll within the cell while the full value remains accessible.
// ============================================================================

import { Check, Copy } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { baseHint, baseLabel, formatValue, type ValueBase } from "@/lib/convert";

/** Copy text to the clipboard with a sonner toast confirmation. */
export function copyText(text: string, label?: string): void {
  if (!text) {
    toast.error("Nothing to copy");
    return;
  }
  navigator.clipboard
    .writeText(text)
    .then(() => {
      toast.success(label ? `${label} copied` : "Copied to clipboard", {
        description: "Full value copied to clipboard.",
      });
    })
    .catch(() => {
      toast.error("Copy failed", {
        description: "Clipboard access was denied by the browser.",
      });
    });
}

interface CopyButtonProps {
  value: string;
  label?: string;
  className?: string;
  size?: "default" | "sm" | "icon" | "lg";
  variant?: "default" | "secondary" | "outline" | "ghost" | "destructive" | "link";
}

/** Small icon button that copies a value and shows a check briefly. */
export function CopyButton({
  value,
  label,
  className,
  size = "icon",
  variant = "ghost",
}: CopyButtonProps) {
  const [copied, setCopied] = useState(false);
  const handle = () => {
    copyText(value, label);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  };
  return (
    <Button
      type="button"
      variant={variant}
      size={size}
      onClick={handle}
      className={cn("h-6 w-6 shrink-0", className)}
      title={label ? `Copy ${label}` : "Copy"}
      aria-label={label ? `Copy ${label}` : "Copy value"}
    >
      {copied ? <Check className="size-3.5 text-emerald-500" /> : <Copy className="size-3.5" />}
    </Button>
  );
}

interface ValueDisplayProps {
  /** Canonical hex value (no 0x prefix). */
  hexValue: string;
  base: ValueBase;
  /** Restrict rendered width and allow internal scroll for very long values. */
  scrollable?: boolean;
  /** Max height when scrollable. */
  maxHeight?: string;
  className?: string;
  showCopy?: boolean;
  /** Optional label prefix for copy toast. */
  label?: string;
}

/**
 * Render a single value in the chosen base, in full, with an optional copy
 * button. For long binary/decimal strings, set `scrollable` so the value sits
 * in a ScrollArea (still fully present, just scrollable).
 */
export function ValueDisplay({
  hexValue,
  base,
  scrollable = false,
  maxHeight = "120px",
  className,
  showCopy = true,
  label,
}: ValueDisplayProps) {
  const rendered = formatValue(hexValue, base);
  const codeEl = (
    <code
      className={cn(
        "block font-mono text-xs break-all leading-relaxed text-foreground",
        className,
      )}
    >
      {rendered || "—"}
    </code>
  );

  return (
    <div className="flex items-start gap-1.5">
      <div className="min-w-0 flex-1">
        {scrollable ? (
          <ScrollArea
            className={cn("rounded border bg-muted/30 px-2 py-1.5", className)}
            style={{ maxHeight }}
          >
            {codeEl}
          </ScrollArea>
        ) : (
          codeEl
        )}
      </div>
      {showCopy && (
        <CopyButton value={rendered} label={label ?? `${baseLabel(base)} value`} />
      )}
    </div>
  );
}

interface ValueAllBasesProps {
  hexValue: string;
  label?: string;
}

/**
 * Render a single hex value in all three bases (hex / dec / bin) side by side,
 * each in full with its own copy button. Used in the signature detail Sheet
 * and on vulnerability cards so the user can really see the conversions.
 */
export function ValueAllBases({ hexValue, label }: ValueAllBasesProps) {
  const bases: ValueBase[] = ["hex", "dec", "bin"];
  return (
    <div className="space-y-2">
      {bases.map((b) => (
        <div key={b} className="rounded-md border bg-muted/20 p-2">
          <div className="mb-1 flex items-center justify-between gap-2">
            <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
              {baseLabel(b)} <span className="normal-case font-normal text-muted-foreground/70">— {baseHint(b)}</span>
            </span>
            <CopyButton value={formatValue(hexValue, b)} label={`${label ? label + " " : ""}${baseLabel(b)}`} />
          </div>
          <ScrollArea className="max-h-40 rounded bg-background/40">
            <code className="block font-mono text-xs break-all leading-relaxed p-1">
              {formatValue(hexValue, b) || "—"}
            </code>
          </ScrollArea>
        </div>
      ))}
    </div>
  );
}
