"use client";

import { useMemo } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  KeyRound,
  ShieldAlert,
  ShieldX,
} from "lucide-react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import type { Severity, Signature, Vulnerability, VulnType } from "@/lib/pipeline-types";
import { CopyButton, ValueDisplay } from "@/components/pipeline/value-display";

interface VulnerabilitiesTabProps {
  vulnerabilities: Vulnerability[];
}

const SEVERITY_ORDER: Record<Severity, number> = {
  critical: 0,
  medium: 1,
  low: 2,
};

const SEVERITY_BADGE: Record<Severity, string> = {
  critical: "border-destructive/40 bg-destructive/15 text-destructive",
  medium: "border-orange-500/30 bg-orange-500/15 text-orange-500",
  low: "border-zinc-500/30 bg-zinc-500/15 text-zinc-400",
};

const SEVERITY_LABEL: Record<Severity, string> = {
  critical: "Critical",
  medium: "Medium",
  low: "Low",
};

const TYPE_LABEL: Record<VulnType, string> = {
  nonce_reuse: "Nonce reuse",
  high_s: "High-S",
  weak_nonce: "Weak nonce",
};

const TYPE_BADGE: Record<VulnType, string> = {
  nonce_reuse: "border-emerald-500/30 bg-emerald-500/10 text-emerald-500",
  high_s: "border-orange-500/30 bg-orange-500/10 text-orange-500",
  weak_nonce: "border-amber-500/30 bg-amber-500/10 text-amber-500",
};

function InvolvedSignatures({ signatures }: { signatures: Signature[] }) {
  if (!signatures || signatures.length === 0) return null;
  return (
    <div className="space-y-2">
      <h4 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        Involved signatures ({signatures.length})
      </h4>
      <div className="space-y-2">
        {signatures.map((sig, i) => (
          <div
            key={`${sig.txid}-${sig.input_index}-${i}`}
            className="rounded-md border bg-muted/20 p-2"
          >
            <div className="mb-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px]">
              <Badge variant="secondary" className="text-[10px]">{sig.type}</Badge>
              <span className="font-mono text-muted-foreground">
                #{sig.input_index}
              </span>
              <code className="break-all font-mono text-[11px] text-foreground/90">
                {sig.txid}
              </code>
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
              <div>
                <div className="mb-0.5 text-[10px] uppercase text-muted-foreground">r</div>
                <ValueDisplay hexValue={sig.r} base="hex" label="r" />
              </div>
              <div>
                <div className="mb-0.5 text-[10px] uppercase text-muted-foreground">s</div>
                <ValueDisplay hexValue={sig.s} base="hex" label="s" />
              </div>
              <div>
                <div className="mb-0.5 text-[10px] uppercase text-muted-foreground">z</div>
                <ValueDisplay hexValue={sig.z} base="hex" label="z" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function VulnerabilityCard({ vuln }: { vuln: Vulnerability }) {
  const hasKey = vuln.type === "nonce_reuse" && (vuln.recovered_private_key || vuln.recovered_nonce);
  return (
    <Card className={cn("overflow-hidden", vuln.severity === "critical" && "border-destructive/40")}>
      <CardHeader className="pb-3">
        <div className="flex flex-wrap items-center gap-2">
          <Badge className={cn("text-[10px] uppercase", SEVERITY_BADGE[vuln.severity])}>
            {vuln.severity === "critical" ? <ShieldX className="size-3" /> : <ShieldAlert className="size-3" />}
            {SEVERITY_LABEL[vuln.severity]}
          </Badge>
          <Badge className={cn("text-[10px]", TYPE_BADGE[vuln.type])}>
            {TYPE_LABEL[vuln.type]}
          </Badge>
          <h3 className="text-sm font-semibold">{vuln.title}</h3>
        </div>
        {vuln.address && (
          <p className="font-mono text-[11px] text-muted-foreground">
            address: <span className="text-orange-500">{vuln.address}</span>
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="break-words text-xs leading-relaxed text-muted-foreground">
          {vuln.description}
        </p>

        {hasKey && (
          <div className="space-y-3 rounded-lg border-2 border-emerald-500/40 bg-emerald-500/5 p-3">
            <div className="flex items-center gap-2">
              <KeyRound className="size-4 text-emerald-500" />
              <h4 className="text-xs font-semibold uppercase tracking-wide text-emerald-600 dark:text-emerald-400">
                Recovered secrets
              </h4>
            </div>

            <Alert className="border-amber-500/30 bg-amber-500/5">
              <AlertTriangle className="size-4 text-amber-500" />
              <AlertTitle className="text-amber-600 dark:text-amber-400">
                This key controls the on-chain funds
              </AlertTitle>
              <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                Anyone with this private key can sign transactions spending all
                current and future UTXOs of this address. Educational use only —
                never import a key you do not own.
              </AlertDescription>
            </Alert>

            {vuln.recovered_private_key && (
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                    Private key (d)
                  </span>
                  <CopyButton value={vuln.recovered_private_key} label="private key" />
                </div>
                <div className="rounded-md border bg-background/60 p-2">
                  <code className="block break-all font-mono text-sm text-emerald-600 dark:text-emerald-400">
                    {vuln.recovered_private_key}
                  </code>
                </div>
              </div>
            )}

            {vuln.recovered_nonce && (
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                    Nonce (k)
                  </span>
                  <CopyButton value={vuln.recovered_nonce} label="nonce k" />
                </div>
                <div className="rounded-md border bg-background/60 p-2">
                  <code className="block break-all font-mono text-sm text-emerald-600 dark:text-emerald-400">
                    {vuln.recovered_nonce}
                  </code>
                </div>
              </div>
            )}
          </div>
        )}

        <Separator />

        <InvolvedSignatures signatures={vuln.signatures ?? []} />
      </CardContent>
    </Card>
  );
}

export function VulnerabilitiesTab({ vulnerabilities }: VulnerabilitiesTabProps) {
  const sorted = useMemo(() => {
    return [...vulnerabilities].sort((a, b) => {
      const s = SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity];
      if (s !== 0) return s;
      // Critical nonce_reuse first within same severity.
      const t = (b.type === "nonce_reuse" ? 1 : 0) - (a.type === "nonce_reuse" ? 1 : 0);
      return t;
    });
  }, [vulnerabilities]);

  if (vulnerabilities.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 rounded-md border border-dashed py-16 text-center">
        <CheckCircle2 className="size-8 text-emerald-500" />
        <p className="text-sm font-medium">No vulnerabilities detected</p>
        <p className="max-w-md text-xs text-muted-foreground">
          No nonce reuse, high-S values, or weak nonces were found in the parsed
          signatures. The pipeline streams findings live as they are discovered.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-[11px] text-muted-foreground">
        {vulnerabilities.length} finding{vulnerabilities.length === 1 ? "" : "s"} —
        sorted by severity (critical first).
      </p>
      <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
        {sorted.map((v) => (
          <VulnerabilityCard key={v.id} vuln={v} />
        ))}
      </div>
    </div>
  );
}
