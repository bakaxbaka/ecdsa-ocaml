"use client";

import { useEffect, useRef } from "react";
import { Activity, Radio } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import type { ActivityLogEntry, PipelinePhase } from "@/lib/pipeline-types";

const PHASE_VARIANT: Record<PipelinePhase, string> = {
  idle: "bg-muted text-muted-foreground border-transparent",
  fetching: "bg-teal-500/15 text-teal-500 border-teal-500/30",
  parsing: "bg-violet-500/15 text-violet-400 border-violet-500/30",
  detecting: "bg-amber-500/15 text-amber-500 border-amber-500/30",
  complete: "bg-emerald-500/15 text-emerald-500 border-emerald-500/30",
  error: "bg-destructive/15 text-destructive border-destructive/30",
};

interface ActivityLogProps {
  activity: ActivityLogEntry[];
  running: boolean;
}

function fmtTime(ts: number): string {
  const d = new Date(ts);
  const h = String(d.getHours()).padStart(2, "0");
  const m = String(d.getMinutes()).padStart(2, "0");
  const s = String(d.getSeconds()).padStart(2, "0");
  const ms = String(d.getMilliseconds()).padStart(3, "0");
  return `${h}:${m}:${s}.${ms}`;
}

export function ActivityLog({ activity, running }: ActivityLogProps) {
  const endRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll to newest entry.
  useEffect(() => {
    if (endRef.current) {
      endRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [activity]);

  return (
    <Card className="flex h-full flex-col">
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle className="flex items-center gap-2 text-base">
          <Activity className="size-4 text-emerald-500" />
          Live activity log
        </CardTitle>
        {running ? (
          <span className="flex items-center gap-1.5 text-xs text-emerald-500">
            <span className="relative flex size-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500/70" />
              <span className="relative inline-flex size-2 rounded-full bg-emerald-500" />
            </span>
            live
          </span>
        ) : (
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Radio className="size-3.5" />
            idle
          </span>
        )}
      </CardHeader>
      <CardContent className="flex-1">
        <ScrollArea className="pipeline-scroll h-96 w-full rounded-md border bg-muted/20">
          <div className="p-2 font-mono text-[11px] leading-relaxed">
            {activity.length === 0 ? (
              <div className="flex h-96 flex-col items-center justify-center gap-1 text-muted-foreground">
                <Activity className="size-5 opacity-40" />
                <p className="text-xs">No activity yet.</p>
                <p className="text-[11px]">Run the pipeline to see live progress here.</p>
              </div>
            ) : (
              <ul className="space-y-1">
                {activity.map((entry) => (
                  <li
                    key={entry.id}
                    className="flex flex-col gap-0.5 rounded px-1.5 py-1 hover:bg-muted/40 sm:flex-row sm:items-start sm:gap-2"
                  >
                    <span className="shrink-0 text-muted-foreground/70">
                      {fmtTime(entry.timestamp)}
                    </span>
                    <Badge
                      className={cn(
                        "h-4 shrink-0 px-1.5 text-[9px] uppercase tracking-wide",
                        PHASE_VARIANT[entry.phase] ?? PHASE_VARIANT.idle,
                      )}
                    >
                      {entry.phase}
                    </Badge>
                    {entry.address && (
                      <code className="shrink-0 text-[10px] text-orange-500">
                        {entry.address}
                      </code>
                    )}
                    <span className="break-all text-foreground/90">
                      {entry.message}
                      {entry.total > 0 && (
                        <span className="ml-1 text-muted-foreground">
                          ({entry.current}/{entry.total})
                        </span>
                      )}
                    </span>
                  </li>
                ))}
              </ul>
            )}
            <div ref={endRef} />
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
