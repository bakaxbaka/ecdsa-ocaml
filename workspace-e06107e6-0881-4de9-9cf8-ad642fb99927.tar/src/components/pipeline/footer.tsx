"use client";

import { ShieldCheck, WifiOff } from "lucide-react";

interface FooterProps {
  connected: boolean;
}

export function Footer({ connected }: FooterProps) {
  return (
    <footer className="mt-auto border-t bg-background/80 backdrop-blur">
      <div className="container mx-auto flex flex-col items-start justify-between gap-1.5 px-4 py-3 text-[11px] text-muted-foreground sm:flex-row sm:items-center">
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="size-3.5 text-emerald-500" />
          <span>
            Bitcoin ECDSA Signature Analyzer — educational / security-research use only.
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <span>Pipeline service:</span>
          {connected ? (
            <span className="flex items-center gap-1 text-emerald-500">
              <span className="inline-block size-1.5 rounded-full bg-emerald-500" />
              online
            </span>
          ) : (
            <span className="flex items-center gap-1 text-destructive">
              <WifiOff className="size-3" />
              offline
            </span>
          )}
          <span className="text-muted-foreground/60">· port 3004</span>
        </div>
      </div>
    </footer>
  );
}
