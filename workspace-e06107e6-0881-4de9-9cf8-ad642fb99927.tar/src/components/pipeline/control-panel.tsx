"use client";

import { useState } from "react";
import { Eraser, Loader2, Play, Square } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import type { PipelineOptions, PipelinePhase, ProgressEvent } from "@/lib/pipeline-types";

const SAMPLE_ADDRESSES = [
  "1FvUkW8thcqG6HP7gAvAjcR52fR7CYodBx",
  "12ib7dApVFvg82TXKycWBNpN8kFyiAN1dr",
  "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
  "1HB5XMLmzFVj8ALj6mfBsbifRoD4miY36v",
  "1FeexV6bAHb8ybZwjQMdeJytQXAQr4qkAM",
  "bc1qgdjqv0av3q56jvd82tkdjpy7gdp9ut8tlqmgrpmv24sq90ecnvqqjwvw97",
  "19YqzU5Mi5nP3p7MsQz4LJj9yD7muWdb3N",
  "1DEP8i3QJCsomS4BSMY2RpU1macvEuZrbV",
].join("\n");

const DEFAULT_ADDRESSES = [
  "1FvUkW8thcqG6HP7gAvAjcR52fR7CYodBx",
  "12ib7dApVFvg82TXKycWBNpN8kFyiAN1dr",
  "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
].join("\n");

const PHASE_LABEL: Record<PipelinePhase, string> = {
  idle: "Idle",
  fetching: "Fetching",
  parsing: "Parsing",
  detecting: "Detecting",
  complete: "Complete",
  error: "Error",
};

interface ControlPanelProps {
  connected: boolean;
  running: boolean;
  phase: PipelinePhase;
  progress: ProgressEvent | null;
  onStart: (addresses: string[], options: PipelineOptions) => void;
  onCancel: () => void;
  onClear: () => void;
}

function parseAddresses(text: string): string[] {
  return text
    .split(/[\s,]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

export function ControlPanel({
  connected,
  running,
  phase,
  progress,
  onStart,
  onCancel,
  onClear,
}: ControlPanelProps) {
  const [text, setText] = useState<string>(DEFAULT_ADDRESSES);
  const [forceRefetch, setForceRefetch] = useState(false);
  const [apiSource, setApiSource] = useState<PipelineOptions["apiSource"]>("auto");

  const addresses = parseAddresses(text);
  const canRun = connected && !running && addresses.length > 0;

  const handleRun = () => {
    if (!canRun) return;
    onStart(addresses, { forceRefetch, apiSource });
  };

  const pct =
    progress && progress.total > 0
      ? Math.min(100, Math.round((progress.current / progress.total) * 100))
      : running
        ? 0
        : 100;

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Play className="size-4 text-emerald-500" />
          Control panel
        </CardTitle>
        <CardDescription>
          Enter Bitcoin addresses (one per line, or comma/space separated) and run the analysis pipeline.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="addresses" className="text-xs">
              Addresses{" "}
              <span className="text-muted-foreground">
                ({addresses.length} parsed)
              </span>
            </Label>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 px-2 text-[11px] text-orange-500 hover:text-orange-400"
              onClick={() => setText(SAMPLE_ADDRESSES)}
            >
              Load sample addresses
            </Button>
          </div>
          <Textarea
            id="addresses"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa&#10;bc1q..."
            rows={5}
            className="resize-y font-mono text-xs leading-relaxed"
            spellCheck={false}
          />
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <Switch
              id="force"
              checked={forceRefetch}
              onCheckedChange={setForceRefetch}
              disabled={running}
            />
            <Label htmlFor="force" className="text-xs">
              Force re-fetch
              <span className="block text-[11px] font-normal text-muted-foreground">
                Ignore cached transactions
              </span>
            </Label>
          </div>

          <div className="flex items-center gap-2">
            <Label htmlFor="api" className="text-xs">
              API source
            </Label>
            <Select
              value={apiSource}
              onValueChange={(v) => setApiSource(v as PipelineOptions["apiSource"])}
              disabled={running}
            >
              <SelectTrigger id="api" size="sm" className="h-8 w-[150px] text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">auto</SelectItem>
                <SelectItem value="mempool.space">mempool.space</SelectItem>
                <SelectItem value="blockstream.info">blockstream.info</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {!running ? (
            <Tooltip>
              <TooltipTrigger asChild>
                <span className="inline-flex">
                  <Button
                    onClick={handleRun}
                    disabled={!canRun}
                    className="gap-1.5 bg-emerald-600 text-white hover:bg-emerald-600/90"
                  >
                    <Play className="size-4" />
                    Run Pipeline
                  </Button>
                </span>
              </TooltipTrigger>
              {!connected && (
                <TooltipContent>Pipeline service offline</TooltipContent>
              )}
              {connected && addresses.length === 0 && (
                <TooltipContent>Add at least one address to run</TooltipContent>
              )}
            </Tooltip>
          ) : (
            <Button
              onClick={onCancel}
              variant="destructive"
              className="gap-1.5"
            >
              <Square className="size-4" />
              Cancel
            </Button>
          )}

          <Button
            variant="outline"
            onClick={onClear}
            disabled={running}
            className="gap-1.5"
          >
            <Eraser className="size-4" />
            Clear results
          </Button>
        </div>

        {(running || phase !== "idle" || progress) && (
          <div className="space-y-1.5 rounded-md border bg-muted/30 p-3">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 font-medium">
                {running && (
                  <Loader2 className="size-3.5 animate-spin text-emerald-500" />
                )}
                {PHASE_LABEL[phase] ?? "Idle"}
              </span>
              {progress && progress.total > 0 && (
                <span className="font-mono text-muted-foreground">
                  {progress.current}/{progress.total}
                </span>
              )}
            </div>
            <Progress value={pct} className={cn(running && "bg-emerald-600/20")} />
            {progress?.message && (
              <p className="break-all text-[11px] text-muted-foreground">
                {progress.message}
              </p>
            )}
            {progress?.address && (
              <p className="break-all font-mono text-[10px] text-muted-foreground/80">
                {progress.address}
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
