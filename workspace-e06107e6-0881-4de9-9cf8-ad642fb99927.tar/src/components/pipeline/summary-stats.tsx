"use client";

import { KeyRound, Signature as SignatureIcon, ShieldAlert, ShieldCheck, Users, Zap } from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { PipelineSummary } from "@/lib/pipeline-types";

interface SummaryStatsProps {
  summary: PipelineSummary | null;
  signatureCount: number;
  vulnerabilityCount: number;
}

interface StatDef {
  label: string;
  value: number;
  icon: LucideIcon;
  hint?: string;
  accent?: string;
  iconWrap?: string;
}

export function SummaryStats({ summary, signatureCount, vulnerabilityCount }: SummaryStatsProps) {
  const s = summary;
  const stats: StatDef[] = [
    {
      label: "Addresses",
      value: s?.addresses ?? 0,
      icon: Users,
      iconWrap: "text-foreground",
    },
    {
      label: "Transactions",
      value: s?.transactions ?? 0,
      icon: Zap,
      iconWrap: "text-foreground",
    },
    {
      label: "Signatures",
      value: s?.signatures ?? signatureCount,
      icon: SignatureIcon,
      iconWrap: "text-foreground",
    },
    {
      label: "Vulnerabilities",
      value: s?.vulnerabilities ?? vulnerabilityCount,
      icon: ShieldAlert,
      iconWrap: (s?.vulnerabilities ?? vulnerabilityCount) > 0 ? "text-amber-500" : "text-foreground",
    },
    {
      label: "Nonce reuse",
      value: s?.nonce_reuse_count ?? 0,
      hint: "critical",
      icon: ShieldAlert,
      iconWrap: (s?.nonce_reuse_count ?? 0) > 0 ? "text-destructive" : "text-foreground",
    },
    {
      label: "Keys recovered",
      value: s?.keys_recovered ?? 0,
      icon: KeyRound,
      accent: (s?.keys_recovered ?? 0) > 0 ? "border-emerald-500/40 bg-emerald-500/5" : undefined,
      iconWrap: (s?.keys_recovered ?? 0) > 0 ? "text-emerald-500" : "text-foreground",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
      {stats.map((st) => (
        <Card key={st.label} className={cn("overflow-hidden py-0", st.accent)}>
          <CardContent className="flex items-center gap-3 p-4">
            <div className={cn("flex size-9 shrink-0 items-center justify-center rounded-lg bg-muted", st.iconWrap)}>
              <st.icon className="size-5" />
            </div>
            <div className="min-w-0">
              <div className="text-2xl font-semibold leading-none tabular-nums">
                {st.value}
              </div>
              <div className="mt-1 flex items-center gap-1 text-[11px] text-muted-foreground">
                {st.label}
                {st.hint && (
                  <span className="rounded bg-destructive/15 px-1 text-[9px] font-medium uppercase text-destructive">
                    {st.hint}
                  </span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
