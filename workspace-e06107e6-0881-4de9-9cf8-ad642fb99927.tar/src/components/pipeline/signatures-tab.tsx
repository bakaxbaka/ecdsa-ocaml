"use client";

import { useMemo, useState } from "react";
import { Download, FileJson, Search, Signature as SignatureIcon } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { baseLabel, formatValue, type ValueBase } from "@/lib/convert";
import {
  downloadFile,
  signaturesToCsv,
  resultsToJson,
} from "@/lib/csv";
import type { Signature, SignatureType } from "@/lib/pipeline-types";
import { CopyButton, ValueAllBases, ValueDisplay } from "@/components/pipeline/value-display";
import { cn } from "@/lib/utils";

interface SignaturesTabProps {
  signatures: Signature[];
}

const TYPE_OPTIONS: Array<{ value: "all" | SignatureType; label: string }> = [
  { value: "all", label: "All types" },
  { value: "P2PKH", label: "P2PKH" },
  { value: "P2PK", label: "P2PK" },
  { value: "P2WPKH", label: "P2WPKH" },
];

function DefRow({ label, value, mono = true }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="grid grid-cols-1 gap-1 border-b py-2 last:border-b-0 sm:grid-cols-[140px_1fr] sm:gap-3">
      <dt className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </dt>
      <dd className={cn("min-w-0 break-all", mono && "font-mono text-xs")}>
        {value || "—"}
      </dd>
    </div>
  );
}

export function SignaturesTab({ signatures }: SignaturesTabProps) {
  const [base, setBase] = useState<ValueBase>("hex");
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | SignatureType>("all");
  const [selected, setSelected] = useState<Signature | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return signatures.filter((s) => {
      if (typeFilter !== "all" && s.type !== typeFilter) return false;
      if (!q) return true;
      return (
        s.address.toLowerCase().includes(q) ||
        s.txid.toLowerCase().includes(q) ||
        s.prev_txid.toLowerCase().includes(q) ||
        s.pubkey.toLowerCase().includes(q) ||
        s.r.toLowerCase().includes(q) ||
        s.s.toLowerCase().includes(q) ||
        s.z.toLowerCase().includes(q)
      );
    });
  }, [signatures, query, typeFilter]);

  const handleExportCsv = () => {
    const csv = signaturesToCsv(filtered, base);
    downloadFile(
      `signatures-${base}-${Date.now()}.csv`,
      csv,
      "text/csv;charset=utf-8",
    );
  };

  const handleExportJson = () => {
    const json = resultsToJson(filtered, []);
    downloadFile(
      `signatures-${Date.now()}.json`,
      json,
      "application/json;charset=utf-8",
    );
  };

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <div className="space-y-1">
            <Label className="text-[11px] text-muted-foreground">Value base</Label>
            <ToggleGroup
              type="single"
              value={base}
              onValueChange={(v) => {
                if (v) setBase(v as ValueBase);
              }}
              variant="outline"
              size="sm"
            >
              <ToggleGroupItem value="hex" className="text-xs">Hex</ToggleGroupItem>
              <ToggleGroupItem value="dec" className="text-xs">Decimal</ToggleGroupItem>
              <ToggleGroupItem value="bin" className="text-xs">Binary</ToggleGroupItem>
            </ToggleGroup>
          </div>

          <div className="space-y-1">
            <Label htmlFor="sig-search" className="text-[11px] text-muted-foreground">
              Search
            </Label>
            <div className="relative">
              <Search className="pointer-events-none absolute left-2 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="sig-search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="address, txid, r/s/z…"
                className="h-8 w-full pl-7 text-xs lg:w-56"
              />
            </div>
          </div>

          <div className="space-y-1">
            <Label htmlFor="sig-type" className="text-[11px] text-muted-foreground">
              Type
            </Label>
            <Select
              value={typeFilter}
              onValueChange={(v) => setTypeFilter(v as "all" | SignatureType)}
            >
              <SelectTrigger id="sig-type" size="sm" className="h-8 w-[140px] text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TYPE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExportCsv} className="gap-1.5 text-xs" disabled={filtered.length === 0}>
            <Download className="size-3.5" />
            Export CSV
            <span className="ml-1 rounded bg-muted px-1 text-[10px] uppercase">{baseLabel(base)}</span>
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportJson} className="gap-1.5 text-xs" disabled={filtered.length === 0}>
            <FileJson className="size-3.5" />
            Export JSON
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-md border">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-2 py-16 text-center text-muted-foreground">
            <SignatureIcon className="size-6 opacity-40" />
            <p className="text-sm font-medium">No signatures yet</p>
            <p className="text-xs">
              {signatures.length === 0
                ? "Run the pipeline to extract ECDSA signatures from transactions."
                : "No signatures match the current filters."}
            </p>
          </div>
        ) : (
          <div className="pipeline-scroll max-h-[600px] overflow-auto">
            <Table className="text-xs">
              <TableHeader className="sticky top-0 z-10 bg-card">
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-[44px]">#</TableHead>
                  <TableHead className="min-w-[140px]">Address</TableHead>
                  <TableHead className="min-w-[180px]">TxID</TableHead>
                  <TableHead className="w-[52px]">In</TableHead>
                  <TableHead className="w-[70px]">Type</TableHead>
                  <TableHead className="min-w-[200px]">r</TableHead>
                  <TableHead className="min-w-[200px]">s</TableHead>
                  <TableHead className="min-w-[200px]">z</TableHead>
                  <TableHead className="w-[70px]">low-S</TableHead>
                  <TableHead className="w-[70px]">sighash</TableHead>
                  <TableHead className="min-w-[180px]">Pubkey</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((sig, i) => (
                  <TableRow
                    key={`${sig.txid}-${sig.input_index}-${i}`}
                    onClick={() => setSelected(sig)}
                    className={cn(
                      "cursor-pointer",
                      !sig.low_s && "bg-orange-500/5 hover:bg-orange-500/10",
                    )}
                  >
                    <TableCell className="align-top tabular-nums text-muted-foreground">
                      {i + 1}
                    </TableCell>
                    <TableCell className="align-top">
                      <code className="break-all font-mono text-[11px] text-foreground">
                        {sig.address}
                      </code>
                    </TableCell>
                    <TableCell className="align-top">
                      <code className="break-all font-mono text-[11px] text-foreground/90">
                        {sig.txid}
                      </code>
                    </TableCell>
                    <TableCell className="align-top tabular-nums">{sig.input_index}</TableCell>
                    <TableCell className="align-top">
                      <Badge variant="secondary" className="text-[10px]">{sig.type}</Badge>
                    </TableCell>
                    <TableCell className="align-top">
                      <div className="max-w-[280px]">
                        <code className="block break-all font-mono text-[11px] text-foreground">
                          {formatValue(sig.r, base)}
                        </code>
                      </div>
                    </TableCell>
                    <TableCell className="align-top">
                      <div className="max-w-[280px]">
                        <code className="block break-all font-mono text-[11px] text-foreground">
                          {formatValue(sig.s, base)}
                        </code>
                      </div>
                    </TableCell>
                    <TableCell className="align-top">
                      <div className="max-w-[280px]">
                        <code className="block break-all font-mono text-[11px] text-foreground">
                          {formatValue(sig.z, base)}
                        </code>
                      </div>
                    </TableCell>
                    <TableCell className="align-top">
                      {sig.low_s ? (
                        <Badge className="border-emerald-500/30 bg-emerald-500/15 text-[10px] text-emerald-500">
                          yes
                        </Badge>
                      ) : (
                        <Badge className="border-orange-500/30 bg-orange-500/15 text-[10px] text-orange-500">
                          no
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="align-top">
                      <code className="font-mono text-[11px]">
                        0x{sig.sighash_type.toString(16)}
                      </code>
                    </TableCell>
                    <TableCell className="align-top">
                      <div className="max-w-[200px]">
                        <code className="block break-all font-mono text-[11px] text-muted-foreground">
                          {sig.pubkey}
                        </code>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      <p className="text-[11px] text-muted-foreground">
        Showing {filtered.length} of {signatures.length} signatures. Click any row to view all fields
        with r/s/z converted to hex, decimal and binary side by side.
      </p>

      {/* Detail sheet */}
      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent
          side="right"
          className="flex w-full flex-col gap-0 overflow-hidden p-0 sm:max-w-2xl lg:max-w-3xl"
        >
          <SheetHeader className="border-b">
            <SheetTitle className="flex items-center gap-2 text-base">
              <SignatureIcon className="size-4 text-emerald-500" />
              Signature detail
            </SheetTitle>
            <SheetDescription>
              Full field dump. r, s and z are shown in all three bases (hex / decimal / binary) below.
            </SheetDescription>
          </SheetHeader>

          {selected && (
            <div className="pipeline-scroll flex-1 overflow-y-auto px-4 py-3">
              <dl className="mb-4 rounded-md border p-3">
                <DefRow label="Address" value={selected.address} />
                <DefRow label="TxID" value={selected.txid} />
                <DefRow label="Input index" value={String(selected.input_index)} mono={false} />
                <DefRow label="Prev txid" value={selected.prev_txid} />
                <DefRow label="Prevout" value={String(selected.prevout)} mono={false} />
                <DefRow label="Sequence" value={`0x${selected.sequence.toString(16)} (${selected.sequence})`} />
                <DefRow label="Type" value={selected.type} mono={false} />
                <DefRow label="DER signature" value={selected.der_signature} />
                <DefRow
                  label="low-S"
                  value={selected.low_s ? "true (BIP-62 compliant)" : "false (malleable)"}
                  mono={false}
                />
                <DefRow
                  label="Sighash type"
                  value={`0x${selected.sighash_type.toString(16)} (${selected.sighash_type})`}
                />
                <DefRow label="Pubkey" value={selected.pubkey} />
              </dl>

              <div className="space-y-4">
                <section>
                  <div className="mb-1.5 flex items-center justify-between">
                    <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      r — random nonce point x-coordinate
                    </h3>
                    <CopyButton value={selected.r} label="r (hex)" />
                  </div>
                  <ValueAllBases hexValue={selected.r} label="r" />
                </section>

                <section>
                  <div className="mb-1.5 flex items-center justify-between">
                    <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      s — signature proof scalar
                    </h3>
                    <CopyButton value={selected.s} label="s (hex)" />
                  </div>
                  <ValueAllBases hexValue={selected.s} label="s" />
                </section>

                <section>
                  <div className="mb-1.5 flex items-center justify-between">
                    <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      z — sighash (message hash)
                    </h3>
                    <CopyButton value={selected.z} label="z (hex)" />
                  </div>
                  <ValueAllBases hexValue={selected.z} label="z" />
                </section>

                <section className="rounded-md border bg-muted/20 p-3">
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Current base view ({baseLabel(base)})
                  </h3>
                  <div className="space-y-2">
                    <ValueDisplay hexValue={selected.r} base={base} label="r" />
                    <ValueDisplay hexValue={selected.s} base={base} label="s" />
                    <ValueDisplay hexValue={selected.z} base={base} label="z" />
                  </div>
                </section>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
