"use client";

import { useState } from "react";
import { AlertCircle, RefreshCw, X } from "lucide-react";
import { toast } from "sonner";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TooltipProvider } from "@/components/ui/tooltip";

import { usePipelineSocket } from "@/hooks/use-pipeline-socket";
import { ActivityLog } from "@/components/pipeline/activity-log";
import { ControlPanel } from "@/components/pipeline/control-panel";
import { Footer } from "@/components/pipeline/footer";
import { Header } from "@/components/pipeline/header";
import { RawDataTab } from "@/components/pipeline/raw-data-tab";
import { SignaturesTab } from "@/components/pipeline/signatures-tab";
import { SummaryStats } from "@/components/pipeline/summary-stats";
import { VulnerabilitiesTab } from "@/components/pipeline/vulnerabilities-tab";

export default function Home() {
  const pipeline = usePipelineSocket();
  const [dismissedError, setDismissedError] = useState(false);

  const showError = pipeline.error && !dismissedError;
  const hasResults =
    pipeline.signatures.length > 0 ||
    pipeline.vulnerabilities.length > 0 ||
    pipeline.summary !== null;

  const handleRetry = () => {
    pipeline.retryConnect();
    toast.info("Reconnecting to pipeline service…");
  };

  const handleClear = () => {
    pipeline.clear();
    setDismissedError(false);
    toast.success("Results cleared");
  };

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <TooltipProvider delayDuration={200}>
        <Header connected={pipeline.connected} onRetry={handleRetry} />

        <main className="flex-1 space-y-6 px-4 py-6 container mx-auto">
          {/* Offline banner */}
          {!pipeline.connected && (
            <Alert className="border-amber-500/40 bg-amber-500/5">
              <AlertCircle className="size-4 text-amber-500" />
              <AlertTitle className="text-amber-600 dark:text-amber-400">
                Pipeline service offline
              </AlertTitle>
              <AlertDescription className="flex flex-col gap-2 text-amber-700 dark:text-amber-300 sm:flex-row sm:items-center sm:justify-between">
                <span>
                  The analysis mini-service (port 3004) is not reachable. The UI is
                  still usable — results will populate once the connection is restored.
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRetry}
                  className="h-7 shrink-0 gap-1.5 text-xs"
                >
                  <RefreshCw className="size-3.5" />
                  Retry connection
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {/* Error banner */}
          {showError && (
            <Alert variant="destructive">
              <AlertCircle className="size-4" />
              <AlertTitle className="flex items-center justify-between gap-2">
                <span>Pipeline error</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-6"
                  onClick={() => setDismissedError(true)}
                  aria-label="Dismiss error"
                >
                  <X className="size-3.5" />
                </Button>
              </AlertTitle>
              <AlertDescription className="break-all font-mono text-xs">
                {pipeline.error}
              </AlertDescription>
            </Alert>
          )}

          {/* Top grid: controls + activity log */}
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <ControlPanel
              connected={pipeline.connected}
              running={pipeline.running}
              phase={pipeline.phase}
              progress={pipeline.progress}
              onStart={pipeline.start}
              onCancel={pipeline.cancel}
              onClear={handleClear}
            />
            <ActivityLog activity={pipeline.activity} running={pipeline.running} />
          </div>

          {/* Summary stats */}
          <SummaryStats
            summary={pipeline.summary}
            signatureCount={pipeline.signatures.length}
            vulnerabilityCount={pipeline.vulnerabilities.length}
          />

          {/* Results tabs */}
          <Card>
            <CardContent className="p-4 sm:p-6">
              <Tabs defaultValue="signatures" className="w-full">
                <TabsList className="mb-4 flex h-9 w-full flex-wrap justify-start sm:w-auto">
                  <TabsTrigger value="signatures" className="gap-1.5">
                    Signatures
                    <span className="ml-1 rounded bg-muted px-1.5 text-[10px] tabular-nums">
                      {pipeline.signatures.length}
                    </span>
                  </TabsTrigger>
                  <TabsTrigger value="vulnerabilities" className="gap-1.5">
                    Vulnerabilities
                    <span className="ml-1 rounded bg-muted px-1.5 text-[10px] tabular-nums">
                      {pipeline.vulnerabilities.length}
                    </span>
                  </TabsTrigger>
                  <TabsTrigger value="raw">Raw data</TabsTrigger>
                </TabsList>

                <TabsContent value="signatures" className="mt-0">
                  <SignaturesTab signatures={pipeline.signatures} />
                </TabsContent>

                <TabsContent value="vulnerabilities" className="mt-0">
                  <VulnerabilitiesTab vulnerabilities={pipeline.vulnerabilities} />
                </TabsContent>

                <TabsContent value="raw" className="mt-0">
                  <RawDataTab
                    signatures={pipeline.signatures}
                    vulnerabilities={pipeline.vulnerabilities}
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {!hasResults && (
            <p className="text-center text-[11px] text-muted-foreground">
              No results yet. Enter addresses in the control panel and click{" "}
              <span className="font-medium text-emerald-500">Run Pipeline</span> to begin.
            </p>
          )}
        </main>

        <Footer connected={pipeline.connected} />
      </TooltipProvider>
    </div>
  );
}
