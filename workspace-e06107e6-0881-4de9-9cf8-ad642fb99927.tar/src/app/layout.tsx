import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { Toaster as SonnerToaster } from "sonner";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Bitcoin ECDSA Signature Analyzer",
  description:
    "Automated pipeline: fetch spending txs → parse r/s/z → detect nonce-reuse & private-key recovery. Educational / security-research use only.",
  keywords: [
    "Bitcoin",
    "ECDSA",
    "nonce reuse",
    "private key recovery",
    "high-S",
    "signature analysis",
  ],
  authors: [{ name: "Bitcoin ECDSA Signature Analyzer" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <SonnerToaster
          theme="dark"
          richColors
          closeButton
          position="bottom-right"
          toastOptions={{
            style: {
              fontFamily: "var(--font-geist-sans)",
            },
          }}
        />
      </body>
    </html>
  );
}
