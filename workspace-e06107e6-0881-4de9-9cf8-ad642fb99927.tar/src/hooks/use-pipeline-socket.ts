"use client";

// ============================================================================
// usePipelineSocket — single source of truth for the pipeline UI.
//
// Owns the socket.io-client connection to the mini-service on port 3004
// (via the gateway: io('/?XTransformPort=3004')), subscribes to the frozen
// event contract, and exposes a clean reactive API for the page.
// ============================================================================

import { useCallback, useEffect, useRef, useState } from "react";
import { io, type Socket } from "socket.io-client";
import { toast } from "sonner";

import type {
  ActivityLogEntry,
  PipelineCompleteEvent,
  PipelineErrorEvent,
  PipelineOptions,
  PipelinePhase,
  PipelineSignatureEvent,
  PipelineStartPayload,
  PipelineSummary,
  ProgressEvent,
  PipelineVulnerabilityEvent,
  Signature,
  Vulnerability,
} from "@/lib/pipeline-types";

const SOCKET_URL = "/?XTransformPort=3004";

export interface UsePipelineSocket {
  connected: boolean;
  running: boolean;
  phase: PipelinePhase;
  jobId: string | null;
  progress: ProgressEvent | null;
  activity: ActivityLogEntry[];
  signatures: Signature[];
  vulnerabilities: Vulnerability[];
  summary: PipelineSummary | null;
  error: string | null;
  start: (addresses: string[], options: PipelineOptions) => void;
  cancel: () => void;
  clear: () => void;
  retryConnect: () => void;
}

/** Max activity-log lines retained in memory (oldest dropped). */
const MAX_ACTIVITY = 500;

/** Generate a short unique id (good enough for client-side log keys). */
function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

/** Generate a client-side job id. */
function newJobId(): string {
  return "job-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
}

export function usePipelineSocket(): UsePipelineSocket {
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const [running, setRunning] = useState(false);
  const [phase, setPhase] = useState<PipelinePhase>("idle");
  const [jobId, setJobId] = useState<string | null>(null);
  const [progress, setProgress] = useState<ProgressEvent | null>(null);
  const [activity, setActivity] = useState<ActivityLogEntry[]>([]);
  const [signatures, setSignatures] = useState<Signature[]>([]);
  const [vulnerabilities, setVulnerabilities] = useState<Vulnerability[]>([]);
  const [summary, setSummary] = useState<PipelineSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  const connect = useCallback(() => {
    if (socketRef.current) return;
    const sock = io(SOCKET_URL, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      forceNew: true,
    });
    socketRef.current = sock;

    sock.on("connect", () => {
      setConnected(true);
    });
    sock.on("disconnect", () => {
      setConnected(false);
    });
    sock.io.on("reconnect_attempt", () => {
      setConnected(false);
    });

    sock.on("pipeline:progress", (evt: ProgressEvent) => {
      if (!evt) return;
      setProgress(evt);
      setPhase(evt.phase ?? "idle");
      if (evt.phase === "fetching" || evt.phase === "parsing" || evt.phase === "detecting") {
        setRunning(true);
      }
      setActivity((prev) => {
        const entry: ActivityLogEntry = {
          id: uid(),
          timestamp: Date.now(),
          phase: evt.phase ?? "idle",
          address: evt.address,
          message: evt.message ?? "",
          current: evt.current ?? 0,
          total: evt.total ?? 0,
        };
        const next = [...prev, entry];
        if (next.length > MAX_ACTIVITY) next.splice(0, next.length - MAX_ACTIVITY);
        return next;
      });
    });

    sock.on("pipeline:signature", (evt: PipelineSignatureEvent) => {
      if (!evt || !evt.signature) return;
      setSignatures((prev) => [...prev, evt.signature]);
    });

    sock.on("pipeline:vulnerability", (evt: PipelineVulnerabilityEvent) => {
      if (!evt || !evt.vulnerability) return;
      setVulnerabilities((prev) => [...prev, evt.vulnerability]);
    });

    sock.on("pipeline:complete", (evt: PipelineCompleteEvent) => {
      if (!evt) return;
      setSignatures(evt.signatures ?? []);
      setVulnerabilities(evt.vulnerabilities ?? []);
      setSummary(evt.summary ?? null);
      setPhase("complete");
      setRunning(false);
      setProgress((prev) =>
        prev
          ? { ...prev, phase: "complete", message: "Pipeline complete", current: prev.total || prev.current }
          : {
              jobId: evt.jobId ?? "",
              phase: "complete",
              message: "Pipeline complete",
              current: 0,
              total: 0,
            },
      );
    });

    sock.on("pipeline:error", (evt: PipelineErrorEvent) => {
      const msg = evt?.error ?? "Unknown pipeline error";
      setError(msg);
      setPhase("error");
      setRunning(false);
      toast.error("Pipeline error", { description: msg });
    });
  }, []);

  useEffect(() => {
    connect();
    return () => {
      const sock = socketRef.current;
      if (sock) {
        sock.removeAllListeners();
        sock.disconnect();
      }
      socketRef.current = null;
    };
  }, [connect]);

  const retryConnect = useCallback(() => {
    const sock = socketRef.current;
    if (sock) {
      sock.connect();
    } else {
      connect();
    }
  }, [connect]);

  const start = useCallback(
    (addresses: string[], options: PipelineOptions) => {
      const sock = socketRef.current;
      if (!sock || !sock.connected) {
        toast.error("Pipeline service offline", {
          description: "Cannot start — socket is not connected. Retry the connection.",
        });
        return;
      }
      const id = newJobId();
      // Reset results for the new run.
      setError(null);
      setSummary(null);
      setSignatures([]);
      setVulnerabilities([]);
      setJobId(id);
      setPhase("fetching");
      setRunning(true);
      setProgress({
        jobId: id,
        phase: "fetching",
        message: "Starting pipeline…",
        current: 0,
        total: addresses.length,
      });
      setActivity((prev) => [
        ...prev,
        {
          id: uid(),
          timestamp: Date.now(),
          phase: "fetching",
          message: `Starting pipeline for ${addresses.length} address(es)`,
          current: 0,
          total: addresses.length,
        },
      ]);
      const payload: PipelineStartPayload = { jobId: id, addresses, options };
      sock.emit("pipeline:start", payload);
    },
    [],
  );

  const cancel = useCallback(() => {
    const sock = socketRef.current;
    if (!sock || !jobId) return;
    sock.emit("pipeline:cancel", { jobId });
    setRunning(false);
    setPhase("idle");
    setActivity((prev) => [
      ...prev,
      {
        id: uid(),
        timestamp: Date.now(),
        phase: "idle",
        message: "Pipeline cancelled by user",
        current: 0,
        total: 0,
      },
    ]);
    toast.info("Pipeline cancelled");
  }, [jobId]);

  const clear = useCallback(() => {
    setSignatures([]);
    setVulnerabilities([]);
    setSummary(null);
    setError(null);
    setActivity([]);
    setProgress(null);
    setPhase("idle");
    setRunning(false);
    setJobId(null);
  }, []);

  return {
    connected,
    running,
    phase,
    jobId,
    progress,
    activity,
    signatures,
    vulnerabilities,
    summary,
    error,
    start,
    cancel,
    clear,
    retryConnect,
  };
}
