// ============================================================================
// Bitcoin ECDSA Signature Analysis Pipeline — socket.io mini-service.
//
// Port 3004, path "/". The Next.js frontend connects via
// `io('/?XTransformPort=3004')` and the Caddy gateway forwards it here.
//
// Implements the frozen event contract in /home/z/my-project/worklog.md:
//   C→S  pipeline:start    { jobId, addresses, options }
//   C→S  pipeline:cancel   { jobId }
//   S→C  pipeline:progress { jobId, phase, address?, message, current, total }
//   S→C  pipeline:signature { jobId, signature }
//   S→C  pipeline:vulnerability { jobId, vulnerability }
//   S→C  pipeline:complete { jobId, signatures, vulnerabilities, summary }
//   S→C  pipeline:error    { jobId, error }
//
// FULL values everywhere — no truncation of r/s/z, recovered keys, txids, etc.
// ============================================================================

import { createServer, type Server as HttpServer } from "http";
import { Server, type Socket } from "socket.io";
import { cancelJob, getJob, runPipeline } from "./lib/pipeline.js";
import { normalizeAddress, parseAddressList } from "./lib/addresses.js";
import type {
  PipelineCancelPayload,
  PipelineCompleteEvent,
  PipelineErrorEvent,
  PipelineProgressEvent,
  PipelineSignatureEvent,
  PipelineStartPayload,
  PipelineVulnerabilityEvent,
} from "./lib/types.js";

const PORT = 3004;

const httpServer: HttpServer = createServer();
const io = new Server(httpServer, {
  // DO NOT change the path — Caddy forwards on path "/".
  path: "/",
  cors: { origin: "*", methods: ["GET", "POST"] },
  pingTimeout: 60000,
  pingInterval: 25000,
});

// Track active socket → jobId(s) so we can emit on the right socket.
const socketJobs = new Map<Socket, Set<string>>();

function emitProgress(event: PipelineProgressEvent): void {
  io.emit("pipeline:progress", event);
}
function emitSignature(event: PipelineSignatureEvent): void {
  io.emit("pipeline:signature", event);
}
function emitVulnerability(event: PipelineVulnerabilityEvent): void {
  io.emit("pipeline:vulnerability", event);
}
function emitComplete(event: PipelineCompleteEvent): void {
  io.emit("pipeline:complete", event);
}
function emitError(event: PipelineErrorEvent): void {
  io.emit("pipeline:error", event);
}

io.on("connection", (socket: Socket) => {
  console.log(`[pipeline] client connected: ${socket.id}`);

  // --- pipeline:start ---
  socket.on("pipeline:start", (raw: unknown) => {
    let payload: PipelineStartPayload;
    try {
      payload = parseStartPayload(raw);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Invalid pipeline:start payload";
      socket.emit("pipeline:error", { jobId: "unknown", error: msg });
      return;
    }

    const { jobId, addresses, options } = payload;
    console.log(`[pipeline] start job ${jobId}: ${addresses.length} address(es)`);

    // Track the job on this socket.
    let set = socketJobs.get(socket);
    if (!set) {
      set = new Set();
      socketJobs.set(socket, set);
    }
    set.add(jobId);

    // If a previous job with this id exists and is running, cancel it first.
    cancelJob(jobId);

    // Fire-and-forget — don't await so the socket stays responsive.
    runPipeline(
      {
        progress: emitProgress,
        signature: emitSignature,
        vulnerability: emitVulnerability,
        complete: emitComplete,
        error: emitError,
      },
      jobId,
      addresses,
      options,
    ).catch((err) => {
      console.error(`[pipeline] uncaught error in job ${jobId}:`, err);
      emitError({ jobId, error: err instanceof Error ? err.message : String(err) });
    });
  });

  // --- pipeline:cancel ---
  socket.on("pipeline:cancel", (raw: unknown) => {
    let payload: PipelineCancelPayload;
    try {
      payload = parseCancelPayload(raw);
    } catch {
      return; // malformed cancel — ignore
    }
    const ok = cancelJob(payload.jobId);
    console.log(`[pipeline] cancel job ${payload.jobId}: ${ok ? "cancelled" : "not running"}`);
  });

  // --- pipeline:state (query existing job results, e.g. on reconnect) ---
  socket.on("pipeline:state", (raw: unknown) => {
    const jobId = typeof raw === "string" ? raw : (raw as { jobId?: string })?.jobId;
    if (typeof jobId !== "string") return;
    const job = getJob(jobId);
    if (!job) {
      socket.emit("pipeline:error", { jobId, error: "No such job." });
      return;
    }
    // Re-send whatever we have.
    for (const sig of job.signatures) socket.emit("pipeline:signature", { jobId, signature: sig });
    for (const v of job.vulnerabilities) socket.emit("pipeline:vulnerability", { jobId, vulnerability: v });
    if (job.summary) {
      socket.emit("pipeline:complete", {
        jobId,
        signatures: job.signatures,
        vulnerabilities: job.vulnerabilities,
        summary: job.summary,
      });
    }
  });

  socket.on("disconnect", () => {
    console.log(`[pipeline] client disconnected: ${socket.id}`);
    // Note: we do NOT cancel running jobs on disconnect — the user may have
    // just refreshed the page. Jobs keep running in the background and their
    // results stay in the in-memory registry until the process restarts.
    socketJobs.delete(socket);
  });

  socket.on("error", (error: unknown) => {
    console.error(`[pipeline] socket error (${socket.id}):`, error);
  });
});

// ---------------------------------------------------------------------------
// Payload validation
// ---------------------------------------------------------------------------
function parseStartPayload(raw: unknown): PipelineStartPayload {
  if (!raw || typeof raw !== "object") throw new Error("pipeline:start payload must be an object");
  const obj = raw as Record<string, unknown>;
  const jobId = typeof obj.jobId === "string" ? obj.jobId : "";
  if (!jobId) throw new Error("pipeline.start: missing jobId");

  let addresses: string[];
  if (Array.isArray(obj.addresses)) {
    addresses = obj.addresses.filter((a): a is string => typeof a === "string");
  } else if (typeof obj.addresses === "string") {
    // Allow a textarea blob.
    addresses = parseAddressList(obj.addresses);
  } else {
    throw new Error("pipeline.start: addresses must be an array or string");
  }

  const opts = (obj.options ?? {}) as Record<string, unknown>;
  const options = {
    forceRefetch: Boolean(opts.forceRefetch),
    apiSource:
      opts.apiSource === "mempool.space" || opts.apiSource === "blockstream.info"
        ? (opts.apiSource as "mempool.space" | "blockstream.info")
        : ("auto" as const),
  };

  // Normalize + validate addresses.
  const normalized = addresses.map(normalizeAddress).filter(Boolean);
  if (normalized.length === 0) throw new Error("pipeline.start: no valid addresses provided");
  if (normalized.length > 50) throw new Error("pipeline.start: too many addresses (max 50 per job)");

  return { jobId, addresses: normalized, options };
}

function parseCancelPayload(raw: unknown): PipelineCancelPayload {
  if (!raw || typeof raw !== "object") throw new Error("pipeline:cancel payload must be an object");
  const obj = raw as Record<string, unknown>;
  if (typeof obj.jobId !== "string" || !obj.jobId) throw new Error("pipeline.cancel: missing jobId");
  return { jobId: obj.jobId };
}

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------
httpServer.listen(PORT, () => {
  console.log(`Pipeline service running on port ${PORT}`);
  console.log(`  socket.io path: /`);
  console.log(`  events: pipeline:start | pipeline:cancel | pipeline:progress | pipeline:signature | pipeline:vulnerability | pipeline:complete | pipeline:error`);
});

// Graceful shutdown.
function shutdown(signal: NodeJS.Signals): void {
  console.log(`\n[pipeline] ${signal} received, shutting down…`);
  httpServer.close(() => {
    console.log("[pipeline] http server closed");
    process.exit(0);
  });
  // Force exit after 5s if close hangs.
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
