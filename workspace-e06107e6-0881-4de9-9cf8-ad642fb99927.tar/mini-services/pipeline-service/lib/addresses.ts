// ============================================================================
// Bitcoin address validation/normalization. Adapted from the reference
// workspace (src/lib/addresses.ts).
// ============================================================================

export function normalizeAddress(raw: string): string {
  const t = raw.trim();
  if (/^(bc1|tb1)/i.test(t)) return t.toLowerCase();
  return t;
}

export function isPlausibleAddress(raw: string): boolean {
  const a = normalizeAddress(raw);
  if (/^(bc1|tb1)[a-z0-9]{14,90}$/.test(a)) return true;
  if (/^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(a)) return true;
  return false;
}

export function sameAddress(a: string | null | undefined, b: string | null | undefined): boolean {
  if (!a || !b) return false;
  if (/^(bc1|tb1)/i.test(a) || /^(bc1|tb1)/i.test(b)) return a.toLowerCase() === b.toLowerCase();
  return a === b;
}

/** Parse a textarea/list of addresses into unique, plausible addresses. */
export function parseAddressList(input: string): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const token of input.replace(/[,;\n\r\t]/g, " ").split(/\s+/)) {
    const addr = normalizeAddress(token);
    if (!addr) continue;
    if (!isPlausibleAddress(addr)) continue;
    if (seen.has(addr)) continue;
    seen.add(addr);
    out.push(addr);
  }
  return out;
}
