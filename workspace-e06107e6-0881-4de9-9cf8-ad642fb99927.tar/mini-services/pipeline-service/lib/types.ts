// ============================================================================
// Bitcoin ECDSA Signature Analysis Pipeline — shared data contract.
// Mirrors the frozen socket.io contract in /home/z/my-project/worklog.md
// and the frontend `src/lib/pipeline-types.ts` 1:1.
// ============================================================================

/** Display base for numeric values (r/s/z, recovered keys). */
export type ValueBase = "hex" | "dec" | "bin";

/** Script/address type that produced the signature. Widened to string to carry
 *  additional script variants (P2SH, P2WSH, P2SH-P2WPKH, nonstandard, ...). */
export type SignatureType = "P2PKH" | "P2PK" | "P2WPKH" | string;

/** A single parsed ECDSA signature from a transaction input. */
export interface Signature {
  /** Stable id: `${txid}:${input_index}:${sig_index}`. */
  id: string;
  address: string;
  txid: string;
  input_index: number;
  prev_txid: string;
  prevout: number;
  sequence: number;
  type: SignatureType;
  /** Full DER-encoded signature, hex (no sighash byte). NEVER truncated. */
  der_signature: string;
  /** r value, hex (no 0x prefix). Even-length. Full value. */
  r: string;
  /** s value, hex (no 0x prefix). Even-length. Full value. */
  s: string;
  /** Whether s is in low-S form (BIP-62). */
  low_s: boolean;
  /** Sighash z value, hex. Always 32 bytes / 64 chars. Full value. */
  z: string;
  /** Sighash type byte (0x01 ALL, 0x02 NONE, 0x03 SINGLE, 0x81 ANYONECANPAY|ALL ...). */
  sighash_type: number;
  /** Public key that signed, hex (compressed or uncompressed). */
  pubkey: string;

  // ----- additive metadata (optional, frontend ignores unknown keys) -----
  /** Human label for sighash_type, e.g. "ALL", "NONE|ANYONECANPAY". */
  sighash_label?: string;
  /** Whether the signature verified against the computed z (null = couldn't check). */
  verified?: boolean | null;
  /** Parse/validation notes (e.g. "non-minimal DER", "verification failed"). */
  notes?: string[];
  /** Block height of the spending tx, null if unconfirmed. */
  block_height?: number | null;
  /** Block time of the spending tx, null if unconfirmed. */
  block_time?: number | null;
  /** Value of the spent prevout in satoshis (decimal string). Null if unknown. */
  value_sats?: string | null;
  /** Bit length of r (used for weak-nonce heuristics). */
  bit_length_r?: number;
}

/** Kind of vulnerability detected. */
export type VulnType = "nonce_reuse" | "high_s" | "weak_nonce";

/** Severity of a vulnerability. */
export type Severity = "critical" | "medium" | "low";

/** A detected vulnerability / security finding. */
export interface Vulnerability {
  id: string;
  type: VulnType;
  severity: Severity;
  title: string;
  description: string;
  address?: string;
  signatures: Signature[];
  /** Recovered private key, hex (32 bytes / 64 chars). Present for nonce_reuse. */
  recovered_private_key?: string;
  /** Recovered nonce k, hex (32 bytes / 64 chars). Present for nonce_reuse. */
  recovered_nonce?: string;
}

/** Aggregate counts emitted at pipeline completion. */
export interface PipelineSummary {
  addresses: number;
  transactions: number;
  signatures: number;
  vulnerabilities: number;
  nonce_reuse_count: number;
  high_s_count: number;
  weak_nonce_count: number;
  keys_recovered: number;
}

/** Pipeline phase reported by progress events. */
export type PipelinePhase =
  | "idle"
  | "fetching"
  | "parsing"
  | "detecting"
  | "complete"
  | "error";

/** `pipeline:progress` payload. */
export interface ProgressEvent {
  jobId: string;
  phase: PipelinePhase;
  address?: string;
  message: string;
  current: number;
  total: number;
}

/** Options sent with `pipeline:start`. */
export interface PipelineOptions {
  forceRefetch: boolean;
  apiSource: "auto" | "mempool.space" | "blockstream.info";
}

// ---------------------------------------------------------------------------
// Socket event payload types (for type-safe emit/on handlers).
// ---------------------------------------------------------------------------

export interface PipelineStartPayload {
  jobId: string;
  addresses: string[];
  options: PipelineOptions;
}

export interface PipelineCancelPayload {
  jobId: string;
}

export interface PipelineSignatureEvent {
  jobId: string;
  signature: Signature;
}

export interface PipelineVulnerabilityEvent {
  jobId: string;
  vulnerability: Vulnerability;
}

export interface PipelineCompleteEvent {
  jobId: string;
  signatures: Signature[];
  vulnerabilities: Vulnerability[];
  summary: PipelineSummary;
}

export interface PipelineErrorEvent {
  jobId: string;
  error: string;
}

// ---------------------------------------------------------------------------
// In-memory job state.
// ---------------------------------------------------------------------------

export interface JobState {
  jobId: string;
  addresses: string[];
  options: PipelineOptions;
  signatures: Signature[];
  vulnerabilities: Vulnerability[];
  summary: PipelineSummary | null;
  status: "running" | "complete" | "error" | "cancelled";
  startedAt: number;
  endedAt: number | null;
  error: string | null;
}

/** Emitters used by the pipeline orchestrator. All callbacks are best-effort. */
export interface PipelineEmitters {
  progress: (event: ProgressEvent) => void;
  signature: (event: PipelineSignatureEvent) => void;
  vulnerability: (event: PipelineVulnerabilityEvent) => void;
  complete: (event: PipelineCompleteEvent) => void;
  error: (event: PipelineErrorEvent) => void;
}
