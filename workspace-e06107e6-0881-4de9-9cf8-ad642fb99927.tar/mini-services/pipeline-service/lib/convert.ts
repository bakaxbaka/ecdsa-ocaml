// ============================================================================
// Number base conversions for 256-bit (and larger) secp256k1 scalars.
// All values are stored/transported as hex strings; these helpers convert to
// decimal / binary strings and to/from BigInt. NOTHING is truncated.
// ============================================================================

import type { ValueBase } from "./types.js";

/** secp256k1 curve order n. */
export const SECP256K1_N =
  0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n;

/** Half of the curve order — used for the BIP-62 low-S check. */
export const SECP256K1_HALF_N = SECP256K1_N / 2n;

/** Strip an optional 0x/0X prefix and lowercase a hex string. */
export function normalizeHex(hex: string): string {
  if (typeof hex !== "string") return "";
  let s = hex.trim();
  if (s.startsWith("0x") || s.startsWith("0X")) s = s.slice(2);
  return s.toLowerCase();
}

/** BigInt modular reduction that always returns a non-negative value. */
export function mod(a: bigint, n: bigint = SECP256K1_N): bigint {
  return ((a % n) + n) % n;
}

/** Extended-Euclid modular inverse. Returns x such that a*x ≡ 1 (mod n). */
export function modInverse(a: bigint, m: bigint = SECP256K1_N): bigint {
  let oldR = mod(a, m);
  let r = m;
  let oldS = 1n;
  let s = 0n;
  while (r !== 0n) {
    const q = oldR / r;
    [oldR, r] = [r, oldR - q * r];
    [oldS, s] = [s, oldS - q * s];
  }
  // oldR is the gcd (should be 1 for a valid inverse)
  return mod(oldS, m);
}

/** Parse a hex (or decimal) string into a BigInt. Auto-detects base. */
export function toBigInt(value: string | bigint | number): bigint {
  if (typeof value === "bigint") return value;
  if (typeof value === "number") return BigInt(value);
  if (typeof value !== "string") return 0n;
  const s = value.trim();
  if (s === "") return 0n;
  if (s.startsWith("0x") || s.startsWith("0X")) {
    return BigInt(s);
  }
  if (s.startsWith("0b") || s.startsWith("0B")) {
    return BigInt(s);
  }
  // Hex if it contains a-f and no sign, or all chars are hex digits
  if (/^[0-9a-f]+$/i.test(s) && /[a-f]/i.test(s)) {
    return BigInt("0x" + s);
  }
  // Pure decimal digits
  if (/^[0-9]+$/.test(s)) {
    return BigInt(s);
  }
  // Fallback: try hex
  try {
    return BigInt("0x" + s);
  } catch {
    return 0n;
  }
}

/** BigInt → hex string without 0x prefix. Pads to even length (no leading 0). */
export function bigIntToHex(n: bigint): string {
  const h = n.toString(16);
  return h.length % 2 === 0 ? h : "0" + h;
}

/** BigInt → 32-byte (64-char) canonical hex string, zero-padded. For r/s/z canon. */
export function bigIntToHex32(n: bigint): string {
  return n.toString(16).padStart(64, "0");
}

/** BigInt → full binary string grouped into bytes (e.g. "00011010 00101011"). */
export function bigIntToBin(n: bigint): string {
  if (n === 0n) return "00000000";
  let bits = n.toString(2);
  // Pad to a whole number of bytes
  const pad = (8 - (bits.length % 8)) % 8;
  bits = "0".repeat(pad) + bits;
  // Group into bytes separated by spaces
  const bytes: string[] = [];
  for (let i = 0; i < bits.length; i += 8) {
    bytes.push(bits.slice(i, i + 8));
  }
  return bytes.join(" ");
}

/** hex → decimal string. Handles arbitrary precision via BigInt. */
export function hexToDec(hex: string): string {
  return toBigInt(hex).toString(10);
}

/** decimal string → hex string (even length, no 0x). */
export function decToHex(dec: string): string {
  const n = /^[0-9]+$/.test(dec.trim()) ? BigInt(dec) : toBigInt(dec);
  return bigIntToHex(n);
}

/** hex string → binary string grouped into bytes. */
export function hexToBin(hex: string): string {
  return bigIntToBin(toBigInt(hex));
}

/** decimal string → binary string grouped into bytes. */
export function decToBin(dec: string): string {
  const n = /^[0-9]+$/.test(dec.trim()) ? BigInt(dec) : toBigInt(dec);
  return bigIntToBin(n);
}

/**
 * Format a hex value in the requested base. The canonical stored form is hex;
 * this converts to the requested display base without any truncation.
 */
export function formatValue(hexValue: string, base: ValueBase): string {
  switch (base) {
    case "hex":
      return normalizeHex(hexValue);
    case "dec":
      return hexToDec(hexValue);
    case "bin":
      return hexToBin(hexValue);
    default:
      return normalizeHex(hexValue);
  }
}

/** Human label for a base. */
export function baseLabel(base: ValueBase): string {
  return base === "hex" ? "Hex" : base === "dec" ? "Decimal" : "Binary";
}

/** Short hint shown beside a base toggle. */
export function baseHint(base: ValueBase): string {
  return base === "hex"
    ? "0x-prefixed bytes"
    : base === "dec"
    ? "base-10 integer"
    : "base-2 bits, byte-grouped";
}

// Re-export so consumers can import everything from one place.
export type { ValueBase };
