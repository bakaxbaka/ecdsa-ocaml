// ============================================================================
// CSV / JSON export helpers. Server-side mirror of the frontend's csv.ts so the
// mini-service could also produce downloadable artifacts if needed. Full values
// everywhere — no truncation.
// ============================================================================

import { hexToDec } from "./convert.js";
import type { Signature, ValueBase, Vulnerability } from "./types.js";

const SIG_COLUMNS = [
  "address",
  "txid",
  "input_index",
  "prev_txid",
  "prevout",
  "sequence",
  "type",
  "r",
  "s",
  "z",
  "low_s",
  "sighash_type",
  "pubkey",
  "der_signature",
  "verified",
  "block_height",
] as const;

function csvCell(value: unknown): string {
  if (value === null || value === undefined) return "";
  const s = String(value);
  // RFC 4180: quote if it contains comma, quote, newline.
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

/** Convert a hex r/s/z value to the requested base for CSV export. */
function valueForCsv(hex: string, base: ValueBase): string {
  if (base === "hex") return hex;
  if (base === "dec") return hexToDec(hex);
  // bin — BigInt → binary, grouped into bytes
  const min = hex.replace(/^0+/, "") || "0";
  const n = BigInt(`0x${min}`);
  if (n === 0n) return "00000000";
  let bits = n.toString(2);
  const pad = (8 - (bits.length % 8)) % 8;
  bits = "0".repeat(pad) + bits;
  const bytes: string[] = [];
  for (let i = 0; i < bits.length; i += 8) bytes.push(bits.slice(i, i + 8));
  return bytes.join(" ");
}

export function signaturesToCsv(signatures: Signature[], base: ValueBase = "hex"): string {
  const header = SIG_COLUMNS.join(",");
  const rows = signatures.map((sig) =>
    [
      sig.address,
      sig.txid,
      sig.input_index,
      sig.prev_txid,
      sig.prevout,
      sig.sequence,
      sig.type,
      valueForCsv(sig.r, base),
      valueForCsv(sig.s, base),
      valueForCsv(sig.z, base),
      sig.low_s ? "true" : "false",
      sig.sighash_type,
      sig.pubkey,
      sig.der_signature,
      sig.verified === null ? "" : sig.verified ? "true" : "false",
      sig.block_height ?? "",
    ]
      .map(csvCell)
      .join(","),
  );
  return [header, ...rows].join("\n");
}

export function vulnerabilitiesToCsv(vulns: Vulnerability[]): string {
  const header = [
    "id",
    "type",
    "severity",
    "title",
    "address",
    "recovered_private_key",
    "recovered_nonce",
    "signature_count",
    "description",
  ].join(",");
  const rows = vulns.map((v) =>
    [
      v.id,
      v.type,
      v.severity,
      v.title,
      v.address ?? "",
      v.recovered_private_key ?? "",
      v.recovered_nonce ?? "",
      v.signatures.length,
      v.description,
    ]
      .map(csvCell)
      .join(","),
  );
  return [header, ...rows].join("\n");
}

export function resultsToJson(signatures: Signature[], vulnerabilities: Vulnerability[]): string {
  return JSON.stringify({ signatures, vulnerabilities }, null, 2);
}
