// ============================================================================
// Pipeline orchestrator. Runs the full fetch → parse → detect flow for a list
// of addresses, streaming progress/signature/vulnerability events as it goes.
// Keeps an in-memory job registry so results can be re-sent on reconnect.
// ============================================================================

import { normalizeAddress, isPlausibleAddress } from "./addresses.js";
import { scanOneAddress, pickHost, type Depth } from "./esplora.js";
import { detectVulnerabilities } from "./vulns.js";
import type {
  JobState,
  PipelineEmitters,
  PipelineOptions,
  PipelineSummary,
  Signature,
  Vulnerability,
} from "./types.js";

/** In-memory job registry (persists for the lifetime of the service). */
const jobs = new Map<string, JobState>();

/** Abort controllers per job, for cancellation. */
const abortControllers = new Map<string, AbortController>();

export function getJob(jobId: string): JobState | undefined {
  return jobs.get(jobId);
}

export function cancelJob(jobId: string): boolean {
  const ctrl = abortControllers.get(jobId);
  if (ctrl) {
    ctrl.abort(new Error("Cancelled by user"));
    return true;
  }
  return false;
}

function isValidAddress(a: string): boolean {
  return isPlausibleAddress(normalizeAddress(a));
}

/** Convert the user's `apiSource` option to a depth hint (deeper = slower). */
function depthFor(addressCount: number): Depth {
  // For batch scans, keep it quick per address so the whole job finishes in
  // a reasonable time. Single-address scans can go deeper.
  if (addressCount <= 1) return "standard";
  if (addressCount <= 5) return "standard";
  return "quick";
}

/**
 * Run the full pipeline for a job. Emits events via the provided emitters.
 * NEVER throws — errors are emitted as `pipeline:error`.
 */
export async function runPipeline(
  emitters: PipelineEmitters,
  jobId: string,
  rawAddresses: string[],
  options: PipelineOptions,
): Promise<void> {
  const startedAt = Date.now();

  // --- Validate addresses ---
  const addresses = rawAddresses.map(normalizeAddress).filter(isValidAddress);
  if (addresses.length === 0) {
    emitters.error({ jobId, error: "No valid Bitcoin addresses provided. Addresses must start with 1, 3, bc1, tb1, or bcrt1." });
    return;
  }

  // --- Register job ---
  const ctrl = new AbortController();
  abortControllers.set(jobId, ctrl);
  const jobState: JobState = {
    jobId,
    addresses,
    options,
    signatures: [],
    vulnerabilities: [],
    summary: null,
    status: "running",
    startedAt,
    endedAt: null,
    error: null,
  };
  jobs.set(jobId, jobState);

  const signal = ctrl.signal;
  const totalAddresses = addresses.length;
  let totalTxs = 0;

  try {
    // --- Phase 1: Fetch + parse (per address) ---
    emitters.progress({
      jobId,
      phase: "fetching",
      message: `Starting pipeline for ${totalAddresses} address${totalAddresses === 1 ? "" : "es"}${options.forceRefetch ? " (force re-fetch)" : ""}.`,
      current: 0,
      total: totalAddresses,
    });

    // Pick a preferred host once (races mempool.space vs blockstream.info).
    let preferredHost: Awaited<ReturnType<typeof pickHost>> | null = null;
    try {
      preferredHost = await pickHost(signal);
      emitters.progress({
        jobId,
        phase: "fetching",
        message: `Using chain index: ${preferredHost.name}.`,
        current: 0,
        total: totalAddresses,
      });
    } catch (e) {
      // Both hosts down — scanOneAddress will still try and throw per address.
      emitters.progress({
        jobId,
        phase: "fetching",
        message: `Warning: could not pre-select a chain index host (${e instanceof Error ? e.message : "unknown error"}). Will retry per address.`,
        current: 0,
        total: totalAddresses,
      });
    }

    const depth = depthFor(totalAddresses);
    const scope: "own" | "all" = "own";

    for (let i = 0; i < addresses.length; i++) {
      if (signal.aborted) throw new DOMException("Aborted", "AbortError");
      const address = addresses[i];

      emitters.progress({
        jobId,
        phase: "fetching",
        address,
        message: `[${i + 1}/${totalAddresses}] Fetching & parsing spending transactions for ${address}…`,
        current: i,
        total: totalAddresses,
      });

      try {
        const result = await scanOneAddress({
          address,
          depth,
          scope,
          preferredHost,
          signal,
          onProgress: (msg, current, total) => {
            emitters.progress({
              jobId,
              phase: "parsing",
              address,
              message: `[${i + 1}/${totalAddresses}] ${msg}`,
              current: typeof current === "number" ? current : i,
              total: typeof total === "number" ? total : totalAddresses,
            });
          },
        });

        totalTxs += result.spending;

        // Stream each signature live.
        for (const sig of result.signatures) {
          jobState.signatures.push(sig);
          emitters.signature({ jobId, signature: sig });
        }

        emitters.progress({
          jobId,
          phase: "parsing",
          address,
          message: `[${i + 1}/${totalAddresses}] ${address}: ${result.signatures.length} signature${result.signatures.length === 1 ? "" : "s"} extracted from ${result.spending} spending tx${result.spending === 1 ? "" : "s"}${result.notice ? " — " + result.notice : ""}.`,
          current: i + 1,
          total: totalAddresses,
        });
      } catch (err) {
        if (err instanceof DOMException && err.name === "AbortError") throw err;
        const msg = err instanceof Error ? err.message : String(err);
        emitters.progress({
          jobId,
          phase: "fetching",
          address,
          message: `[${i + 1}/${totalAddresses}] ${address}: failed — ${msg}. Continuing to next address.`,
          current: i + 1,
          total: totalAddresses,
        });
      }

      // Small inter-address delay to be polite to the index APIs.
      if (i < addresses.length - 1 && !signal.aborted) {
        await sleep(300);
      }
    }

    // --- Phase 2: Detect vulnerabilities ---
    if (signal.aborted) throw new DOMException("Aborted", "AbortError");
    emitters.progress({
      jobId,
      phase: "detecting",
      message: `Detecting vulnerabilities across ${jobState.signatures.length} signature${jobState.signatures.length === 1 ? "" : "s"}…`,
      current: 0,
      total: jobState.signatures.length,
    });

    const vulnerabilities = detectVulnerabilities(jobState.signatures);
    for (const v of vulnerabilities) {
      jobState.vulnerabilities.push(v);
      emitters.vulnerability({ jobId, vulnerability: v });
    }

    // --- Phase 3: Complete ---
    const summary: PipelineSummary = {
      addresses: totalAddresses,
      transactions: totalTxs,
      signatures: jobState.signatures.length,
      vulnerabilities: vulnerabilities.length,
      nonce_reuse_count: vulnerabilities.filter((v) => v.type === "nonce_reuse").length,
      high_s_count: vulnerabilities.filter((v) => v.type === "high_s").length,
      weak_nonce_count: vulnerabilities.filter((v) => v.type === "weak_nonce").length,
      keys_recovered: vulnerabilities.filter(
        (v) => v.type === "nonce_reuse" && v.recovered_private_key,
      ).length,
    };
    jobState.summary = summary;
    jobState.status = "complete";
    jobState.endedAt = Date.now();

    emitters.progress({
      jobId,
      phase: "complete",
      message: `Pipeline complete: ${summary.signatures} signature${summary.signatures === 1 ? "" : "s"}, ${summary.vulnerabilities} vulnerabilit${summary.vulnerabilities === 1 ? "y" : "ies"}, ${summary.keys_recovered} key${summary.keys_recovered === 1 ? "" : "s"} recovered.`,
      current: summary.signatures,
      total: summary.signatures,
    });

    emitters.complete({
      jobId,
      signatures: jobState.signatures,
      vulnerabilities: jobState.vulnerabilities,
      summary,
    });
  } catch (err) {
    const aborted = err instanceof DOMException && err.name === "AbortError";
    const msg = aborted ? "Pipeline cancelled by user." : err instanceof Error ? err.message : String(err);
    jobState.status = aborted ? "cancelled" : "error";
    jobState.endedAt = Date.now();
    jobState.error = msg;
    emitters.error({ jobId, error: msg });
  } finally {
    abortControllers.delete(jobId);
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

// Re-export for index.ts convenience.
export type { Signature, Vulnerability, PipelineSummary };
