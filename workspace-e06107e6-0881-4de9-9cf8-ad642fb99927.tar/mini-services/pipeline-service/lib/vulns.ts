// ============================================================================
// Vulnerability detection + private-key recovery.
// Heuristics adapted from the reference workspace (src/lib/bitcoin/findings.ts):
//   - nonce reuse (repeated r across signatures with different s/z)
//   - high-S malleability (BIP-62)
//   - very-small / short r (biased nonce hint)
//   - duplicate signature filtering (same r,s,z = repeated record, not a leak)
//   - unverified z, non-ALL sighash, non-strict DER, LSB bias stats
// EXTENDED WITH: full private-key + nonce recovery via secp256k1 modular
// arithmetic when a genuine nonce reuse is detected. This is the exploitable
// output the user explicitly asked for ("decrease the hardwork for identifying
// vulnerabilities").
//
// Recovery math (two signatures sharing the same r, i.e. same nonce k):
//   k = (z1 − z2) · (s1 − s2)⁻¹   mod n
//   d = (s1·k − z1) · r⁻¹          mod n
// where d is the private key and k is the nonce. Full values, no truncation.
// ============================================================================

import { bitLength } from "./bytes.js";
import { mod, modInverse, SECP256K1_N } from "./convert.js";
import type { Signature, Vulnerability } from "./types.js";

const N = SECP256K1_N;
const HALF_N = N >> 1n;

/** Strip leading zeros from a hex string so it can be used as a BigInt key. */
function rKey(hex: string): string {
  return hex.replace(/^0+/, "") || "0";
}

/** BigInt from a hex string (handles 0x prefix or bare hex). */
function hexToBig(hex: string): bigint {
  const h = hex.replace(/^0x/i, "").replace(/^0+/, "") || "0";
  return BigInt(`0x${h}`);
}

/** BigInt → 32-byte canonical hex (zero-padded to 64 chars). Full value. */
function bigToHex32(n: bigint): string {
  return mod(n, N).toString(16).padStart(64, "0");
}

/**
 * Recover the private key `d` and nonce `k` from two signatures that share the
 * same r (nonce reuse). Returns null if recovery fails (e.g. s1 === s2, which
 * means the two signatures are identical and there's nothing to exploit).
 */
function recoverKeyFromReuse(
  sig1: Signature,
  sig2: Signature,
): { privateKey: string; nonce: string } | null {
  const r = hexToBig(sig1.r);
  const s1 = hexToBig(sig1.s);
  const s2 = hexToBig(sig2.s);
  const z1 = hexToBig(sig1.z);
  const z2 = hexToBig(sig2.z);

  if (r === 0n) return null;
  if (s1 === s2) return null; // identical signature, no information leak

  const sDiff = mod(s1 - s2, N);
  if (sDiff === 0n) return null;

  // k = (z1 - z2) · (s1 - s2)^-1  mod n
  const k = mod(mod(z1 - z2, N) * modInverse(sDiff, N), N);

  // d = (s1·k - z1) · r^-1  mod n
  const rInv = modInverse(r, N);
  if (rInv === 0n) return null;
  const d = mod(mod(s1 * k - z1, N) * rInv, N);

  if (d === 0n || k === 0n) return null;

  return { privateKey: bigToHex32(d), nonce: bigToHex32(k) };
}

/** Generate a stable id. */
function vid(prefix: string, key: string): string {
  return `${prefix}-${key.slice(0, 16)}`;
}

/**
 * Analyze a batch of signatures and produce vulnerability findings.
 * FULL values everywhere — recovered keys, r/s/z, descriptions — no truncation.
 */
export function detectVulnerabilities(rows: Signature[]): Vulnerability[] {
  const findings: Vulnerability[] = [];

  // -----------------------------------------------------------------------
  // 1) Group by r to find nonce reuse (or duplicate signatures)
  // -----------------------------------------------------------------------
  const groups = new Map<string, Signature[]>();
  for (const row of rows) {
    const key = rKey(row.r);
    const list = groups.get(key);
    if (list) list.push(row);
    else groups.set(key, [row]);
  }

  for (const [r, list] of groups) {
    if (list.length < 2) continue;

    const sameEverything = list.every(
      (row) => row.s === list[0].s && row.z === list[0].z && row.pubkey === list[0].pubkey,
    );

    if (sameEverything) {
      // Duplicate record, not a new nonce. Informational.
      findings.push({
        id: vid("dup", r),
        type: "weak_nonce", // reuse the weak_nonce bucket as "info"-ish; severity low
        severity: "low",
        title: "Duplicate signature record",
        description:
          `The exact same r, s, and z appear ${list.length} times across ${list.length} record(s). ` +
          `This is a repeated record (likely the same input re-read), not a fresh nonce. ` +
          `r = ${list[0].r}. No private-key leak is implied.`,
        signatures: list,
      });
      continue;
    }

    // Genuine nonce reuse — try to recover the private key.
    // Pick the first two signatures with differing (s or z) to drive the math.
    let recovered: { privateKey: string; nonce: string } | null = null;
    let pairA: Signature | null = null;
    let pairB: Signature | null = null;
    for (let i = 0; i < list.length && !recovered; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i];
        const b = list[j];
        if (a.s === b.s && a.z === b.z) continue;
        const attempt = recoverKeyFromReuse(a, b);
        if (attempt) {
          recovered = attempt;
          pairA = a;
          pairB = b;
          break;
        }
      }
    }

    const addresses = [...new Set(list.map((s) => s.address || "(unknown)"))];
    const pubkeys = [...new Set(list.map((s) => s.pubkey).filter(Boolean))];

    if (recovered) {
      findings.push({
        id: vid("reuse", r),
        type: "nonce_reuse",
        severity: "critical",
        title: "Nonce reuse — private key recovered",
        description:
          `${list.length} signature${list.length === 1 ? "" : "s"} share the same r value ` +
          `(r = ${r.length > 64 ? r : r.padStart(64, "0")}). On secp256k1 a repeated r means ` +
          `the nonce k collided, which allows the private key to be recovered with simple modular ` +
          `arithmetic. Affected address(es): ${addresses.join(", ")}. ` +
          `Pubkey(s): ${pubkeys.join(", ")}. ` +
          `The recovered private key below controls all funds ever locked by this key — ` +
          `anyone with this key can sign transactions spending them.`,
        address: addresses[0],
        signatures: list,
        recovered_private_key: recovered.privateKey,
        recovered_nonce: recovered.nonce,
      });
    } else {
      // Reuse detected but recovery failed (e.g. s1 === s2 for all pairs).
      findings.push({
        id: vid("reuse", r),
        type: "nonce_reuse",
        severity: "critical",
        title: "Nonce reuse detected (key recovery inconclusive)",
        description:
          `${list.length} signature${list.length === 1 ? "" : "s"} share the same r value ` +
          `(r = ${r.length > 64 ? r : r.padStart(64, "0")}), which indicates nonce reuse. ` +
          `Automatic private-key recovery did not succeed on the available pair(s) ` +
          `(this happens when all matching signatures are byte-identical). ` +
          `Affected address(es): ${addresses.join(", ")}. Pubkey(s): ${pubkeys.join(", ")}.`,
        address: addresses[0],
        signatures: list,
      });
    }
    void pairA;
    void pairB;
  }

  // -----------------------------------------------------------------------
  // 2) High-S malleability, grouped by address
  // -----------------------------------------------------------------------
  const highSRows = rows.filter((row) => !row.low_s);
  if (highSRows.length) {
    const byAddr = new Map<string, Signature[]>();
    for (const row of highSRows) {
      const a = row.address || "(unknown)";
      const list = byAddr.get(a);
      if (list) list.push(row);
      else byAddr.set(a, [row]);
    }
    for (const [addr, list] of byAddr) {
      findings.push({
        id: vid("highs", addr.replace(/[^a-z0-9]/gi, "")),
        type: "high_s",
        severity: "medium",
        title: `High-S signatures for ${addr}`,
        description:
          `${list.length} signature${list.length === 1 ? "" : "s"} from ${addr} use an s value ` +
          `greater than half the curve order (s > n/2). This is the non-canonical (high-S) form. ` +
          `BIP-62 low-S policy rejects such signatures, and they are malleable — a third party can ` +
          `flip s to n−s and produce a different valid signature for the same tx, changing the txid. ` +
          `This is NOT a private-key leak. The signatures listed below are affected.`,
        address: addr,
        signatures: list,
      });
    }
  }

  // -----------------------------------------------------------------------
  // 3) Weak / biased nonce (very small r or short r)
  // -----------------------------------------------------------------------
  const verySmall = rows.filter((row) => (row.bit_length_r ?? bitLength(row.r)) <= 128);
  const mediumSmall = rows.filter((row) => {
    const bits = row.bit_length_r ?? bitLength(row.r);
    return bits > 128 && bits <= 160;
  });
  if (verySmall.length) {
    findings.push({
      id: "tiny-r",
      type: "weak_nonce",
      severity: "low",
      title: "Very small r (possible biased nonce)",
      description:
        `${verySmall.length} signature${verySmall.length === 1 ? "" : "s"} have an r value of 128 bits ` +
        `or fewer. A uniformly random nonce k almost never produces an r that small — ` +
        `this can be a sign of a biased or broken RNG in the signer. ` +
        `If the bias is severe enough, lattice attacks can recover the private key from a handful ` +
        `of such signatures. The signatures below should be treated as suspicious and investigated further.`,
      signatures: verySmall,
    });
  }
  if (mediumSmall.length) {
    findings.push({
      id: "short-r",
      type: "weak_nonce",
      severity: "low",
      title: "Short r (potential nonce bias)",
      description:
        `${mediumSmall.length} signature${mediumSmall.length === 1 ? "" : "s"} have an r value of ` +
        `129–160 bits. A healthy secp256k1 nonce produces a ~256-bit r. While not as damning as the ` +
        `tiny-r case, a cluster of short r values is worth a second look — it may indicate a mildly ` +
        `biased nonce generator that could be exploited with a lattice attack given enough samples.`,
      signatures: mediumSmall,
    });
  }

  // -----------------------------------------------------------------------
  // 4) Unverified z (sighash didn't match the signature)
  // -----------------------------------------------------------------------
  const failed = rows.filter((row) => row.verified === false);
  if (failed.length) {
    findings.push({
      id: "unverified-z",
      type: "weak_nonce",
      severity: "low",
      title: "Sighash did not verify",
      description:
        `${failed.length} signature${failed.length === 1 ? "" : "s"} did not verify against the ` +
        `computed z value. Common causes: unusual scripts, OP_CODESEPARATOR, missing input amount ` +
        `(so BIP143 z couldn't be computed), or a non-standard sighash type. ` +
        `The r and s are still valid; the z for these rows should not be trusted for key-recovery math.`,
      signatures: failed,
    });
  }

  // -----------------------------------------------------------------------
  // 5) LSB bias statistic (informational, only meaningful with enough samples)
  // -----------------------------------------------------------------------
  if (rows.length >= 40) {
    let odd = 0;
    for (const row of rows) if (hexToBig(row.r) & 1n) odd += 1;
    const ratio = odd / rows.length;
    if (ratio <= 0.32 || ratio >= 0.68) {
      findings.push({
        id: "lsb-bias",
        type: "weak_nonce",
        severity: "low",
        title: "Lopsided low bit of r",
        description:
          `${Math.round(ratio * 100)}% of r values are odd across ${rows.length} signatures ` +
          `(expected ~50%). A large skew is a hint of nonce bias, though it is only statistically ` +
          `meaningful on a large sample. Treat as a lead, not proof.`,
        signatures: [],
      });
    }
  }

  // Sort: critical first, then medium, then low.
  const order = { critical: 0, medium: 1, low: 2 };
  findings.sort((a, b) => order[a.severity] - order[b.severity]);
  return findings;
}

export { N, HALF_N };
