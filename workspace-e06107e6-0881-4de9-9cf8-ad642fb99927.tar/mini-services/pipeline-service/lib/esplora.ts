// ============================================================================
// Esplora blockchain-index client. Fetches all spending transactions for a
// Bitcoin address (transactions where the address appears as an input).
// Adapted from the reference workspace (src/lib/bitcoin/esplora.ts):
//   - mempool.space + blockstream.info with host racing + fallback
//   - paginated history walk (initial page + /txs/chain/{lastid} pages)
//   - txid reconciliation via re-serialization
//   - prevout assembly for sighash computation
// Adds: AbortSignal support, depth control, streaming progress callbacks.
// ============================================================================

import { sameAddress } from "./addresses.js";
import { hexToBytes, reverseBytes } from "./bytes.js";
import { extractSignatures, parseRawTransaction, txidOf, type Prevout, type Tx } from "./rawtx.js";
import type { Signature } from "./types.js";

const HOSTS = [
  { name: "mempool.space", base: "https://mempool.space/api" },
  { name: "blockstream.info", base: "https://blockstream.info/api" },
];

/** History depth — how many pages to walk back. */
export type Depth = "quick" | "standard" | "deep";

export const PAGES: Record<Depth, number> = { quick: 3, standard: 10, deep: 40 };
const BUDGET_MS = 8000;
const MAX_SIGNATURES_PER_ADDRESS = 500;

// ---------------------------------------------------------------------------
// Esplora JSON shapes
// ---------------------------------------------------------------------------
type EsploraPrevout = {
  scriptpubkey?: string;
  scriptpubkey_address?: string;
  value?: number;
};

type EsploraVin = {
  txid?: string;
  vout?: number;
  sequence?: number;
  scriptsig?: string;
  witness?: string[];
  is_coinbase?: boolean;
  prevout?: EsploraPrevout | null;
};

type EsploraTx = {
  txid: string;
  version?: number;
  locktime?: number;
  vin: EsploraVin[];
  vout: { scriptpubkey?: string; value?: number }[];
  status?: { block_height?: number; block_time?: number; confirmed?: boolean };
};

function isTx(value: unknown): value is EsploraTx {
  if (!value || typeof value !== "object") return false;
  const tx = value as EsploraTx;
  return typeof tx.txid === "string" && Array.isArray(tx.vin) && Array.isArray(tx.vout);
}

// ---------------------------------------------------------------------------
// HTTP helpers (with abort + timeout)
// ---------------------------------------------------------------------------
function anySignal(signals: (AbortSignal | undefined | null)[]): AbortSignal {
  const valid = signals.filter((s): s is AbortSignal => s != null);
  if (valid.length === 0) return AbortSignal.timeout(30000);
  // Bun/Node 20+ supports AbortSignal.any
  const anyFn = (AbortSignal as unknown as { any?: (s: AbortSignal[]) => AbortSignal }).any;
  if (typeof anyFn === "function") {
    return anyFn([...valid, AbortSignal.timeout(30000)]);
  }
  // Fallback: link aborts manually
  const ctrl = new AbortController();
  const timeout = setTimeout(() => ctrl.abort(new Error("timeout")), 30000);
  for (const s of valid) {
    if (s.aborted) {
      clearTimeout(timeout);
      ctrl.abort(s.reason);
      break;
    }
    s.addEventListener("abort", () => {
      clearTimeout(timeout);
      ctrl.abort(s.reason);
    });
  }
  return ctrl.signal;
}

async function getText(url: string, signal?: AbortSignal | null): Promise<string> {
  const response = await fetch(url, {
    signal: anySignal([signal]),
    headers: { accept: "application/json,text/plain", "user-agent": "ECDSA-Pipeline/1.0" },
  });
  if (!response.ok) throw new Error(`${response.status} from the chain index`);
  return response.text();
}

async function getJson(url: string, signal?: AbortSignal | null): Promise<unknown> {
  const text = await getText(url, signal);
  try {
    return JSON.parse(text) as unknown;
  } catch {
    throw new Error("The chain index returned something that is not JSON");
  }
}

// ---------------------------------------------------------------------------
// Map an Esplora tx JSON into our Tx + Prevout[] structure
// ---------------------------------------------------------------------------
function isAllZero(bytes: Uint8Array): boolean {
  for (const b of bytes) if (b !== 0) return false;
  return true;
}

function mapTx(remote: EsploraTx): { tx: Tx; prevouts: Prevout[] } {
  const ins = remote.vin.map((vin) => {
    const coinbase = Boolean(vin.is_coinbase) || (!vin.txid && vin.prevout == null);
    const prevTxid = !vin.txid || coinbase ? new Uint8Array(32) : reverseBytes(hexToBytes(vin.txid));
    const prevVout = coinbase ? 0xffffffff : (vin.vout ?? 0) >>> 0;
    return {
      prevTxid,
      prevVout,
      scriptSig: hexToBytes(vin.scriptsig || ""),
      sequence: (vin.sequence ?? 0xffffffff) >>> 0,
      witness: (vin.witness ?? []).map((item) => hexToBytes(item || "")),
      coinbase: Boolean(vin.is_coinbase) || (isAllZero(prevTxid) && prevVout === 0xffffffff),
    };
  });
  const outs = remote.vout.map((out) => ({
    value: BigInt(Math.trunc(out.value ?? 0)),
    scriptPubKey: hexToBytes(out.scriptpubkey || ""),
  }));
  const tx: Tx = {
    version: (remote.version ?? 1) >>> 0,
    ins,
    outs,
    locktime: (remote.locktime ?? 0) >>> 0,
    segwit: ins.some((inp) => inp.witness.length > 0),
  };
  const prevouts: Prevout[] = remote.vin.map((vin) => {
    if (!vin.prevout || !vin.prevout.scriptpubkey) return null;
    return {
      scriptPubKey: hexToBytes(vin.prevout.scriptpubkey),
      value: typeof vin.prevout.value === "number" ? BigInt(Math.trunc(vin.prevout.value)) : null,
      address: vin.prevout.scriptpubkey_address ?? null,
    };
  });
  return { tx, prevouts };
}

/** Reconcile the JSON-derived tx against the raw hex (catches index drift). */
async function loadTx(
  hostBase: string,
  remote: EsploraTx,
  signal?: AbortSignal | null,
): Promise<{ tx: Tx; prevouts: Prevout[]; reconciled: boolean }> {
  const mapped = mapTx(remote);
  if (txidOf(mapped.tx) === remote.txid) return { ...mapped, reconciled: true };
  const hex = (await getText(`${hostBase}/tx/${remote.txid}/hex`, signal)).trim();
  const tx = parseRawTransaction(hexToBytes(hex));
  if (txidOf(tx) !== remote.txid) return { ...mapped, reconciled: false };
  return { tx, prevouts: mapped.prevouts, reconciled: true };
}

function spends(tx: EsploraTx, address: string): boolean {
  return tx.vin.some((vin) => sameAddress(vin.prevout?.scriptpubkey_address, address));
}

// ---------------------------------------------------------------------------
// Host selection (race the hosts, pick the first that responds)
// ---------------------------------------------------------------------------
export async function pickHost(signal?: AbortSignal | null): Promise<(typeof HOSTS)[number]> {
  const attempts = HOSTS.map(async (host) => {
    const response = await fetch(`${host.base}/blocks/tip/height`, {
      signal: anySignal([signal, AbortSignal.timeout(5000)]),
      headers: { accept: "text/plain", "user-agent": "ECDSA-Pipeline/1.0" },
    });
    if (!response.ok) throw new Error(host.name);
    return host;
  });
  try {
    return await Promise.any(attempts);
  } catch {
    throw new Error("The chain index is unreachable. Try again in a moment.");
  }
}

// ---------------------------------------------------------------------------
// Paginated history walk
// ---------------------------------------------------------------------------
async function readPages(
  host: (typeof HOSTS)[number],
  address: string,
  depth: Depth,
  signal?: AbortSignal | null,
): Promise<{ txs: EsploraTx[]; source: string; base: string; truncated: boolean }> {
  const started = Date.now();
  const first = await getJson(`${host.base}/address/${encodeURIComponent(address)}/txs`, signal);
  if (!Array.isArray(first) || !first.every(isTx)) throw new Error("Unexpected address history");
  const txs: EsploraTx[] = [...first];
  let cursor = [...first].reverse().find((tx) => tx.status?.confirmed)?.txid ?? null;
  let pages = 1;
  let truncated = false;
  const maxPages = PAGES[depth];
  while (cursor && pages < maxPages) {
    if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
    if (Date.now() - started > BUDGET_MS) {
      truncated = true;
      break;
    }
    const page = await getJson(`${host.base}/address/${encodeURIComponent(address)}/txs/chain/${cursor}`, signal);
    if (!Array.isArray(page) || page.length === 0) break;
    if (!page.every(isTx)) throw new Error("Unexpected history page");
    txs.push(...page);
    pages += 1;
    if (page.length < 25) break;
    cursor = page[page.length - 1]?.txid ?? null;
    if (pages >= maxPages) truncated = true;
  }
  const seen = new Set<string>();
  const unique = txs.filter((tx) => {
    if (seen.has(tx.txid)) return false;
    seen.add(tx.txid);
    return true;
  });
  return { txs: unique, source: host.name, base: host.base, truncated };
}

async function fetchHistory(
  address: string,
  depth: Depth,
  preferredHost: (typeof HOSTS)[number] | null,
  signal?: AbortSignal | null,
): Promise<{ txs: EsploraTx[]; source: string; base: string; truncated: boolean }> {
  const preferred = preferredHost ?? (await pickHost(signal));
  const order = [preferred, ...HOSTS.filter((host) => host.name !== preferred.name)];
  let last = "The chain index is unreachable";
  for (const host of order) {
    try {
      return await readPages(host, address, depth, signal);
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") throw error;
      last = error instanceof Error ? error.message : last;
    }
  }
  throw new Error(last);
}

// ---------------------------------------------------------------------------
// Progress callback
// ---------------------------------------------------------------------------
export type ProgressCb = (msg: string, current?: number, total?: number) => void;

// ---------------------------------------------------------------------------
// Per-address scan: fetch + parse + extract signatures
// ---------------------------------------------------------------------------
export type ScanAddressResult = {
  address: string;
  source: string;
  seen: number;
  spending: number;
  signatures: Signature[];
  skipped: { reason: string; count: number }[];
  otherInputs: number;
  notice?: string;
  truncated: boolean;
};

export async function scanOneAddress(
  input: {
    address: string;
    depth: Depth;
    scope: "own" | "all";
    preferredHost?: (typeof HOSTS)[number] | null;
    signal?: AbortSignal | null;
    onProgress?: ProgressCb;
  },
): Promise<ScanAddressResult> {
  const { address, depth, scope, preferredHost = null, signal = null, onProgress } = input;

  onProgress?.(`Fetching transaction history for ${address}…`);
  const history = await fetchHistory(address, depth, preferredHost, signal);
  onProgress?.(`Index ${history.source} returned ${history.txs.length} transactions (walking ${depth}).`, 0, history.txs.length);

  const spending = history.txs.filter((tx) => spends(tx, address));
  onProgress?.(`${spending.length} spending transaction${spending.length === 1 ? "" : "s"} found for ${address}.`, spending.length, spending.length);

  const signatures: Signature[] = [];
  const skipMap = new Map<string, number>();
  let otherInputs = 0;
  let failed = 0;
  let unreconciled = 0;
  const hostBase = history.base;

  for (let i = 0; i < spending.length; i++) {
    if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
    const remote = spending[i];
    onProgress?.(`Parsing ${remote.txid} (${i + 1}/${spending.length})`, i + 1, spending.length);
    try {
      const loaded = await loadTx(hostBase, remote, signal);
      if (!loaded.reconciled) unreconciled += 1;
      const extracted = extractSignatures(loaded.tx, loaded.prevouts, {
        txid: remote.txid,
        address,
        blockHeight: remote.status?.block_height ?? null,
        blockTime: remote.status?.block_time ?? null,
        scope,
      });
      signatures.push(...extracted.signatures);
      otherInputs += extracted.otherInputs;
      for (const skip of extracted.skipped) skipMap.set(skip.reason, (skipMap.get(skip.reason) ?? 0) + skip.count);
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") throw error;
      failed += 1;
    }
    if (signatures.length >= MAX_SIGNATURES_PER_ADDRESS) break;
  }

  const notes: string[] = [];
  if (history.truncated) notes.push("History was cut short to keep this pass quick. Use a deeper scan on this address alone to read further back.");
  if (signatures.length >= MAX_SIGNATURES_PER_ADDRESS) notes.push(`Stopped after ${MAX_SIGNATURES_PER_ADDRESS} signatures from this address.`);
  if (failed) notes.push(`${failed} spending transaction${failed === 1 ? "" : "s"} could not be read.`);
  if (unreconciled) notes.push(`${unreconciled} transaction${unreconciled === 1 ? "" : "s"} did not reserialize cleanly, so those z values are less certain.`);
  if (scope === "own" && otherInputs) notes.push(`Left out ${otherInputs} input${otherInputs === 1 ? "" : "s"} that do not spend this address.`);
  if (!spending.length) notes.push("No spending transactions in the pages that were read. Incoming payments are ignored on purpose.");

  return {
    address,
    source: history.source,
    seen: history.txs.length,
    spending: spending.length,
    truncated: history.truncated || signatures.length >= MAX_SIGNATURES_PER_ADDRESS,
    signatures,
    skipped: [...skipMap.entries()].map(([reason, count]) => ({ reason, count })),
    otherInputs,
    notice: notes.length ? notes.join(" ") : undefined,
  };
}
