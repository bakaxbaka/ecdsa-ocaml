// ============================================================================
// Raw Bitcoin transaction parsing + ECDSA signature extraction.
// Adapted from the reference workspace (src/lib/bitcoin/parse.ts), which is a
// more complete and correct implementation than a naive Python port:
//   - handles P2PKH, P2PK, P2WPKH, P2WSH, P2SH, P2SH-P2WPKH, P2SH-P2WSH, nonstandard
//   - correct SIGHASH_NONE / SINGLE / ANYONECANPAY handling for legacy + BIP143
//   - REAL ECDSA verification via @noble/curves (so we can flag bad z values)
// Returns our pipeline `Signature` type (full r/s/z hex, no truncation).
// ============================================================================

import { secp256k1 } from "@noble/curves/secp256k1.js";
import { sha256 } from "@noble/hashes/sha2.js";
import { sameAddress } from "./addresses.js";
import type { Signature, SignatureType } from "./types.js";
import {
  bitLength,
  concat,
  encodeVarint,
  hexToBytes,
  isAllZero,
  reverseBytes,
  toHex,
  u32le,
  u64le,
} from "./bytes.js";

const N = 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n;
const HALF_N = N >> 1n;

const SIGHASH_ALL = 1;
const SIGHASH_NONE = 2;
const SIGHASH_SINGLE = 3;

// ---------------------------------------------------------------------------
// Transaction data types
// ---------------------------------------------------------------------------
export type TxIn = {
  prevTxid: Uint8Array;
  prevVout: number;
  scriptSig: Uint8Array;
  sequence: number;
  witness: Uint8Array[];
  coinbase: boolean;
};

export type TxOut = {
  value: bigint;
  scriptPubKey: Uint8Array;
};

export type Tx = {
  version: number;
  ins: TxIn[];
  outs: TxOut[];
  locktime: number;
  segwit: boolean;
};

export type Prevout = {
  scriptPubKey: Uint8Array;
  value: bigint | null;
  address: string | null;
} | null;

type ParsedSig = {
  r: bigint;
  s: bigint;
  hashType: number;
  der: Uint8Array;
  notes: string[];
};

// ---------------------------------------------------------------------------
// Hashing
// ---------------------------------------------------------------------------
function dsha256(data: Uint8Array): Uint8Array {
  return sha256(sha256(data));
}

// ---------------------------------------------------------------------------
// Reader for sequential byte parsing
// ---------------------------------------------------------------------------
class Reader {
  private o = 0;
  constructor(private readonly data: Uint8Array) {}

  remaining(): number {
    return this.data.length - this.o;
  }

  read(n: number): Uint8Array {
    if (this.o + n > this.data.length) throw new Error("Transaction is truncated");
    const s = this.data.slice(this.o, this.o + n);
    this.o += n;
    return s;
  }

  u8(): number {
    return this.read(1)[0];
  }

  u32(): number {
    const b = this.read(4);
    return (b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)) >>> 0;
  }

  u64(): bigint {
    const b = this.read(8);
    let n = 0n;
    for (let i = 0; i < 8; i++) n |= BigInt(b[i]) << BigInt(8 * i);
    return n;
  }

  varint(): number {
    const f = this.u8();
    if (f < 0xfd) return f;
    if (f === 0xfd) {
      const b = this.read(2);
      return b[0] | (b[1] << 8);
    }
    if (f === 0xfe) return this.u32();
    const b = this.read(8);
    return (b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)) >>> 0;
  }
}

// ---------------------------------------------------------------------------
// Transaction (de)serialization
// ---------------------------------------------------------------------------
export function parseRawTransaction(data: Uint8Array): Tx {
  const r = new Reader(data);
  const version = r.u32();
  let segwit = false;
  if (r.remaining() >= 2 && data[data.length - r.remaining()] === 0) {
    const mark = r.u8();
    const flag = r.u8();
    if (mark !== 0 || flag === 0) throw new Error("Bad segwit marker");
    segwit = true;
  }
  const vinCount = r.varint();
  const ins: TxIn[] = [];
  for (let i = 0; i < vinCount; i++) {
    const prevTxid = r.read(32);
    const prevVout = r.u32();
    const scriptLen = r.varint();
    const scriptSig = r.read(scriptLen);
    const sequence = r.u32();
    const coinbase = isAllZero(prevTxid) && prevVout === 0xffffffff;
    ins.push({ prevTxid, prevVout, scriptSig, sequence, witness: [], coinbase });
  }
  const voutCount = r.varint();
  const outs: TxOut[] = [];
  for (let i = 0; i < voutCount; i++) {
    const value = r.u64();
    const scriptLen = r.varint();
    outs.push({ value, scriptPubKey: r.read(scriptLen) });
  }
  if (segwit) {
    for (const inp of ins) {
      const count = r.varint();
      for (let i = 0; i < count; i++) {
        const len = r.varint();
        inp.witness.push(r.read(len));
      }
    }
  }
  const locktime = r.u32();
  return { version, ins, outs, locktime, segwit };
}

export function serializeTransaction(tx: Tx): Uint8Array {
  const parts: Uint8Array[] = [u32le(tx.version)];
  if (tx.segwit) parts.push(new Uint8Array([0, 1]));
  parts.push(encodeVarint(tx.ins.length));
  for (const inp of tx.ins) {
    parts.push(inp.prevTxid, u32le(inp.prevVout), encodeVarint(inp.scriptSig.length), inp.scriptSig, u32le(inp.sequence));
  }
  parts.push(encodeVarint(tx.outs.length));
  for (const out of tx.outs) {
    parts.push(u64le(out.value), encodeVarint(out.scriptPubKey.length), out.scriptPubKey);
  }
  if (tx.segwit) {
    for (const inp of tx.ins) {
      parts.push(encodeVarint(inp.witness.length));
      for (const item of inp.witness) parts.push(encodeVarint(item.length), item);
    }
  }
  parts.push(u32le(tx.locktime));
  return concat(parts);
}

export function txidOf(tx: Tx): string {
  const legacy = serializeTransaction({ ...tx, segwit: false });
  return toHex(reverseBytes(dsha256(legacy)));
}

// ---------------------------------------------------------------------------
// Sighash (z) computation
// ---------------------------------------------------------------------------
function sighashLabel(hashType: number): string {
  const base = hashType & 0x1f;
  const name =
    base === SIGHASH_ALL
      ? "ALL"
      : base === SIGHASH_NONE
      ? "NONE"
      : base === SIGHASH_SINGLE
      ? "SINGLE"
      : base === 0
      ? "DEFAULT"
      : `TYPE_${base}`;
  return hashType & 0x80 ? `${name}|ANYONECANPAY` : name;
}

function legacySighash(tx: Tx, inputIndex: number, scriptCode: Uint8Array, hashType: number): Uint8Array {
  const base = hashType & 0x1f;
  const anyone = (hashType & 0x80) !== 0;
  if (base === SIGHASH_SINGLE && inputIndex >= tx.outs.length) {
    const one = new Uint8Array(32);
    one[0] = 1;
    return one;
  }
  const parts: Uint8Array[] = [u32le(tx.version)];
  const indexes = anyone ? [inputIndex] : tx.ins.map((_, i) => i);
  parts.push(encodeVarint(indexes.length));
  for (const i of indexes) {
    const inp = tx.ins[i];
    parts.push(inp.prevTxid, u32le(inp.prevVout));
    if (i === inputIndex) parts.push(encodeVarint(scriptCode.length), scriptCode);
    else parts.push(new Uint8Array([0]));
    const seq = i !== inputIndex && (base === SIGHASH_NONE || base === SIGHASH_SINGLE) ? 0 : inp.sequence;
    parts.push(u32le(seq));
  }
  if (base === SIGHASH_NONE) {
    parts.push(new Uint8Array([0]));
  } else if (base === SIGHASH_SINGLE) {
    parts.push(encodeVarint(inputIndex + 1));
    for (let i = 0; i < inputIndex; i++) {
      parts.push(u64le(0xffffffffffffffffn), new Uint8Array([0]));
    }
    const out = tx.outs[inputIndex];
    parts.push(u64le(out.value), encodeVarint(out.scriptPubKey.length), out.scriptPubKey);
  } else {
    parts.push(encodeVarint(tx.outs.length));
    for (const out of tx.outs) {
      parts.push(u64le(out.value), encodeVarint(out.scriptPubKey.length), out.scriptPubKey);
    }
  }
  parts.push(u32le(tx.locktime), u32le(hashType));
  return dsha256(concat(parts));
}

function bip143Sighash(
  tx: Tx,
  inputIndex: number,
  scriptCode: Uint8Array,
  amount: bigint,
  hashType: number,
): Uint8Array {
  const base = hashType & 0x1f;
  const anyone = (hashType & 0x80) !== 0;
  const zero = new Uint8Array(32);

  let hashPrevouts = zero;
  if (!anyone) {
    const prev: Uint8Array[] = [];
    for (const inp of tx.ins) prev.push(inp.prevTxid, u32le(inp.prevVout));
    hashPrevouts = dsha256(concat(prev));
  }

  let hashSequence = zero;
  if (!anyone && base !== SIGHASH_SINGLE && base !== SIGHASH_NONE) {
    const seq: Uint8Array[] = [];
    for (const inp of tx.ins) seq.push(u32le(inp.sequence));
    hashSequence = dsha256(concat(seq));
  }

  let hashOutputs = zero;
  if (base !== SIGHASH_NONE && base !== SIGHASH_SINGLE) {
    const outs: Uint8Array[] = [];
    for (const out of tx.outs) outs.push(u64le(out.value), encodeVarint(out.scriptPubKey.length), out.scriptPubKey);
    hashOutputs = dsha256(concat(outs));
  } else if (base === SIGHASH_SINGLE && inputIndex < tx.outs.length) {
    const out = tx.outs[inputIndex];
    hashOutputs = dsha256(concat([u64le(out.value), encodeVarint(out.scriptPubKey.length), out.scriptPubKey]));
  }

  const inp = tx.ins[inputIndex];
  const preimage = concat([
    u32le(tx.version),
    hashPrevouts,
    hashSequence,
    inp.prevTxid,
    u32le(inp.prevVout),
    encodeVarint(scriptCode.length),
    scriptCode,
    u64le(amount),
    u32le(inp.sequence),
    hashOutputs,
    u32le(tx.locktime),
    u32le(hashType),
  ]);
  return dsha256(preimage);
}

// ---------------------------------------------------------------------------
// Script / DER parsing
// ---------------------------------------------------------------------------
type Push = { data: Uint8Array };

function parsePushes(script: Uint8Array): Push[] {
  const out: Push[] = [];
  let i = 0;
  while (i < script.length) {
    const op = script[i++];
    let n = 0;
    if (op === 0) {
      out.push({ data: new Uint8Array() });
      continue;
    }
    if (op >= 1 && op <= 75) n = op;
    else if (op === 0x4c) n = script[i++] ?? 0;
    else if (op === 0x4d) {
      n = (script[i] ?? 0) | ((script[i + 1] ?? 0) << 8);
      i += 2;
    } else if (op === 0x4e) {
      n =
        (script[i] ?? 0) |
        ((script[i + 1] ?? 0) << 8) |
        ((script[i + 2] ?? 0) << 16) |
        ((script[i + 3] ?? 0) << 24);
      i += 4;
    } else continue;
    out.push({ data: script.slice(i, i + n) });
    i += n;
  }
  return out;
}

function isPubkey(data: Uint8Array): boolean {
  return (
    (data.length === 33 && (data[0] === 2 || data[0] === 3)) ||
    (data.length === 65 && data[0] === 4)
  );
}

function parseDerSig(buf: Uint8Array): ParsedSig | null {
  if (buf.length < 9 || buf[0] !== 0x30) return null;
  const hashType = buf[buf.length - 1];
  const der = buf.slice(0, -1);
  if (der[0] !== 0x30) return null;
  const notes: string[] = [];
  if ((der[1] & 0x80) !== 0) return null;
  if (der[1] !== der.length - 2) notes.push("DER length mismatch");
  let p = 2;
  const readInt = (): bigint | null => {
    if (p >= der.length || der[p] !== 0x02) return null;
    const len = der[p + 1];
    const start = p + 2;
    const end = start + len;
    if (!len || end > der.length) return null;
    const bytes = der.slice(start, end);
    p = end;
    if (bytes[0] === 0x00 && (bytes.length === 1 || (bytes[1] & 0x80) === 0)) notes.push("non-minimal DER");
    if ((bytes[0] & 0x80) !== 0) notes.push("negative DER integer");
    return BigInt(`0x${toHex(bytes)}`);
  };
  const r = readInt();
  const s = readInt();
  if (r === null || s === null) return null;
  if (p !== der.length) notes.push("trailing bytes inside DER");
  if (r === 0n || s === 0n) notes.push("zero r or s");
  if (r >= N || s >= N) notes.push("component not reduced");
  return { r, s, hashType, der, notes: [...new Set(notes)] };
}

// ---------------------------------------------------------------------------
// Script-type detection
// ---------------------------------------------------------------------------
function isP2pkh(spk: Uint8Array): boolean {
  return spk.length === 25 && spk[0] === 0x76 && spk[1] === 0xa9 && spk[2] === 0x14 && spk[23] === 0x88 && spk[24] === 0xac;
}
function isP2sh(spk: Uint8Array): boolean {
  return spk.length === 23 && spk[0] === 0xa9 && spk[1] === 0x14 && spk[22] === 0x87;
}
function isP2wpkh(spk: Uint8Array): boolean {
  return spk.length === 22 && spk[0] === 0x00 && spk[1] === 0x14;
}
function isP2wsh(spk: Uint8Array): boolean {
  return spk.length === 34 && spk[0] === 0x00 && spk[1] === 0x20;
}
function isP2tr(spk: Uint8Array): boolean {
  return spk.length === 34 && spk[0] === 0x51 && spk[1] === 0x20;
}
function isP2pk(spk: Uint8Array): boolean {
  if (spk.length === 35 && spk[0] === 33 && (spk[1] === 2 || spk[1] === 3) && spk[34] === 0xac) return true;
  if (spk.length === 67 && spk[0] === 65 && spk[1] === 4 && spk[66] === 0xac) return true;
  return false;
}

function p2pkhFromHash(hash160: Uint8Array): Uint8Array {
  const out = new Uint8Array(25);
  out[0] = 0x76;
  out[1] = 0xa9;
  out[2] = 0x14;
  out.set(hash160, 3);
  out[23] = 0x88;
  out[24] = 0xac;
  return out;
}

function witnessProgram(script: Uint8Array): "wpkh" | "wsh" | null {
  if (isP2wpkh(script)) return "wpkh";
  if (isP2wsh(script)) return "wsh";
  return null;
}

function pubkeysIn(script: Uint8Array): Uint8Array[] {
  return parsePushes(script)
    .map((p) => p.data)
    .filter(isPubkey);
}

// ---------------------------------------------------------------------------
// ECDSA verification (real, via @noble/curves)
// ---------------------------------------------------------------------------
function verifyDer(der: Uint8Array, z: Uint8Array, pubkey: Uint8Array): boolean {
  try {
    return secp256k1.verify(der, z, pubkey, { prehash: false, lowS: false, format: "der" });
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Hex helpers for BigInt (FULL values, no truncation)
// ---------------------------------------------------------------------------
function minHex(n: bigint): string {
  // Even-length, no leading zero padding. Full value.
  const h = n.toString(16);
  return h.length % 2 === 0 ? h : "0" + h;
}

function zHex(bytes: Uint8Array | null): string {
  // z is always 32 bytes / 64 chars.
  return bytes ? toHex(bytes) : "00".repeat(32);
}

// ---------------------------------------------------------------------------
// Extraction context + main entry point
// ---------------------------------------------------------------------------
export type ExtractContext = {
  txid: string;
  address: string;
  blockHeight: number | null;
  blockTime: number | null;
  scope: "own" | "all";
};

export type ExtractResult = {
  signatures: Signature[];
  skipped: { reason: string; count: number }[];
  otherInputs: number;
};

export function extractSignatures(
  tx: Tx,
  prevouts: Prevout[],
  ctx: ExtractContext,
): ExtractResult {
  const signatures: Signature[] = [];
  const skipCounts = new Map<string, number>();
  let otherInputs = 0;
  const skip = (reason: string) => skipCounts.set(reason, (skipCounts.get(reason) ?? 0) + 1);

  tx.ins.forEach((inp, inputIndex) => {
    const prev = prevouts[inputIndex] ?? null;
    if (inp.coinbase) {
      skip("coinbase");
      return;
    }
    if (ctx.scope === "own" && prev?.address && !sameAddress(prev.address, ctx.address)) {
      otherInputs += 1;
      return;
    }
    if (!prev || prev.scriptPubKey.length === 0) {
      skip("missing prevout");
      return;
    }
    const spk = prev.scriptPubKey;
    if (isP2tr(spk)) {
      skip("Taproot (Schnorr, not ECDSA)");
      return;
    }

    const dataPushes = parsePushes(inp.scriptSig)
      .map((p) => p.data)
      .filter((d) => d.length > 0);

    let mode: "legacy" | "bip143" = "legacy";
    let scriptType: SignatureType | "P2WSH" | "P2SH-P2WPKH" | "P2SH-P2WSH" | "P2SH" | "nonstandard" = "P2PKH";
    let scriptCode: Uint8Array | null = null;
    const sigs: ParsedSig[] = [];
    const pubs: Uint8Array[] = [];

    const takeItems = (items: Uint8Array[]) => {
      for (const item of items) {
        const sig = parseDerSig(item);
        if (sig) sigs.push(sig);
        else if (isPubkey(item)) pubs.push(item);
      }
    };

    if (isP2wpkh(spk)) {
      mode = "bip143";
      scriptType = "P2WPKH";
      scriptCode = p2pkhFromHash(spk.slice(2));
      takeItems(inp.witness);
    } else if (isP2wsh(spk)) {
      mode = "bip143";
      scriptType = "P2WSH";
      if (inp.witness.length === 0) {
        skip("empty witness");
        return;
      }
      scriptCode = inp.witness[inp.witness.length - 1];
      takeItems(inp.witness.slice(0, -1));
      pubs.push(...pubkeysIn(scriptCode));
    } else if (isP2sh(spk)) {
      const redeem = dataPushes[dataPushes.length - 1];
      if (!redeem) {
        skip("P2SH without redeem script");
        return;
      }
      const kind = witnessProgram(redeem);
      if (kind === "wpkh") {
        mode = "bip143";
        scriptType = "P2SH-P2WPKH";
        scriptCode = p2pkhFromHash(redeem.slice(2));
        takeItems(inp.witness);
      } else if (kind === "wsh") {
        mode = "bip143";
        scriptType = "P2SH-P2WSH";
        if (inp.witness.length === 0) {
          skip("empty witness");
          return;
        }
        scriptCode = inp.witness[inp.witness.length - 1];
        takeItems(inp.witness.slice(0, -1));
        pubs.push(...pubkeysIn(scriptCode));
      } else {
        scriptType = "P2SH";
        scriptCode = redeem;
        takeItems(dataPushes.slice(0, -1));
        pubs.push(...pubkeysIn(redeem));
      }
    } else if (isP2pkh(spk)) {
      scriptType = "P2PKH";
      scriptCode = spk;
      takeItems(dataPushes);
    } else if (isP2pk(spk)) {
      scriptType = "P2PK";
      scriptCode = spk;
      takeItems(dataPushes);
      const pk = spk.slice(1, -1);
      if (isPubkey(pk)) pubs.push(pk);
    } else if (inp.witness.some((w) => w.length > 0) || dataPushes.length) {
      scriptType = "nonstandard";
      scriptCode = spk;
      mode = inp.witness.length ? "bip143" : "legacy";
      takeItems(dataPushes);
      takeItems(mode === "bip143" ? inp.witness.slice(0, -1) : inp.witness);
      pubs.push(...pubkeysIn(spk));
    } else {
      skip("no signature");
      return;
    }

    if (!sigs.length || !scriptCode) {
      skip("no ECDSA signature");
      return;
    }

    const seenPubs = new Map<string, Uint8Array>();
    for (const pk of pubs) seenPubs.set(toHex(pk), pk);
    const pubList = [...seenPubs.values()].slice(0, 16);

    sigs.forEach((sig, sigIndex) => {
      const notes = [...sig.notes];
      if (scriptCode!.includes(0xab)) notes.push("OP_CODESEPARATOR present");
      let z: Uint8Array | null = null;
      try {
        if (mode === "bip143") {
          if (prev.value === null) notes.push("missing input amount");
          else z = bip143Sighash(tx, inputIndex, scriptCode!, prev.value, sig.hashType);
        } else {
          z = legacySighash(tx, inputIndex, scriptCode!, sig.hashType);
        }
      } catch {
        notes.push("sighash failed");
      }

      let pubkey: Uint8Array | null = pubList[0] ?? null;
      let verified: boolean | null = null;
      if (z && pubList.length && sig.r > 0n && sig.s > 0n && sig.r < N && sig.s < N) {
        verified = false;
        for (const pk of pubList) {
          if (verifyDer(sig.der, z, pk)) {
            verified = true;
            pubkey = pk;
            break;
          }
        }
      } else if (!pubList.length) {
        notes.push("no public key to check z");
      }
      if (verified === false) notes.push("verification failed");

      // Build the canonical pipeline Signature. FULL values, no truncation.
      signatures.push({
        id: `${ctx.txid}:${inputIndex}:${sigIndex}`,
        address: prev.address || ctx.address,
        txid: ctx.txid,
        input_index: inputIndex,
        prev_txid: toHex(reverseBytes(inp.prevTxid)),
        prevout: inp.prevVout,
        sequence: inp.sequence,
        type: scriptType as SignatureType,
        der_signature: toHex(sig.der),
        r: minHex(sig.r),
        s: minHex(sig.s),
        low_s: sig.s > 0n && sig.s <= HALF_N,
        z: zHex(z),
        sighash_type: sig.hashType,
        pubkey: pubkey ? toHex(pubkey) : "(none)",
        sighash_label: sighashLabel(sig.hashType),
        verified,
        notes: [...new Set(notes)],
        block_height: ctx.blockHeight,
        block_time: ctx.blockTime,
        value_sats: prev.value === null ? null : prev.value.toString(),
        bit_length_r: bitLength(minHex(sig.r)),
      });
    });
  });

  const skipped = [...skipCounts.entries()].map(([reason, count]) => ({ reason, count }));
  return { signatures, skipped, otherInputs };
}

export { N, HALF_N, sighashLabel };
